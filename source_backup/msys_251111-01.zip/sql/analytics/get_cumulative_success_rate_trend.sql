WITH daily_stats AS (
    SELECT
        (start_dt AT TIME ZONE 'Asia/Seoul')::date AS date,
        job_id,
        SUM(CASE WHEN status = 'CD901' THEN 1 ELSE 0 END) AS success_count,
        COUNT(*) AS total_count
    FROM tb_con_hist
    {where_clause}
    GROUP BY (start_dt AT TIME ZONE 'Asia/Seoul')::date, job_id
)
SELECT
    date,
    job_id,
    (
        SUM(success_count) OVER (PARTITION BY job_id ORDER BY date) * 100.0 /
        NULLIF(SUM(total_count) OVER (PARTITION BY job_id ORDER BY date), 0)
    ) AS success_rate
FROM daily_stats
ORDER BY date, job_id;
