document.addEventListener('DOMContentLoaded', function() {
    const sessionTimerElement = document.getElementById('session-timer');
    let sessionTimeoutInterval;

    function updateSessionTimer(secondsRemaining) {
        if (!sessionTimerElement) return;

        if (secondsRemaining > 0) {
            const minutes = Math.floor(secondsRemaining / 60);
            const seconds = Math.floor(secondsRemaining % 60);
            sessionTimerElement.textContent = `(남은 시간: ${minutes}분 ${seconds}초)`;
        } else {
            sessionTimerElement.textContent = '(세션 만료)';
            clearInterval(sessionTimeoutInterval);
            // Optionally, redirect to login page
            // window.location.href = '/login';
        }
    }

    async function fetchAuthStatus() {
        try {
            const response = await fetch('/api/auth/status');
            if (response.ok) {
                const data = await response.json();
                if (data.isLoggedIn) {
                    let secondsRemaining = data.seconds_remaining;
                    updateSessionTimer(secondsRemaining);

                    if (sessionTimeoutInterval) clearInterval(sessionTimeoutInterval);
                    sessionTimeoutInterval = setInterval(() => {
                        secondsRemaining--;
                        updateSessionTimer(secondsRemaining);
                    }, 1000);
                }
            } else {
                if (sessionTimeoutInterval) clearInterval(sessionTimeoutInterval);
            }
        } catch (error) {
            console.error('Error fetching auth status:', error);
            if (sessionTimeoutInterval) clearInterval(sessionTimeoutInterval);
        }
    }

    // Initial fetch
    fetchAuthStatus();

    // Periodically sync with server to get the accurate remaining time
    setInterval(fetchAuthStatus, 60 * 1000); // every 1 minute
});
