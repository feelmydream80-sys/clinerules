# service/admin_settings_service.py
"""
Handles all business logic related to administrator settings.
"""
import logging
import random
from typing import List, Dict, Set
from mapper.mst_mapper import MstMapper
from mapper.mngr_sett_mapper import MngrSettMapper
from dao.schedule_settings_dao import ScheduleSettingsDAO
from msys.column_mapper import convert_to_new_columns, convert_to_legacy_columns

# Default settings are defined once as a constant for consistency.
DEFAULT_ADMIN_SETTINGS = {
    'CNN_FAILR_THRS_VAL': 5,
    'CNN_WARN_THRS_VAL': 3,
    'CNN_FAILR_ICON_ID': 2,
    'CNN_FAILR_WRD_COLR': '#dc3545',
    'CNN_WARN_ICON_ID': 5,
    'CNN_WARN_WRD_COLR': '#ffc107',
    'CNN_SUCS_ICON_ID': 1,
    'CNN_SUCS_WRD_COLR': '#28a745',
    'DLY_SUCS_RT_THRS_VAL': 95.0,
    'DD7_SUCS_RT_THRS_VAL': 90.0,
    'MTHL_SUCS_RT_THRS_VAL': 85.0,
    'MC6_SUCS_RT_THRS_VAL': 80.0,
    'YY1_SUCS_RT_THRS_VAL': 75.0,
    'SUCS_RT_SUCS_ICON_ID': 1,
    'SUCS_RT_SUCS_WRD_COLR': '#28a745',
    'SUCS_RT_WARN_ICON_ID': 2,
    'SUCS_RT_WARN_WRD_COLR': '#ffc107',
    'CHRT_COLR': '#007bff',
    'CHRT_DSP_YN': 'Y',
    'GRASS_CHRT_MIN_COLR': '#9be9a8',
    'GRASS_CHRT_MAX_COLR': '#216e39'
}

def get_random_hex_color() -> str:
    """Generates a random hex color."""
    return f"#{random.randint(0, 0xFFFFFF):06x}"

class MngrSettService:
    """
    Manages business logic for admin settings, including fetching, updating,
    and ensuring data consistency.
    """
    def __init__(self, db_connection):
        # --- Local Import for avoiding circular dependencies ---
        from service.dashboard_service import DashboardService
        from service.icon_service import IconService
        
        self.conn = db_connection
        self.dashboard_service = DashboardService(db_connection)
        self.icon_service = IconService(db_connection)
        self.mngr_sett_mapper = MngrSettMapper(db_connection)
        self.mst_mapper = MstMapper(db_connection)
        self.schedule_settings_dao = ScheduleSettingsDAO(db_connection)
        self.logger = logging.getLogger(self.__class__.__name__)

    def insert_or_update_settings(self, settings_data: dict):
        """
        Inserts or updates settings for a single Job ID.
        Applies default values for new settings.
        """
        try:
            mapper = self.mngr_sett_mapper
            converted_settings = convert_to_new_columns('TB_MNGR_SETT', settings_data)
            job_cd = converted_settings.get('cd')

            existing_settings = mapper.get_settings_by_cd(job_cd)
            
            if existing_settings:
                self.logger.info(f"Service: 기존 설정 업데이트 (CD: {job_cd})")
                mapper.insert_or_update_settings(settings_data)
            else:
                self.logger.info(f"Service: 신규 설정 삽입 (CD: {job_cd})")
                default_settings_new_keys = convert_to_new_columns('TB_MNGR_SETT', DEFAULT_ADMIN_SETTINGS)
                final_settings = {**default_settings_new_keys, **converted_settings}
                if job_cd:
                    final_settings['cd'] = job_cd
                
                final_settings_legacy = convert_to_legacy_columns('TB_MNGR_SETT', final_settings)
                mapper.insert_or_update_settings(final_settings_legacy)

            job_cd_for_log = converted_settings.get('cd', settings_data.get('sett_id', 'N/A'))
            self.logger.info(f"Service: Admin settings for {job_cd_for_log} saved successfully.")
        except Exception as e:
            job_cd_for_log = settings_data.get('sett_id', 'N/A')
            self.logger.error(f"Service: Failed to save/update settings for {job_cd_for_log}: {e}", exc_info=True)
            raise

    def get_all_settings(self) -> list[dict]:
        """
        Fetches all admin settings, ensuring consistency by creating default settings
        for jobs that have history but no settings record.
        """
        try:
            mapper = self.mngr_sett_mapper
            con_hist_summary = self.dashboard_service.get_summary(all_data=True)
            self._ensure_settings_for_all_jobs_with_history(self.conn, con_hist_summary)

            all_settings_raw = mapper.get_all_settings()
            all_icons = self.icon_service.get_all_icons_data()

            return self._combine_settings_details(all_settings_raw, con_hist_summary, all_icons)
        except Exception as e:
            self.logger.error(f"Service: Failed to get all settings: {e}", exc_info=True)
            return []

    def _ensure_settings_for_all_jobs_with_history(self, conn, con_hist_summary):
        """
        Ensures that any job with a history record that also exists in the master job list (TB_CON_MST)
        has a corresponding admin setting. If not, a default setting is created.
        """
        mapper = MngrSettMapper(conn)
        
        # 1. Get all unique job IDs from the execution history (TB_CON_HIST).
        all_hist_job_ids = {item['job_id'] for item in con_hist_summary}
        
        # 2. Get all existing job IDs from the admin settings (TB_MNGR_SETT).
        existing_admin_settings = mapper.get_all_settings()
        existing_admin_job_ids = {setting['cd'] for setting in existing_admin_settings}
        
        # 3. Get all valid job IDs from the master job list (TB_CON_MST).
        all_mst_job_ids = set(self.mst_mapper.get_all_job_ids())
        
        # Determine which jobs from history are missing settings.
        hist_jobs_missing_settings = all_hist_job_ids - existing_admin_job_ids
        
        # Filter this list to include only jobs that are also in the master list.
        jobs_to_create_settings_for = hist_jobs_missing_settings.intersection(all_mst_job_ids)
        
        if jobs_to_create_settings_for:
            self.logger.info(f"Service: Found {len(jobs_to_create_settings_for)} jobs that need default settings created.")
            
            existing_colors = {setting['chrt_colr'] for setting in existing_admin_settings if setting.get('chrt_colr')}
            
            for job_id in jobs_to_create_settings_for:
                new_setting_data = {'CD': job_id, **DEFAULT_ADMIN_SETTINGS}
                
                # Assign a unique random color for the chart.
                new_color = get_random_hex_color()
                while new_color in existing_colors:
                    new_color = get_random_hex_color()
                
                new_setting_data['CHRT_COLR'] = new_color
                existing_colors.add(new_color)
                
                mapper.insert_or_update_settings(new_setting_data)
                
            self.logger.info(f"Service: Default settings created for: {jobs_to_create_settings_for}")

    def _combine_settings_details(self, all_settings_raw: List[Dict], con_hist_summary: List[Dict], all_icons: List[Dict]) -> List[Dict]:
        hist_count_map = {item['job_id']: item['total_count'] for item in con_hist_summary}
        icon_code_map = {icon['icon_id']: icon['icon_cd'] for icon in all_icons}
        
        final_settings_list = []
        
        for setting_raw in all_settings_raw:
            job_id = setting_raw['cd']
            total_count = hist_count_map.get(job_id, 0)
            
            combined_setting = setting_raw.copy()
            combined_setting['total_count'] = total_count
            
            icon_fields = [
                'CNN_FAILR_ICON_ID', 'CNN_WARN_ICON_ID', 'CNN_SUCS_ICON_ID',
                'SUCS_RT_SUCS_ICON_ID', 'SUCS_RT_WARN_ICON_ID'
            ]
            for field in icon_fields:
                icon_id = combined_setting.get(field)
                combined_setting[f'{field}_code'] = icon_code_map.get(icon_id)
            
            final_settings_list.append(combined_setting)
        
        final_settings_list.sort(key=lambda x: x['cd'])
        return final_settings_list

    def delete_settings(self, cd: str):
        try:
            mapper = self.mngr_sett_mapper
            self.logger.info(f"Service: 설정 삭제 요청 (CD: {cd})")
            mapper.delete_settings(cd)
            self.logger.info(f"Service: Admin settings for {cd} deleted successfully.")
        except Exception as e:
            self.logger.error(f"Service: Failed to delete settings for {cd}: {e}", exc_info=True)
            raise

    def import_settings(self, settings_list: List[Dict]):
        try:
            self.logger.info(f"Service: Importing {len(settings_list)} settings.")
            for settings_data in settings_list:
                self.insert_or_update_settings(settings_data)
            self.logger.info("Service: Batch import of admin settings successful.")
        except Exception as e:
            self.logger.error(f"Service: Batch import failed: {e}", exc_info=True)
            raise

    def export_settings(self) -> List[Dict]:
        try:
            mapper = self.mngr_sett_mapper
            self.logger.info("Service: Exporting all admin settings.")
            settings = mapper.get_all_settings()
            self.logger.info(f"Service: Exported {len(settings)} settings successfully.")
            return settings
        except Exception as e:
            self.logger.error(f"Service: Failed to export settings: {e}", exc_info=True)
            raise

    def get_menu_settings(self) -> List[Dict]:
        """
        Fetches all menu settings from the database.
        """
        try:
            self.logger.info("Service: Fetching all menu settings.")
            menu_settings = self.mngr_sett_mapper.get_all_menu_settings()
            self.logger.info(f"Service: Fetched {len(menu_settings)} menu items successfully.")
            return menu_settings
        except Exception as e:
            self.logger.error(f"Service: Failed to fetch menu settings: {e}", exc_info=True)
            raise

    def get_schedule_settings_service(self) -> Dict:
        """
        Service layer to fetch schedule settings.
        The DAO now returns the data with icon codes already joined.
        """
        try:
            self.logger.info("Service: Fetching schedule settings (with pre-joined icon data).")
            settings = self.schedule_settings_dao.get_schedule_settings()
            if settings:
                self.logger.info("Service: Schedule settings fetched successfully.")
                # Convert snake_case from DB to camelCase for the frontend
                return {
                    'settId': settings.get('sett_id'),
                    'grpMinCnt': settings.get('grp_min_cnt'),
                    'prgsRtRedThrsval': settings.get('prgs_rt_red_thrsval'),
                    'prgsRtOrgThrsval': settings.get('prgs_rt_org_thrsval'),
                    'succRtRedThrsval': settings.get('succ_rt_red_thrsval'),
                    'succRtOrgThrsval': settings.get('succ_rt_org_thrsval'),
                    'useYn': settings.get('use_yn'),
                    'grpBrdrStyl': settings.get('grp_brdr_styl'),
                    'grpColrCrtr': settings.get('grp_colr_crtr'),
                    'sucsIconId': settings.get('sucs_icon_id'),
                    'sucsIconCd': settings.get('sucs_icon_cd'),
                    'sucsBgColr': settings.get('sucs_bg_colr'),
                    'sucsTxtColr': settings.get('sucs_txt_colr'),
                    'failIconId': settings.get('fail_icon_id'),
                    'failIconCd': settings.get('fail_icon_cd'),
                    'failBgColr': settings.get('fail_bg_colr'),
                    'failTxtColr': settings.get('fail_txt_colr'),
                    'prgsIconId': settings.get('prgs_icon_id'),
                    'prgsIconCd': settings.get('prgs_icon_cd'),
                    'prgsBgColr': settings.get('prgs_bg_colr'),
                    'prgsTxtColr': settings.get('prgs_txt_colr'),
                    'nodtIconId': settings.get('nodt_icon_id'),
                    'nodtIconCd': settings.get('nodt_icon_cd'),
                    'nodtBgColr': settings.get('nodt_bg_colr'),
                    'nodtTxtColr': settings.get('nodt_txt_colr'),
                    'schdIconId': settings.get('schd_icon_id'),
                    'schdIconCd': settings.get('schd_icon_cd'),
                    'schdBgColr': settings.get('schd_bg_colr'),
                    'schdTxtColr': settings.get('schd_txt_colr'),
                    'grpPrgsIconId': settings.get('grp_prgs_icon_id'),
                    'grpPrgsIconCd': settings.get('grp_prgs_icon_cd'),
                    'grpSucsIconId': settings.get('grp_sucs_icon_id'),
                    'grpSucsIconCd': settings.get('grp_sucs_icon_cd')
                }
            else:
                self.logger.warning("Service: No schedule settings found.")
                return None
        except Exception as e:
            self.logger.error(f"Service: Failed to fetch schedule settings: {e}", exc_info=True)
            raise
    
    def save_schedule_settings_service(self, settings_data: Dict, user_id: str):
        """
        Service layer to save schedule settings.
        It decides whether to create a new record or update an existing one.
        """
        try:
            sett_id = settings_data.get('sett_id')
            self.logger.info(f"Service: Saving schedule settings. sett_id: {sett_id}, user_id: {user_id}")

            # Add user_id for tracking who made the changes
            settings_data['updr_id'] = user_id
            
            if sett_id:
                self.logger.info(f"--- Service: Calling DAO to update with data: {settings_data}")
                self.schedule_settings_dao.update_schedule_settings(settings_data)
                self.logger.info(f"Service: Successfully updated settings for sett_id: {sett_id}")
                return {'message': '설정이 성공적으로 업데이트되었습니다.', 'sett_id': sett_id}
            else:
                settings_data['regr_id'] = user_id
                self.logger.info(f"--- Service: Calling DAO to create with data: {settings_data}")
                new_id = self.schedule_settings_dao.create_schedule_settings(settings_data)
                self.logger.info(f"Service: Successfully created new settings with sett_id: {new_id}")
                return {'message': '설정이 성공적으로 생성되었습니다.', 'sett_id': new_id}
        except Exception as e:
            self.logger.error(f"Service: Failed to save schedule settings: {e}", exc_info=True)
            raise
