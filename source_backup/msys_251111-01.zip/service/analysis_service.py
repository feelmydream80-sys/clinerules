import logging
from mapper.analysis_mapper import AnalysisMapper

class AnalysisService:
    def __init__(self, db_connection):
        self.conn = db_connection
        self.mapper = AnalysisMapper(db_connection)
        self.logger = logging.getLogger(self.__class__.__name__)

    def get_dynamic_chart_data(self, params: dict) -> list[dict]:
        """
        요청 파라미터를 기반으로 동적 차트 데이터를 조회합니다.
        """
        try:
            self.logger.info(f"▶ Service: 동적 차트 데이터 요청: {params}")
            # 현재는 매퍼를 직접 호출하지만, 향후 복잡한 비즈니스 로직 추가 가능
            data = self.mapper.get_dynamic_chart_data(params)
            self.logger.info(f"✅ Service: 동적 차트 데이터 {len(data)}건 조회 성공")
            return data
        except ValueError as ve:
            self.logger.error(f"❌ Service: 유효하지 않은 파라미터: {ve}", exc_info=True)
            raise
        except Exception as e:
            self.logger.error(f"❌ Service: 동적 차트 데이터 조회 실패: {e}", exc_info=True)
            raise
