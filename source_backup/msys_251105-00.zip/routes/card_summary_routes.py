import logging
from flask import Blueprint, render_template
from flask_login import login_required

card_summary_bp = Blueprint('card_summary', __name__)

@card_summary_bp.route('/card_summary')
@login_required
def card_summary():
    """카드 요약 페이지를 렌더링합니다."""
    logging.getLogger(__name__).info("--- [LOG] Entered card_summary() route function.")
    return render_template('card_summary.html')
