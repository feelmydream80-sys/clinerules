from dao.sql_loader import load_sql

class RawDataSQL:
    @staticmethod
    def get_min_max_dates():
        return load_sql('raw_data/get_min_max_dates.sql')

    @staticmethod
    def get_raw_data(start_date, end_date, job_ids, all_data):
        query = "SELECT * FROM TB_CON_HIST"
        params = []
        conditions = []
        
        if not all_data:
            if start_date:
                conditions.append("(start_dt AT TIME ZONE 'Asia/Seoul')::date >= %s")
                params.append(start_date)
            if end_date:
                conditions.append("(start_dt AT TIME ZONE 'Asia/Seoul')::date <= %s")
                params.append(end_date)

        if job_ids:
            conditions.append("job_id = ANY(%s)")
            params.append(job_ids)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        
        query += " ORDER BY start_dt DESC"
            
        return query, params
