// static/js/pages/dashboard.js

/**
 * @file dashboard.js
 * @description 대시보드 페이지의 진입점(Entry Point) 역할을 합니다.
 * - 필요한 모듈들을 가져와서 페이지 초기화를 담당하는 함수를 호출합니다.
 * - 각 기능의 상세 구현은 `static/js/modules/dashboard/` 디렉토리의 모듈들이 담당합니다.
 * 
 * @see {@link module:data} for data loading and state management.
 * @see {@link module:ui} for UI rendering and interaction.
 * @see {@link module:events} for event handling and main application logic.
 * 
 * @example
 * // 이 파일은 HTML에서 <script type="module" src=".../dashboard.js"></script> 형태로 로드됩니다.
 * // 별도의 호출 없이, DOMContentLoaded 이벤트에 따라 자동으로 initializeDashboard 함수가 실행됩니다.
 */

import { initializeDashboard as init } from '../modules/dashboard/events.js';

export { init };
