export function init() {
    // DOM Elements
    const weeklyBtn = document.getElementById('weekly-btn');
    const monthlyBtn = document.getElementById('monthly-btn');
    const calendarGrid = document.getElementById('calendar-grid');
    const cardTitle = document.querySelector('.card-title');
    const totalCountEl = document.getElementById('total-count');
    const successCountEl = document.getElementById('success-count');
    const failCountEl = document.getElementById('fail-count');
    const nodataCountEl = document.getElementById('nodata-count');
    const saveSettingsBtn = document.getElementById('save-settings-btn');
    const settingsHeader = document.getElementById('settings-header');
    const settingsBody = document.getElementById('settings-body');
    const settingsContainer = document.getElementById('settings-container');
    const toggleIcon = document.getElementById('toggle-icon');
    
    let mstData = {}; // For mapping job_id to name
 
    // --- Collapsible Settings ---
    const settingsCollapseManager = {
        _storageKey: 'heatmapSettingsCollapsed',
        _isCollapsed: false,

        init() {
            this.loadState();
            this.applyState();
            settingsHeader.addEventListener('click', () => {
                this.toggleState();
            });
        },
        loadState() {
            this._isCollapsed = localStorage.getItem(this._storageKey) === 'true';
        },
        saveState() {
            localStorage.setItem(this._storageKey, this._isCollapsed);
        },
        applyState() {
            settingsBody.classList.toggle('collapsed', this._isCollapsed);
            settingsContainer.classList.toggle('collapsed', this._isCollapsed);
            toggleIcon.classList.toggle('collapsed', this._isCollapsed);
        },
        toggleState() {
            this._isCollapsed = !this._isCollapsed;
            this.applyState();
            this.saveState();
        }
    };
    settingsCollapseManager.init();

    // --- Settings Manager ---
    const settingsManager = {
        _storageKey: 'heatmapSettings',
        _defaults: {
            groupingThreshold: 5,
            colorMetric: 'progress',
            redThreshold: 30,
            orangeThreshold: 100,
        },
        _settings: {},

        init() {
            this.load();
            this.applyToUI();
            saveSettingsBtn.addEventListener('click', () => {
                this.saveFromUI();
                alert('설정이 저장되었습니다.');
                // Re-render with new settings
                const activeView = weeklyBtn.classList.contains('active') ? 'weekly' : 'monthly';
                fetchData(activeView);
            });
        },

        load() {
            try {
                const storedSettings = localStorage.getItem(this._storageKey);
                this._settings = storedSettings ? JSON.parse(storedSettings) : { ...this._defaults };
            } catch (e) {
                console.error("Failed to load settings from localStorage", e);
                this._settings = { ...this._defaults };
            }
        },

        save() {
            try {
                localStorage.setItem(this._storageKey, JSON.stringify(this._settings));
            } catch (e) {
                console.error("Failed to save settings to localStorage", e);
            }
        },

        applyToUI() {
            document.getElementById('grouping-threshold').value = this._settings.groupingThreshold;
            document.getElementById('color-metric').value = this._settings.colorMetric;
            document.getElementById('red-threshold').value = this._settings.redThreshold;
            document.getElementById('orange-threshold').value = this._settings.orangeThreshold;
        },

        saveFromUI() {
            this._settings.groupingThreshold = parseInt(document.getElementById('grouping-threshold').value, 10) || this._defaults.groupingThreshold;
            this._settings.colorMetric = document.getElementById('color-metric').value || this._defaults.colorMetric;
            this._settings.redThreshold = parseInt(document.getElementById('red-threshold').value, 10) || this._defaults.redThreshold;
            this._settings.orangeThreshold = parseInt(document.getElementById('orange-threshold').value, 10) || this._defaults.orangeThreshold;
            this.save();
        },

        get(key) {
            return this._settings[key];
        }
    };

    settingsManager.init();
    // --- End Settings Manager ---

    function getStatusClass(status) {
        switch (status) {
            case '성공': return 'status-success';
            case '실패': return 'status-fail';
            case '미수집': return 'status-nodata';
            case '수집중': return 'status-inprogress';
            case '예정': return 'status-scheduled';
            default: return '';
        }
    }

    function getStatusIcon(status) {
        // Icons for individual jobs in the popup
        switch (status) {
            case '성공': return '✅';
            case '실패': return '❌';
            case '미수집': return '⚠️';
            case '수집중': return '🟡';
            case '예정': return '⏰';
            default: return '';
        }
    }

    function getGroupPillColorClass(rate, redThreshold, orangeThreshold) {
        if (rate < redThreshold) return 'status-fail'; // Red
        if (rate < orangeThreshold) return 'status-inprogress'; // Orange/Yellow
        return 'status-success'; // Green
    }

    function renderCalendar(data) {
        calendarGrid.innerHTML = '';
        const today = new Date().toISOString().split('T')[0];

        const groupedData = data.reduce((acc, item) => {
            const date = item.date;
            if (!acc[date]) acc[date] = [];
            acc[date].push(item);
            return acc;
        }, {});

        if (data.length === 0) {
            calendarGrid.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">해당 기간에 예정된 수집 일정이 없습니다.</p>';
            return;
        }

        const allDates = Array.from(new Set(data.map(item => item.date))).sort();
        const startDate = new Date(allDates[0]);
        const endDate = new Date(allDates[allDates.length - 1]);
        
        let currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            const dateStr = currentDate.toISOString().split('T')[0];
            const dayData = groupedData[dateStr] || [];
            
            const dayColumn = document.createElement('div');
            dayColumn.className = 'day-column';
            if (dateStr === today) dayColumn.classList.add('today');

            const dayHeader = document.createElement('div');
            dayHeader.className = 'day-header';
            dayHeader.textContent = `${String(currentDate.getMonth() + 1).padStart(2, '0')}/${String(currentDate.getDate()).padStart(2, '0')} (${['일', '월', '화', '수', '목', '금', '토'][currentDate.getDay()]})`;
            
            const jobsContainer = document.createElement('div');
            jobsContainer.className = 'jobs-container';

            const jobsByGroup = dayData.reduce((acc, job) => {
                const jobIdNum = parseInt(job.job_id.replace('CD', ''), 10);
                if (isNaN(jobIdNum)) return acc;
                const groupId = `CD${Math.floor(jobIdNum / 100) * 100}`;
                if (!acc[groupId]) acc[groupId] = [];
                acc[groupId].push(job);
                return acc;
            }, {});

            Object.keys(jobsByGroup).sort().forEach(groupName => {
                const groupJobs = jobsByGroup[groupName];
                const groupingThreshold = settingsManager.get('groupingThreshold');

                if (groupJobs.length >= groupingThreshold) {
                    // Render as a group pill
                    const allScheduled = groupJobs.every(j => j.status === '예정');

                    const total = groupJobs.length;
                    const success = groupJobs.filter(j => j.status === '성공').length;
                    const fail = groupJobs.filter(j => j.status === '실패').length;
                    const completed = success + fail;
                    
                    const progressRate = total > 0 ? Math.round((completed / total) * 100) : 0;
                    const successRate = completed > 0 ? Math.round((success / completed) * 100) : 0;

                    let colorClass;
                    if (allScheduled) {
                        colorClass = 'status-scheduled';
                    } else {
                        const colorMetric = settingsManager.get('colorMetric');
                        const rateForColor = colorMetric === 'success' ? successRate : progressRate;
                        colorClass = getGroupPillColorClass(rateForColor, settingsManager.get('redThreshold'), settingsManager.get('orangeThreshold'));
                    }

                    const groupPill = document.createElement('div');
                    groupPill.className = `job-pill group-pill-summary ${colorClass}`;
                    const displayMode = document.querySelector('input[name="displayMode"]:checked').value;
                    const originalGroupName = displayMode === 'name' && mstData[groupName] ? mstData[groupName] : groupName;
                    const groupDisplayName = originalGroupName.length > 10 ? originalGroupName.substring(0, 10) + '...' : originalGroupName;
                    groupPill.innerHTML = `<span>${groupDisplayName} (${progressRate}% / ${successRate}%)</span>`;
                    groupPill.title = originalGroupName;

                    const popup = document.createElement('div');
                    popup.className = 'popup';
                    groupJobs.sort((a, b) => a.job_id.localeCompare(b.job_id)).forEach(job => {
                        const displayMode = document.querySelector('input[name="displayMode"]:checked').value;
                        const originalName = displayMode === 'name' && mstData[job.job_id] ? mstData[job.job_id] : job.job_id;
                        const displayName = originalName.length > 10 ? originalName.substring(0, 10) + '...' : originalName;
                        popup.innerHTML += `<div class="job-pill ${getStatusClass(job.status)}" title="${originalName}">${getStatusIcon(job.status)} ${displayName}</div>`;
                    });
                    groupPill.appendChild(popup);
                    jobsContainer.appendChild(groupPill);
                } else {
                    // Render individual job pills
                    groupJobs.forEach(job => {
                        const jobItem = document.createElement('div');
                        jobItem.className = `job-pill ${getStatusClass(job.status)}`;
                        const displayMode = document.querySelector('input[name="displayMode"]:checked').value;
                        const originalName = displayMode === 'name' && mstData[job.job_id] ? mstData[job.job_id] : job.job_id;
                        const displayName = originalName.length > 10 ? originalName.substring(0, 10) + '...' : originalName;
                        jobItem.textContent = `${getStatusIcon(job.status)} ${displayName}`;
                        jobItem.title = originalName;
                        jobsContainer.appendChild(jobItem);
                    });
                }
            });

            dayColumn.appendChild(dayHeader);
            dayColumn.appendChild(jobsContainer);
            calendarGrid.appendChild(dayColumn);
            currentDate.setDate(currentDate.getDate() + 1);
        }
    }

    function updateSummary(data) {
        const total = data.filter(d => d.status !== '예정').length;
        const success = data.filter(d => d.status === '성공').length;
        const fail = data.filter(d => d.status === '실패').length;
        const nodata = data.filter(d => d.status === '미수집' || d.status === '수집중').length;

        totalCountEl.textContent = total;
        successCountEl.textContent = success;
        failCountEl.textContent = fail;
        nodataCountEl.textContent = nodata;
    }

    async function fetchData(viewType) {
        // Fetch MST data for mapping if not already fetched
        if (Object.keys(mstData).length === 0) {
            try {
                const mstResponse = await fetch('/api/mst_list');
                const mstResult = await mstResponse.json();
                if (mstResult) {
                    mstData = mstResult.reduce((acc, item) => {
                        acc[item.job_id] = item.cd_nm;
                        return acc;
                    }, {});
                }
            } catch (e) {
                console.error("Failed to fetch MST data", e);
                // Continue without mapping
            }
        }

        fetch(`/api/collection_schedule?view=${viewType}`)
            .then(response => {
                if (!response.ok) {
                    if (response.status === 401) {
                        alert('세션이 만료되었거나 로그인되지 않았습니다. 로그인 페이지로 이동합니다.');
                        window.location.href = '/login';
                    }
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    alert(data.error);
                    return;
                }
                cardTitle.textContent = viewType === 'weekly' ? '주간 수집 현황 히트맵' : '월간 수집 현황 히트맵';
                renderCalendar(data);
                updateSummary(data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                alert('데이터를 불러오는 데 실패했습니다.');
            });
    }

    weeklyBtn.addEventListener('click', () => {
        if (!weeklyBtn.classList.contains('active')) {
            weeklyBtn.classList.add('active');
            monthlyBtn.classList.remove('active');
            fetchData('weekly');
        }
    });

    monthlyBtn.addEventListener('click', () => {
        if (!monthlyBtn.classList.contains('active')) {
            monthlyBtn.classList.add('active');
            weeklyBtn.classList.remove('active');
            fetchData('monthly');
        }
    });

    document.querySelectorAll('input[name="displayMode"]').forEach(radio => {
        radio.addEventListener('change', () => {
            const activeView = weeklyBtn.classList.contains('active') ? 'weekly' : 'monthly';
            fetchData(activeView);
        });
    });
 
    // Initial load
    fetchData('weekly');
}
