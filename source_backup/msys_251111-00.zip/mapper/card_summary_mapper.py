# mapper/card_summary_mapper.py
from dao.sql_loader import load_sql as get_sql
import logging

class CardSummaryMapper:
    def __init__(self, db_connection):
        self.conn = db_connection

    def get_latest_job_status_today(self):
        """
        Fetches the latest status for each job_id for the current day (KST).
        """
        try:
            with self.conn.cursor() as cursor:
                sql = get_sql('card_summary/get_latest_job_status_today')
                cursor.execute(sql)
                result = cursor.fetchall()
                return result
        except Exception as e:
            logging.error(f"Error in get_latest_job_status_today: {e}")
            return []
