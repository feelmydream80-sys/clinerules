import { getRandomColorForAdmin } from '../mngr_sett/adminUtils.js';
import { showConfirm } from '../common/utils.js';
import { saveIcon, confirmAndDeleteIcon, toggleIconDisplayStatus } from './events.js';

// @DOC: 이 파일은 관리자 설정 페이지의 UI 렌더링 및 조작과 관련된 함수들을 포함합니다.
// DOM 요소 캐싱, 테이블 렌더링, 폼 표시/숨김 등 UI 로직을 담당하여 코드의 가독성과 유지보수성을 높입니다.

// @DOC: 자주 사용되는 DOM 요소를 변수에 캐싱하여 성능을 최적화합니다.
export const settingsTableBody = document.getElementById('settingsTableBody');
export const chartSettingsTableBody = document.getElementById('chartSettingsTableBody');
export const importFileInput = document.getElementById('importFile');
export const iconTableBody = document.getElementById('iconTableBody');
export const iconIdInput = document.getElementById('iconId');
export const iconCodeInput = document.getElementById('iconCode');
export const iconNameInput = document.getElementById('iconName');
export const iconDescriptionInput = document.getElementById('iconDescription');
export const saveIconButton = document.getElementById('saveIconBtn');
export const cancelEditIconButton = document.getElementById('cancelEditBtn');
export const importIconsFile = document.getElementById('importIconsFile');
export const adminLoadingOverlay = document.getElementById('adminLoadingOverlay');

/**
 * @DOC: 탭 버튼 클릭 시 해당 탭 콘텐츠를 표시하는 기능을 설정합니다.
 * @example
 * // 페이지 로드 시 호출되어 탭 기능을 활성화합니다.
 * setupTabs();
 */
export function setupTabs() {
    console.log("Setting up tabs...");
    const tabs = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(item => item.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            tab.classList.add('active');
            const targetTab = document.getElementById(tab.dataset.tab);
            if (targetTab) {
                targetTab.classList.add('active');
            }
            console.log(`Tab changed to: ${tab.dataset.tab}`);
        });
    });
}

/**
 * @DOC: 관리자 설정 데이터를 받아 HTML 테이블로 렌더링합니다.
 * `allAdminSettings` 배열을 순회하며 각 설정 항목을 테이블의 행으로 만듭니다.
 * @param {Array<Object>} allAdminSettings - 표시할 관리자 설정 데이터 배열. `data.js`의 `allAdminSettings`가 사용됩니다.
 * @param {Array<Object>} allIcons - 아이콘 선택 드롭다운을 채우기 위한 아이콘 데이터 배열. `data.js`의 `allIcons`가 사용됩니다.
 * @example
 * // adminSettings와 icons 데이터를 사용하여 설정 테이블을 렌더링합니다.
 * // renderSettingsTable(adminSettings, icons);
 */
export function renderSettingsTable(allMngrSett, allIcons) {
    console.log("Rendering settings table...");
    settingsTableBody.innerHTML = '';
    renderChartSettingsTable(allMngrSett); // 차트 설정 테이블도 함께 렌더링

    if (allMngrSett.length === 0) {
        settingsTableBody.innerHTML = '<tr><td colspan="20" class="text-center py-4">표시할 Job ID가 없습니다. (tb_con_hist에 이력이 있는 Job ID만 표시됩니다.)</td></tr>';
        return;
    }

    console.log("renderSettingsTable: Current allIcons data:", allIcons);
    console.log("renderSettingsTable: Current allMngrSett data:", allMngrSett);

    allMngrSett.forEach((setting, index) => {
        console.log(`🔍 테이블 렌더링 ${index + 1}: Job ID: ${setting.cd}, Job Name: ${setting.cd_nm}, Job Name Type: ${typeof setting.cd_nm}, Item5: ${setting.item5}`);
        if (index < 3) {
            console.log('🔍 Full setting object:', setting);
        }
        const row = settingsTableBody.insertRow();
        row.dataset.cd = String(setting.cd);

        const cfFailIconId = setting.cnn_failr_icon_id !== undefined && setting.cnn_failr_icon_id !== null ? parseInt(setting.cnn_failr_icon_id) : null;
        const cfWarningIconId = setting.cnn_warn_icon_id !== undefined && setting.cnn_warn_icon_id !== null ? parseInt(setting.cnn_warn_icon_id) : null;
        const cfSuccessIconId = setting.cnn_sucs_icon_id !== undefined && setting.cnn_sucs_icon_id !== null ? parseInt(setting.cnn_sucs_icon_id) : null;
        const srSuccessIconId = setting.sucs_rt_sucs_icon_id !== undefined && setting.sucs_rt_sucs_icon_id !== null ? parseInt(setting.sucs_rt_sucs_icon_id) : null;
        const srWarningIconId = setting.sucs_rt_warn_icon_id !== undefined && setting.sucs_rt_warn_icon_id !== null ? parseInt(setting.sucs_rt_warn_icon_id) : null;

        console.log(`Job ID: ${setting.cd}, cnn_failr_icon_id: ${cfFailIconId}, cnn_warn_icon_id: ${cfWarningIconId}, cnn_sucs_icon_id: ${cfSuccessIconId}, sucs_rt_sucs_icon_id: ${srSuccessIconId}, sucs_rt_warn_icon_id: ${srWarningIconId}`);

        row.innerHTML = `
            <td class="job-id-cell">${setting.cd}</td>
            <td><input type="text" value="${setting.cd_nm || setting.cd}" data-field="cd_nm" placeholder="Job 이름" readonly disabled></td>
            <td><input type="text" value="${setting.cd_desc || ''}" data-field="cd_desc" placeholder="Job 설명" readonly disabled></td>
            <td><input type="text" value="${setting.item5 || ''}" data-field="item5" placeholder="비고" readonly disabled></td>
            <td><input type="number" value="${setting.cnn_failr_thrs_val || 0}" data-field="cnn_failr_thrs_val"></td>
            <td>
                <select data-field="cnn_failr_icon_id" class="icon-select">
                    <option value="">선택 안 함</option>
                    ${allIcons.filter(icon => icon.icon_dsp_yn === true).map(icon => {
                        const isSelected = icon.icon_id === cfFailIconId;
                        return `<option value="${String(icon.icon_id)}" ${isSelected ? 'selected' : ''}>${icon.icon_cd}</option>`;
                    }).join('')}
                </select>
            </td>
            <td><input type="color" value="${setting.cnn_failr_wrd_colr || '#FF0000'}" data-field="cnn_failr_wrd_colr"></td>
            <td><input type="number" value="${setting.cnn_warn_thrs_val || 0}" data-field="cnn_warn_thrs_val"></td>
            <td>
                <select data-field="cnn_warn_icon_id" class="icon-select">
                    <option value="">선택 안 함</option>
                    ${allIcons.filter(icon => icon.icon_dsp_yn === true).map(icon => `<option value="${String(icon.icon_id)}" ${icon.icon_id === cfWarningIconId ? 'selected' : ''}>${icon.icon_cd}</option>`).join('')}
                </select>
            </td>
            <td><input type="color" value="${setting.cnn_warn_wrd_colr || '#FFA500'}" data-field="cnn_warn_wrd_colr"></td>
            <td>
                <select data-field="cnn_sucs_icon_id" class="icon-select">
                    <option value="">선택 안 함</option>
                    ${allIcons.filter(icon => icon.icon_dsp_yn === true).map(icon => `<option value="${String(icon.icon_id)}" ${icon.icon_id === cfSuccessIconId ? 'selected' : ''}>${icon.icon_cd}</option>`).join('')}
                </select>
            </td>
            <td><input type="color" value="${setting.cnn_sucs_wrd_colr || '#008000'}" data-field="cnn_sucs_wrd_colr"></td>
            <td><input type="number" step="0.01" value="${setting.dly_sucs_rt_thrs_val || 0}" data-field="dly_sucs_rt_thrs_val"></td>
            <td><input type="number" step="0.01" value="${setting.dd7_sucs_rt_thrs_val || 0}" data-field="dd7_sucs_rt_thrs_val"></td>
            <td><input type="number" step="0.01" value="${setting.mthl_sucs_rt_thrs_val || 0}" data-field="mthl_sucs_rt_thrs_val"></td>
            <td><input type="number" step="0.01" value="${setting.mc6_sucs_rt_thrs_val || 0}" data-field="mc6_sucs_rt_thrs_val"></td>
            <td><input type="number" step="0.01" value="${setting.yy1_sucs_rt_thrs_val || 0}" data-field="yy1_sucs_rt_thrs_val"></td>
            <td>
                <select data-field="sucs_rt_sucs_icon_id" class="icon-select">
                    <option value="">선택 안 함</option>
                    ${allIcons.filter(icon => icon.icon_dsp_yn === true).map(icon => `<option value="${String(icon.icon_id)}" ${icon.icon_id === srSuccessIconId ? 'selected' : ''}>${icon.icon_cd}</option>`).join('')}
                </select>
            </td>
            <td><input type="color" value="${setting.sucs_rt_sucs_wrd_colr || '#008000'}" data-field="sucs_rt_sucs_wrd_colr"></td>
            <td>
                <select data-field="sucs_rt_warn_icon_id" class="icon-select">
                    <option value="">선택 안 함</option>
                    ${allIcons.filter(icon => icon.icon_dsp_yn === true).map(icon => `<option value="${String(icon.icon_id)}" ${icon.icon_id === srWarningIconId ? 'selected' : ''}>${icon.icon_cd}</option>`).join('')}
                </select>
            </td>
            <td><input type="color" value="${setting.sucs_rt_warn_wrd_colr || '#FFA500'}" data-field="sucs_rt_warn_wrd_colr"></td>
            <td><input type="checkbox" ${setting.chrt_dsp_yn === true ? 'checked' : ''} data-field="chrt_dsp_yn"></td>
        `;
    });
    console.log("Settings table rendered.");
}

/**
 * @DOC: 차트/시각화 설정 데이터를 받아 HTML 테이블로 렌더링합니다.
 * @param {Array<Object>} allAdminSettings - 표시할 관리자 설정 데이터 배열.
 */
export function renderChartSettingsTable(allMngrSett) {
    console.log("Rendering chart settings table...");
    chartSettingsTableBody.innerHTML = '';

    if (allMngrSett.length === 0) {
        chartSettingsTableBody.innerHTML = '<tr><td colspan="5" class="text-center py-4">표시할 Job ID가 없습니다.</td></tr>';
        return;
    }

    allMngrSett.forEach(setting => {
        const row = chartSettingsTableBody.insertRow();
        row.dataset.cd = String(setting.cd);

        // chrt_colr가 없으면 랜덤 색상 할당
        const chartColor = setting.chrt_colr || getRandomColorForAdmin();

        row.innerHTML = `
            <td class="job-id-cell">${setting.cd}</td>
            <td><input type="text" value="${setting.cd_nm || setting.cd}" data-field="cd_nm" readonly disabled></td>
            <td><input type="color" value="${chartColor}" data-field="chrt_colr"></td>
            <td><input type="color" value="${setting.grass_chrt_min_colr || '#9be9a8'}" data-field="grass_chrt_min_colr"></td>
            <td><input type="color" value="${setting.grass_chrt_max_colr || '#216e39'}" data-field="grass_chrt_max_colr"></td>
        `;
    });
    console.log("Chart settings table rendered.");
}

/**
 * @DOC: 페이지 내의 모든 아이콘 선택 드롭다운(`<select>`)을 최신 아이콘 목록으로 채웁니다.
 * 아이콘이 추가되거나 수정될 때 호출되어 드롭다운을 동기화합니다.
 * @param {Array<Object>} allIcons - 드롭다운에 표시할 아이콘 데이터 배열.
 * @example
 * // 아이콘 목록이 변경된 후 모든 드롭다운을 업데이트합니다.
 * // populateIconSelects(allIcons);
 */
export function populateIconSelects(allIcons) {
    console.log("Populating icon selects...");
    const iconSelects = document.querySelectorAll('.icon-select');
    iconSelects.forEach(select => {
        const currentSelectedValue = select.value;
        console.log(`  Select element: ${select.dataset.field}, currentSelectedValue: '${currentSelectedValue}' (Type: ${typeof currentSelectedValue})`);
        select.innerHTML = '<option value="">선택 안 함</option>';

        allIcons.filter(icon => icon.icon_dsp_yn === true).forEach(icon => {
            const option = document.createElement('option');
            option.value = String(icon.icon_id);
            option.innerHTML = `${icon.icon_cd}`;
            select.appendChild(option);
        });

        if (currentSelectedValue) {
            const parsedCurrentValue = parseInt(currentSelectedValue);
            console.log(`    Attempting to re-select: parsedCurrentValue: ${parsedCurrentValue}`);

            const targetOption = Array.from(select.options).find(option => parseInt(option.value) === parsedCurrentValue);
            if (targetOption) {
                select.value = targetOption.value;
                console.log(`    Re-selected: ${select.value}`);
            } else {
                select.value = "";
                console.log(`    No matching option found for ${parsedCurrentValue}, setting to '선택 안 함'.`);
            }
        }
    });
    console.log("Icon selects populated.");
}

/**
 * @DOC: 아이콘 관리 탭의 테이블을 렌더링합니다.
 * `allIcons` 배열을 순회하며 각 아이콘 정보를 테이블 행으로 추가하고, 수정/삭제 버튼에 이벤트를 연결합니다.
 * @param {Array<Object>} allIcons - 테이블에 표시할 아이콘 데이터 배열.
 * @example
 * // 아이콘 목록을 받아 아이콘 관리 테이블을 화면에 그립니다.
 * // renderIconTable(allIcons);
 */
export function renderIconTable(allIcons) {
    console.log("Rendering icon table...");
    iconTableBody.innerHTML = '';

    if (allIcons.length === 0) {
        iconTableBody.innerHTML = '<tr><td colspan="6" class="text-center py-4">등록된 아이콘이 없습니다.</td></tr>';
        return;
    }

    allIcons.forEach(icon => {
        const row = iconTableBody.insertRow();
        row.dataset.iconId = icon.icon_id;
        row.innerHTML = `
            <td class="px-4 py-2 border-b">${icon.icon_id}</td>
            <td class="px-4 py-2 border-b"><i class="${icon.icon_cd}"></i> ${icon.icon_cd}</td>
            <td class="px-4 py-2 border-b">${icon.icon_nm}</td>
            <td class="px-4 py-2 border-b">${icon.icon_expl || ''}</td>
            <td class="px-4 py-2 border-b">
                <input type="checkbox" class="toggle-display-yn" data-icon-id="${icon.icon_id}" ${icon.icon_dsp_yn === true ? 'checked' : ''}>
            </td>
            <td class="px-4 py-2 border-b">
                <button class="edit-icon-btn bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-2 rounded-md mr-2" data-icon-id="${icon.icon_id}">수정</button>
                <button class="delete-icon-btn bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded-md" data-icon-id="${icon.icon_id}">삭제</button>
            </td>
        `;
    });

    iconTableBody.querySelectorAll('.toggle-display-yn').forEach(checkbox => {
        checkbox.addEventListener('change', toggleIconDisplayStatus);
    });
    iconTableBody.querySelectorAll('.edit-icon-btn').forEach(button => {
        button.addEventListener('click', (event) => {
            const iconId = parseInt(event.target.dataset.iconId);
            displayIconForm(iconId, allIcons);
        });
    });
    iconTableBody.querySelectorAll('.delete-icon-btn').forEach(button => {
        button.addEventListener('click', (event) => {
            const iconId = parseInt(event.target.dataset.iconId);
            confirmAndDeleteIcon(iconId);
        });
    });
    console.log("Icon list rendered.");
}

/**
 * @DOC: 아이콘 추가 또는 수정을 위한 폼을 화면에 표시합니다.
 * `iconId`가 제공되면 해당 아이콘의 정보로 폼을 채워 '수정' 모드로, `iconId`가 없으면 빈 폼을 '추가' 모드로 엽니다.
 * @param {number|null} iconId - 수정할 아이콘의 ID. 새 아이콘 추가 시에는 null 또는 undefined입니다.
 * @param {Array<Object>} allIcons - 수정할 아이콘 정보를 찾기 위한 전체 아이콘 목록.
 * @example
 * // 새 아이콘을 추가하기 위해 폼을 엽니다.
 * // displayIconForm(null, allIcons);
 * // ID가 5인 아이콘을 수정하기 위해 폼을 엽니다.
 * // displayIconForm(5, allIcons);
 */
export function displayIconForm(iconId, allIcons) {
    const iconFormContainer = document.getElementById('iconFormContainer');
    const iconFormTitle = document.getElementById('iconFormTitle');
    const iconIdField = document.getElementById('iconId');
    const iconCodeField = document.getElementById('iconCode');
    const iconNameField = document.getElementById('iconName');
    const iconDescriptionField = document.getElementById('iconDescription');
    const iconDisplayYnField = document.getElementById('iconDisplayYn');

    if (iconId) {
        iconFormTitle.textContent = '아이콘 수정';
        const icon = allIcons.find(i => i.icon_id === iconId);
        if (icon) {
            iconIdField.value = icon.icon_id;
            iconCodeField.value = icon.icon_cd || '';
            iconNameField.value = icon.icon_nm || '';
            iconDescriptionField.value = icon.icon_expl || '';
            iconDisplayYnField.value = icon.icon_dsp_yn === true ? 'Y' : 'N';
        }
    } else {
        iconFormTitle.textContent = '새 아이콘 추가';
        iconIdField.value = '';
        iconCodeField.value = '';
        iconNameField.value = '';
        iconDescriptionField.value = '';
        iconDisplayYnField.value = 'Y';
    }
    iconFormContainer.classList.remove('hidden');
    saveIconButton.textContent = iconId ? '아이콘 업데이트' : '아이콘 추가';
    cancelEditIconButton.style.display = 'inline-block';
    console.log(`Icon form displayed for ID: ${iconId || 'new'}`);
}

/**
 * @DOC: 아이콘 추가/수정 폼을 화면에서 숨기고 입력 필드를 초기화합니다.
 * @example
 * // 사용자가 '취소' 버튼을 클릭했을 때 폼을 닫습니다.
 * // hideIconForm();
 */
export function hideIconForm() {
    document.getElementById('iconFormContainer').classList.add('hidden');
    iconIdInput.value = '';
    iconCodeInput.value = '';
    iconNameInput.value = '';
    iconDescriptionInput.value = '';
    document.getElementById('iconDisplayYn').value = 'Y';
    saveIconButton.textContent = '아이콘 추가';
    cancelEditIconButton.style.display = 'none';
    console.log("Icon form hidden.");
}
