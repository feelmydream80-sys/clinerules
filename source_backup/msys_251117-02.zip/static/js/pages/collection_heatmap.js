import { fetchWithToken } from "/static/js/modules/fetch.js";

document.addEventListener('DOMContentLoaded', () => {
    const weeklyBtn = document.getElementById('weekly-btn');
    const monthlyBtn = document.getElementById('monthly-btn');
    const calendarGrid = document.getElementById('calendar-grid');
    const summaryStats = document.getElementById('summary-stats');
    const heatmapTitle = document.getElementById('heatmap-title');

    let currentView = 'weekly'; // 'weekly' or 'monthly'

    const renderHeatmap = async () => {
        try {
            const response = await fetchWithToken(`/api/analytics/collection_heatmap?period=${currentView}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            
            updateSummary(data.summary);
            updateCalendar(data.heatmap);
            updateTitle();

        } catch (error) {
            console.error("Error fetching heatmap data:", error);
            calendarGrid.innerHTML = '<p class="text-red-500">데이터를 불러오는 데 실패했습니다.</p>';
        }
    };

    const updateTitle = () => {
        heatmapTitle.textContent = `${currentView === 'weekly' ? '주간' : '월간'} 수집 현황 히트맵`;
    };

    const updateSummary = (summary) => {
        summaryStats.innerHTML = `
            <div>전체 예정: <span class="count">${summary.total}</span></div>
            <div>성공: <span class="count" style="color: #166534;">${summary.success}</span></div>
            <div>실패: <span class="count" style="color: #991b1b;">${summary.fail}</span></div>
            <div>미수집: <span class="count" style="color: #9a3412;">${summary.nodata}</span></div>
        `;
    };

    const updateCalendar = (heatmapData) => {
        calendarGrid.innerHTML = ''; // Clear previous content
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        heatmapData.forEach(dayData => {
            const dayDate = new Date(dayData.date);
            dayDate.setHours(0, 0, 0, 0);

            const isToday = dayDate.getTime() === today.getTime();
            const dayColumn = document.createElement('div');
            dayColumn.className = `day-column ${isToday ? 'today' : ''}`;

            const dayHeader = document.createElement('div');
            dayHeader.className = 'day-header';
            dayHeader.textContent = `${dayData.date_str} (${dayData.day_of_week})`;
            
            const jobsContainer = document.createElement('div');
            jobsContainer.className = 'jobs-container';

            dayData.jobs.forEach(job => {
                const jobPill = document.createElement('div');
                jobPill.className = `job-pill status-${job.status.toLowerCase()}`;
                
                let icon = '';
                switch(job.status) {
                    case 'SUCCESS': icon = '✅'; break;
                    case 'FAIL': icon = '❌'; break;
                    case 'INPROGRESS': icon = '🔵'; break;
                    case 'NODATA': icon = '⚠️'; break;
                }
                jobPill.textContent = `${icon} ${job.job_id}`;
                jobsContainer.appendChild(jobPill);
            });

            dayColumn.appendChild(dayHeader);
            dayColumn.appendChild(jobsContainer);
            calendarGrid.appendChild(dayColumn);
        });
    };

    weeklyBtn.addEventListener('click', () => {
        if (currentView !== 'weekly') {
            currentView = 'weekly';
            weeklyBtn.classList.add('active');
            monthlyBtn.classList.remove('active');
            renderHeatmap();
        }
    });

    monthlyBtn.addEventListener('click', () => {
        if (currentView !== 'monthly') {
            currentView = 'monthly';
            monthlyBtn.classList.add('active');
            weeklyBtn.classList.remove('active');
            renderHeatmap();
        }
    });

    // Initial render
    renderHeatmap();
});
