-- 파일명: sql/card_summary/get_latest_job_status_today.sql
-- 설명: 오늘 날짜(KST)를 기준으로 각 job_id별 가장 마지막 작업 상태를 조회하는 쿼리

WITH latest_records AS (
    -- 각 job_id 별로 가장 마지막 start_dt를 찾음
    SELECT
        job_id,
        MAX(start_dt) AS max_start_dt
    FROM
        tb_con_hist
    WHERE
        -- KST 기준으로 오늘 날짜에 해당하는 데이터만 필터링
        (start_dt AT TIME ZONE 'Asia/Seoul')::date = (NOW() AT TIME ZONE 'Asia/Seoul')::date
    GROUP BY
        job_id
)
-- 위에서 찾은 가장 마지막 start_dt를 가진 레코드의 전체 정보를 조회
SELECT
    t.job_id,
    t.status,
    t.start_dt AT TIME ZONE 'Asia/Seoul' as start_dt_kst,
    t.end_dt AT TIME ZONE 'Asia/Seoul' as end_dt_kst
FROM
    tb_con_hist t
JOIN
    latest_records lr ON t.job_id = lr.job_id AND t.start_dt = lr.max_start_dt
ORDER BY
    t.job_id;
