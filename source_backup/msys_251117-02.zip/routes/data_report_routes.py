from flask import Blueprint, render_template, session, current_app, request, jsonify
from functools import wraps
from .auth_routes import login_required, check_password_change_required
from routes.dashboard_routes import log_menu_access
from service.dashboard_service import DashboardService
from mapper.mst_mapper import MstMapper
from msys.database import get_db_connection
from datetime import datetime, timedelta
import croniter
import pytz

data_report_bp = Blueprint('data_report', __name__)

def data_report_required(f):
    """'data_report' 권한을 확인하는 데코레이터"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session or 'data_report' not in session['user'].get('permissions', []):
            return render_template("unauthorized.html")
        return f(*args, **kwargs)
    return decorated_function

@data_report_bp.route("/data-report")
@login_required
@check_password_change_required
@data_report_required
@log_menu_access
def data_report():
    """데이터 보고 페이지를 렌더링합니다."""
    return render_template("data_report.html")

def get_schedule_and_history(start_date, end_date):
    """
    주어진 기간 동안의 데이터 수집 스케줄과 실제 이력을 조합하여 반환합니다.
    기존 dashboard_service.get_summary()를 재사용하고 결과를 가공합니다.
    """
    with get_db_connection() as conn:
        dashboard_service = DashboardService(conn)
        mst_mapper = MstMapper(conn)
        
        # 전체 기간에 대한 데이터를 한 번에 가져옵니다.
        summary_data = dashboard_service.get_summary(start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'), all_data=False)
        
        # 이력 데이터를 날짜와 job_id 기준으로 쉽게 조회할 수 있도록 가공
        history_map = {}
        for item in summary_data:
            # UTC 시간을 KST로 변환
            start_dt_utc = item.get('min_con_dt')
            if start_dt_utc:
                kst = pytz.timezone('Asia/Seoul')
                start_dt_kst = start_dt_utc.astimezone(kst)
                date_str = start_dt_kst.strftime('%Y-%m-%d')
                
                key = (date_str, item['job_id'])
                history_map[key] = item

    # 스케줄과 이력을 조합할 최종 데이터 구조
    report_data = []
    
    # DB에서 모든 Job 마스터 정보를 가져와서 스케줄링의 기준이 되는 Job 목록을 생성
    all_mst_data = mst_mapper.get_all_mst()
    jobs = {mst['con_id']: mst.get('item6') for mst in all_mst_data if mst.get('item6')}

    current_date = start_date
    while current_date <= end_date:
        date_str = current_date.strftime('%Y-%m-%d')
        for job_id, cron_str in jobs.items():
            try:
                # croniter를 사용하여 해당 날짜에 실행이 예정되어 있는지 확인
                base_time = datetime(current_date.year, current_date.month, current_date.day)
                cron = croniter.croniter(cron_str, base_time)
                
                # 하루 동안의 모든 예정 시간을 확인
                schedule_time = cron.get_next(datetime)
                while schedule_time.date() == current_date:
                    entry = {
                        "date": date_str,
                        "job_id": job_id,
                        "schedule_time": schedule_time.strftime('%H:%M:%S'),
                        "status": "미수집", # 기본 상태
                        "details": {}
                    }

                    # 해당 날짜, 해당 Job의 실제 이력이 있는지 확인
                    history_item = history_map.get((date_str, job_id))
                    if history_item:
                        # 일간 성공/실패 여부를 확인하여 상태 업데이트
                        if history_item.get('day_success', 0) > 0:
                            entry['status'] = '성공'
                        elif history_item.get('day_fail_count', 0) > 0:
                            entry['status'] = '실패'
                        elif history_item.get('day_ing_count', 0) > 0:
                            entry['status'] = '수집중'
                        elif history_item.get('day_no_data_count', 0) > 0:
                            entry['status'] = '미수집'
                        
                        entry['details'] = {
                            'total_count': history_item.get('total_count'),
                            'day_success': history_item.get('day_success'),
                            'day_fail': history_item.get('day_fail_count'),
                        }

                    report_data.append(entry)
                    schedule_time = cron.get_next(datetime)

            except Exception as e:
                # cron 표현식이 잘못된 경우 로그를 남길 수 있음
                current_app.logger.error(f"Error parsing cron string '{cron_str}' for job '{job_id}': {e}")
                pass # 다음 Job으로 계속 진행
        
        current_date += timedelta(days=1)
        
    return report_data

@data_report_bp.route("/api/data-report")
@login_required
def api_data_report():
    """데이터 보고서 데이터를 API로 제공합니다."""
    view_type = request.args.get('view', 'weekly') # 'weekly' or 'monthly'
    
    today = datetime.now(pytz.timezone('Asia/Seoul')).date()
    
    if view_type == 'monthly':
        start_date = today.replace(day=1)
        # 다음 달의 첫 날에서 하루를 빼서 이번 달의 마지막 날을 구함
        next_month = (start_date.replace(day=28) + timedelta(days=4)).replace(day=1)
        end_date = next_month - timedelta(days=1)
    else: # weekly
        start_date = today - timedelta(days=today.weekday())
        end_date = start_date + timedelta(days=6)
        
    try:
        report_data = get_schedule_and_history(start_date, end_date)
        return jsonify(report_data)
    except Exception as e:
        current_app.logger.error(f"Failed to get data report: {e}", exc_info=True)
        return jsonify({"error": "데이터를 조회하는 중 오류가 발생했습니다."}), 500
