from flask import Blueprint, render_template, current_app, request, jsonify, session
from .auth_routes import login_required, check_password_change_required, collection_schedule_required
from routes.dashboard_routes import log_menu_access
from service.dashboard_service import DashboardService
from mapper.mst_mapper import MstMapper
from mapper.user_mapper import UserMapper
from msys.database import get_db_connection
from datetime import datetime, timedelta
import croniter
import pytz
import re
from service.mngr_sett_service import MngrSettService
from typing import Optional, Dict

collection_schedule_bp = Blueprint('collection_schedule', __name__)

@collection_schedule_bp.route("/collection_schedule")
@login_required
@check_password_change_required
@collection_schedule_required
@log_menu_access
def collection_schedule():
    """데이터 수집 일정 페이지를 렌더링합니다."""
    return render_template("collection_schedule.html")

def get_schedule_and_history(start_date, end_date, user: Optional[Dict] = None):
    """
    주어진 기간 동안의 데이터 수집 스케줄과 실제 이력을 조합하여 반환합니다.
    사용자 권한에 따라 표시되는 Job이 필터링됩니다.
    """
    with get_db_connection() as conn:
        dashboard_service = DashboardService(conn)
        mst_mapper = MstMapper(conn)
        user_mapper = UserMapper(conn)

        allowed_job_ids = None
        if user:
            is_admin = 'mngr_sett' in user.get('permissions', [])
            if not is_admin:
                # 로그인 시 세션에 저장된 데이터 접근 권한을 직접 사용합니다.
                allowed_job_ids = user.get('data_permissions', [])
                
                if not allowed_job_ids:
                    return [] # 권한이 없으면 빈 목록 반환
        
        kst = pytz.timezone('Asia/Seoul')
        now_kst = datetime.now(kst)

        all_mst_data = mst_mapper.get_all_mst_for_schedule(allowed_job_ids)
        jobs = {mst['cd']: mst.get('item6') for mst in all_mst_data if mst.get('item6')}
 
        scheduled_tasks = []
        current_date = start_date
        while current_date <= end_date:
            for cd, cron_str in jobs.items():
                if not cron_str or not re.match(r'^(\S+\s+){4,5}\S+$', cron_str.strip()):
                    continue

                try:
                    base_time = datetime(current_date.year, current_date.month, current_date.day)
                    cron = croniter.croniter(cron_str, base_time)
                    schedule_time = cron.get_next(datetime)
                    while schedule_time.date() == current_date:
                        schedule_time_aware = kst.localize(schedule_time)
                        status = "미수집"
                        if schedule_time_aware > now_kst:
                            status = "예정"

                        scheduled_tasks.append({
                            "date": schedule_time.strftime('%Y-%m-%d %H:%M:%S'),
                            "job_id": cd,
                            "cron": cron_str,
                            "status": status,
                        })
                        schedule_time = cron.get_next(datetime)
                except (ValueError, KeyError):
                    current_app.logger.warning(f"Skipping job '{cd}' due to invalid cron string: '{cron_str}'")
                    continue
                except Exception as e:
                    current_app.logger.error(f"Error parsing cron string '{cron_str}' for job '{cd}': {e}")
            current_date += timedelta(days=1)

        history_data = dashboard_service.get_collection_history_for_schedule(start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'), allowed_job_ids)
        
        # 1. 하루에 2회 이상 실행되는 작업 식별
        multi_run_jobs = set()
        for cd, cron_str in jobs.items():
            try:
                base_time = datetime(2023, 1, 1) # 임의의 날짜로 하루 동안의 실행 횟수 계산
                cron = croniter.croniter(cron_str, base_time)
                first_run = cron.get_next(datetime)
                second_run = cron.get_next(datetime)
                if first_run.date() == second_run.date():
                    multi_run_jobs.add(cd)
            except:
                continue

        # 2. 상태 매핑 로직
        # 한 번 실행되는 작업을 위한 history_map
        history_map = {}
        for item in history_data:
            key = (str(item['collection_date']), item['job_id'])
            if item.get('job_id') not in multi_run_jobs:
                 # 가장 심각한 상태로 업데이트 (실패 > 수집중 > 성공)
                current_status = history_map.get(key, '미수집')
                new_status_code = item['status']
                
                status_priority = {'실패': 3, '수집중': 2, '성공': 1, '미수집': 0}
                
                new_status = '미수집'
                if new_status_code == 'CD901': new_status = '성공'
                elif new_status_code == 'CD902': new_status = '수집중'
                elif new_status_code == 'CD903': new_status = '실패'

                if status_priority.get(new_status, 0) > status_priority.get(current_status, 0):
                    history_map[key] = new_status


        kst = pytz.timezone('Asia/Seoul')
        utc = pytz.utc
        
        # 중복 매칭을 피하기 위해 사용 가능한 history_data 복사본 생성
        usable_history = list(history_data)

        for task in scheduled_tasks:
            if task['status'] == '예정':
                continue

            job_id = task['job_id']
            
            if job_id in multi_run_jobs:
                # 여러 번 실행되는 작업: 시간 기반 매핑
                # 'date' field now contains the full datetime string
                schedule_dt_naive = datetime.strptime(task['date'], '%Y-%m-%d %H:%M:%S')
                schedule_dt_aware = kst.localize(schedule_dt_naive)
                
                found_match = False
                for i, history_item in enumerate(usable_history):
                    if history_item['job_id'] != job_id:
                        continue

                    history_dt = history_item.get('start_dt')
                    if not history_dt: continue

                    if history_dt.tzinfo is None:
                        history_dt = utc.localize(history_dt)
                    history_dt_kst = history_dt.astimezone(kst)

                    if abs(schedule_dt_aware - history_dt_kst) <= timedelta(minutes=5):
                        status_code = history_item.get('status')
                        if status_code == 'CD901': task['status'] = '성공'
                        elif status_code == 'CD902': task['status'] = '수집중'
                        elif status_code == 'CD903': task['status'] = '실패'
                        else: task['status'] = '미수집'
                        
                        usable_history.pop(i) # 사용한 기록은 제거
                        found_match = True
                        break
                
                if not found_match:
                    task['status'] = '미수집'
            else:
                # 하루에 한 번 실행되는 작업: 날짜 기반 매핑
                key = (task['date'], job_id)
                task['status'] = history_map.get(key, '미수집')

    # history_data = dashboard_service.get_collection_history_for_schedule(start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'), allowed_job_ids)
    history_data = dashboard_service.get_collection_history_for_schedule_with_start_dt(start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'), allowed_job_ids)
    
    # 1. 하루에 2회 이상 실행되는 작업 식별
    multi_run_jobs = set()
    for cd, cron_str in jobs.items():
        try:
            base_time = datetime(2023, 1, 1) # 임의의 날짜로 하루 동안의 실행 횟수 계산
            cron = croniter.croniter(cron_str, base_time)
            first_run = cron.get_next(datetime)
            second_run = cron.get_next(datetime)
            if first_run.date() == second_run.date():
                multi_run_jobs.add(cd)
        except:
            continue

    # 2. 상태 매핑 로직
    # 한 번 실행되는 작업을 위한 history_map
    history_map = {}
    for item in history_data:
        key = (str(item['collection_date']), item['job_id'])
        if item.get('job_id') not in multi_run_jobs:
             # 가장 심각한 상태로 업데이트 (실패 > 수집중 > 성공)
            current_status = history_map.get(key, '미수집')
            new_status_code = item['status']
            
            status_priority = {'실패': 3, '수집중': 2, '성공': 1, '미수집': 0}
            
            new_status = '미수집'
            if new_status_code == 'CD901': new_status = '성공'
            elif new_status_code == 'CD902': new_status = '수집중'
            elif new_status_code == 'CD903': new_status = '실패'

            if status_priority.get(new_status, 0) > status_priority.get(current_status, 0):
                history_map[key] = new_status


    kst = pytz.timezone('Asia/Seoul')
    utc = pytz.utc
    
    # 중복 매칭을 피하기 위해 사용 가능한 history_data 복사본 생성
    usable_history = list(history_data)

    for task in scheduled_tasks:
        if task['status'] == '예정':
            continue

        job_id = task['job_id']
        
        if job_id in multi_run_jobs:
            # 여러 번 실행되는 작업: 시간 기반 매핑
            # 'date' field now contains the full datetime string
            schedule_dt_naive = datetime.strptime(task['date'], '%Y-%m-%d %H:%M:%S')
            schedule_dt_aware = kst.localize(schedule_dt_naive)
            
            found_match = False
            for i, history_item in enumerate(usable_history):
                if history_item['job_id'] != job_id:
                    continue

                history_dt = history_item.get('start_dt')
                if not history_dt: continue

                if history_dt.tzinfo is None:
                    history_dt = utc.localize(history_dt)
                history_dt_kst = history_dt.astimezone(kst)

                if abs(schedule_dt_aware - history_dt_kst) <= timedelta(minutes=5):
                    status_code = history_item.get('status')
                    if status_code == 'CD901': task['status'] = '성공'
                    elif status_code == 'CD902': task['status'] = '수집중'
                    elif status_code == 'CD903': task['status'] = '실패'
                    else: task['status'] = '미수집'
                    
                    usable_history.pop(i) # 사용한 기록은 제거
                    found_match = True
                    break
            
            if not found_match:
                task['status'] = '미수집'
        else:
            # 하루에 한 번 실행되는 작업: 날짜 기반 매핑
            key = (task['date'], job_id)
            task['status'] = history_map.get(key, '미수집')
    return scheduled_tasks

@collection_schedule_bp.route("/api/collection_schedule")
@login_required
def api_collection_schedule():
    """데이터 수집 일정 데이터를 API로 제공합니다."""
    user = session.get('user')
    view_type = request.args.get('view', 'weekly')
    
    today = datetime.now(pytz.timezone('Asia/Seoul')).date()
    
    if view_type == 'monthly':
        start_date = today.replace(day=1)
        next_month = (start_date.replace(day=28) + timedelta(days=4)).replace(day=1)
        end_date = next_month - timedelta(days=1)
    else: # weekly
        start_date = today - timedelta(days=today.weekday())
        end_date = start_date + timedelta(days=6)
        
    try:
        with get_db_connection() as db_connection:
            mngr_sett_service = MngrSettService(db_connection)
            display_settings = mngr_sett_service.get_schedule_settings_service()
            current_app.logger.info(f"DEBUG_ICON_CHECK: Fetched display_settings from service: {display_settings}")
        
        report_data = get_schedule_and_history(start_date, end_date, user)
        
        response_data = {
            "schedule_data": report_data,
            "display_settings": display_settings
        }
        
        current_app.logger.info(f"DEBUG_ICON_CHECK: Final response_data to be sent: {response_data}")
        return jsonify(response_data)
    except Exception as e:
        current_app.logger.error(f"Failed to get data report: {e}", exc_info=True)
        return jsonify({"error": "데이터를 조회하는 중 오류가 발생했습니다."}), 500
