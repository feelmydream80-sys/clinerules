// @DOC_FILE: ui.js (chart_analysis)
// @DOC_DESC: 이 파일은 분석 페이지의 UI 렌더링, 초기화, 및 차트 생성을 담당합니다.
// Job ID 체크박스 생성, 날짜 선택기 초기화, 차트 렌더링 로직을 포함합니다.

import { allJobMstList } from './data.js';
import { loadAnalyticsPageData } from './events.js';

// @DOC: 차트 인스턴스를 저장하여 이전 차트를 파괴하고 새로 그릴 수 있도록 합니다.
let successRateChart = null;
let troublePieChart = null;

// @DOC: 관리자 설정에 색상이 지정되지 않았을 경우 사용할 기본 차트 색상 팔레트입니다.
const DEFAULT_CHART_COLORS = [
    'rgb(255, 99, 132)', 'rgb(54, 162, 235)', 'rgb(255, 206, 86)',
    'rgb(75, 192, 192)', 'rgb(153, 102, 255)', 'rgb(255, 159, 64)',
    'rgb(201, 203, 207)', 'rgb(23, 162, 184)', 'rgb(108, 117, 125)',
    'rgb(0, 123, 255)'
];

// @DOC: 장애 코드별로 고정된 색상을 매핑하여 차트의 일관성을 유지합니다.
const errorCodeColorMap = {
    'CD901': '#22c55e', // 정상(성공)
    'CD902': '#ef4444', // 실패
    'CD903': '#f59e42', // 미수집
    'CD904': '#22c55e', // 계측중
};

/**
 * @DOC: Job ID 목록을 받아 동적으로 체크박스를 생성하고 컨테이너에 추가합니다.
 * @param {Array<Object>} mstList - Job ID와 이름이 포함된 객체 배열.
 */
export function renderJobCheckboxes(mstList) {
    const jobCheckboxesContainer = document.getElementById('jobCheckboxes');
    if (!jobCheckboxesContainer) {
        console.error("Error: jobCheckboxes container not found.");
        return;
    }
    jobCheckboxesContainer.innerHTML = '';

    mstList.forEach(job => {
        if (job.job_id) {
            const label = document.createElement('label');
            label.className = 'job-checkbox-label';
            label.innerHTML = `
                <input type="checkbox" class="job-checkbox form-checkbox text-blue-600 mr-2" value="${job.job_id}" checked>
                <span>${job.cd || job.job_id}</span>
            `;
            jobCheckboxesContainer.appendChild(label);
        }
    });

    jobCheckboxesContainer.querySelectorAll('.job-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', loadAnalyticsPageData);
    });
    console.log("Job ID checkboxes rendered.");
}

/**
 * @DOC: Luxon 라이브러리를 사용하여 시작일과 종료일 날짜 선택기를 초기화하고 이벤트 리스너를 설정합니다.
 */
export function initializeDatePickers(adminSettings) {
    const startDatePicker = document.getElementById('startDate');
    const endDatePicker = document.getElementById('endDate');

    const currentYear = luxon.DateTime.local().year;
    const defaultStartDate = luxon.DateTime.local().set({ year: currentYear, month: 1, day: 1 }).toISODate();
    const defaultEndDate = luxon.DateTime.local().toISODate();

    if (startDatePicker) startDatePicker.value = defaultStartDate;
    if (endDatePicker) endDatePicker.value = defaultEndDate;

    if (startDatePicker) startDatePicker.addEventListener('change', () => loadAnalyticsPageData(adminSettings));
    if (endDatePicker) endDatePicker.addEventListener('change', () => loadAnalyticsPageData(adminSettings));
    console.log("Date pickers initialized for analytics.");
}

/**
 * @DOC: 차트 타입(라인/바, 도넛/바)을 선택하는 라디오 버튼에 이벤트 리스너를 설정합니다.
 */
export function initializeChartTypeRadios(adminSettings) {
    document.querySelectorAll('input[name="successChartType"]').forEach(radio => {
        radio.addEventListener('change', () => loadAnalyticsPageData(adminSettings));
    });
    document.querySelectorAll('input[name="troubleChartType"]').forEach(radio => {
        radio.addEventListener('change', () => loadAnalyticsPageData(adminSettings));
    });
    console.log("Chart type radios initialized.");
}

/**
 * @DOC: Chart.js를 사용하여 기간별 수집 성공률 차트를 렌더링합니다.
 * @param {Array<Object>} data - API로부터 받은 원본 차트 데이터.
 * @param {string} chartType - 'line' 또는 'bar'.
 */
export function renderSuccessRateChart(data, chartType, adminSettings) {
    const ctx = document.getElementById('successRateChart')?.getContext('2d');
    if (!ctx) {
        console.error("Success Rate Chart canvas element not found.");
        return;
    }

    if (successRateChart) {
        successRateChart.destroy();
    }

    const groupedData = data.reduce((acc, item) => {
        const jobId = String(item.job_id);
        if (!acc[jobId]) {
            acc[jobId] = [];
        }
        acc[jobId].push(item);
        return acc;
    }, {});

    const allDates = [...new Set(data.map(item => luxon.DateTime.fromHTTP(item.date).toISODate()))].sort();

    const datasets = Object.keys(groupedData).map((jobIdKey, index) => {
        const actualJobId = (jobIdKey === 'undefined' || jobIdKey === 'null' || !jobIdKey) ? 'UNKNOWN_JOB' : jobIdKey;
        const jobData = groupedData[jobIdKey].sort((a, b) => luxon.DateTime.fromHTTP(a.date).toISODate().localeCompare(luxon.DateTime.fromHTTP(b.date).toISODate()));
        
        const dataPoints = allDates.map(date => {
            const item = jobData.find(d => luxon.DateTime.fromHTTP(d.date).toISODate() === date);
            return item ? parseFloat(item.success_rate) : (chartType === 'line' ? null : 0);
        });

        const adminSetting = adminSettings.find(setting => setting.cd === actualJobId);
        const dynamicColor = adminSetting?.chrt_colr || DEFAULT_CHART_COLORS[index % DEFAULT_CHART_COLORS.length];
        
        const jobMst = allJobMstList.find(mst => mst.job_id === actualJobId);
        const displayLabel = jobMst?.cd || actualJobId;

        return {
            label: displayLabel,
            data: dataPoints,
            borderColor: dynamicColor,
            backgroundColor: dynamicColor.replace('rgb', 'rgba').replace(')', ', 0.5)'),
            tension: 0.1,
            fill: false,
            spanGaps: chartType === 'line',
            datalabels: { display: false }
        };
    });

    successRateChart = new Chart(ctx, {
        type: chartType,
        data: { labels: allDates, datasets: datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, max: 100, title: { display: true, text: '성공률 (%)' } },
                x: { title: { display: true, text: '날짜' }, type: 'category', ticks: { autoSkip: true, maxTicksLimit: 20 } }
            },
            plugins: {
                tooltip: {
                    enabled: true, mode: 'nearest', intersect: false,
                    callbacks: {
                        label: context => `${context.dataset.label}: ${context.raw !== null ? parseFloat(context.raw).toFixed(2) : 'N/A'}%`
                    }
                },
                datalabels: { display: false },
                title: { display: true, text: '기간별 Job ID별 수집 성공률 추이' }
            },
            elements: { point: { radius: 0, hitRadius: 0 } },
            animation: { duration: 1000 }
        }
    });
    console.log("Success Rate Chart rendered.");
}

/**
 * @DOC: Chart.js를 사용하여 장애 코드별 비율 차트를 렌더링합니다.
 * @param {Array<Object>} troubleCodeData - API로부터 받은 장애 코드 데이터.
 * @param {string} chartType - 'doughnut' 또는 'bar'.
 * @param {string} startDate - 조회 시작일.
 * @param {string} endDate - 조회 종료일.
 */
export function renderTroublePieChart(troubleCodeData, chartType, startDate, endDate, adminSettings) {
    const ctx = document.getElementById('troublePieChart').getContext('2d');
    const chartContainer = ctx.canvas.parentElement;

    if (!troubleCodeData || troubleCodeData.length === 0) {
        ctx.canvas.style.display = 'none';
        let noDataMsg = document.getElementById('troublePieNoDataMsg');
        if (!noDataMsg) {
            noDataMsg = document.createElement('div');
            noDataMsg.id = 'troublePieNoDataMsg';
            noDataMsg.className = 'text-center text-gray-500 my-8';
            chartContainer.appendChild(noDataMsg);
        }
        noDataMsg.textContent = `장애 코드 없음 (조회 기간: ${startDate} ~ ${endDate})`;
        return;
    }
    
    ctx.canvas.style.display = '';
    const noDataMsg = document.getElementById('troublePieNoDataMsg');
    if (noDataMsg) noDataMsg.remove();

    const labels = troubleCodeData.map(item => item.error_code || '알 수 없음');
    const dataValues = troubleCodeData.map(item => item.count || 0);
    
    const getColorForErrorCode = (errorCode) => {
        if (!adminSettings || adminSettings.length === 0) {
            return errorCodeColorMap[errorCode] || '#a3a3a3';
        }
        const setting = adminSettings[0]; // Assuming global color settings from the first entry
        switch (errorCode) {
            case 'CD901': return setting.cnn_sucs_wrd_colr;
            case 'CD902': return setting.cnn_failr_wrd_colr;
            case 'CD903': return setting.cnn_warn_wrd_colr;
            case 'CD904': return '#84cc16'; // @FIX: CD904(계측중)를 연두색으로 변경
            default: return '#a3a3a3';
        }
    };

    const backgroundColors = troubleCodeData.map(item => getColorForErrorCode(item.error_code));

    if (troublePieChart) {
        troublePieChart.destroy();
    }

    troublePieChart = new Chart(ctx, {
        type: chartType,
        data: {
            labels: labels,
            datasets: [{ data: dataValues, backgroundColor: backgroundColors }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    callbacks: {
                        label: context => {
                            const sum = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = (context.raw * 100 / sum).toFixed(2) + "%";
                            return `${context.label}: ${context.raw}건 (${percentage})`;
                        }
                    }
                },
                legend: { position: 'top' },
                title: { display: true, text: '장애 코드별 비율' }
            },
            animation: { duration: 1000 }
        }
    });
    console.log("Trouble Pie Chart rendered.");
}
