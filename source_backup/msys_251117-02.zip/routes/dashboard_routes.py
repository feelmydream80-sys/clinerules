from flask import Blueprint, request, jsonify, render_template, session, current_app
import logging
from datetime import datetime, timedelta
from functools import wraps
import pytz
from .auth_routes import login_required, check_password_change_required

from service.dashboard_service import DashboardService
from msys.database import get_db_connection
from dao.analytics_dao import AnalyticsDAO

dashboard_bp = Blueprint('dashboard', __name__)

def dashboard_required(f):
    """'dashboard' 권한을 확인하는 데코레이터"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session or 'dashboard' not in session['user'].get('permissions', []):
            return render_template("unauthorized.html")
        return f(*args, **kwargs)
    return decorated_function

def log_menu_access(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            user_id = session.get('user', {}).get('user_id')
            endpoint = request.endpoint
            
            if user_id and endpoint:
                menu_to_log = endpoint  # 기본값으로 엔드포인트 이름 사용
                
                # 엔드포인트에서 메뉴 ID 추출 (예: 'dashboard.dashboard' -> 'dashboard')
                menu_id = endpoint.split('.')[0]

                # 앱 컨텍스트에 캐시된 메뉴 데이터에서 메뉴 이름 찾기
                menu_items = getattr(current_app, 'menu_items', [])
                menu_item = next((item for item in menu_items if item.get('menu_id') == menu_id), None)
                
                if menu_item and menu_item.get('menu_nm'):
                    menu_to_log = menu_item['menu_nm']
                else:
                    current_app.logger.warning(f"캐시에서 menu_id '{menu_id}'에 해당하는 메뉴 이름을 찾을 수 없습니다. 엔드포인트 '{endpoint}'를 기본값으로 사용합니다.")

                # 로그 삽입
                with get_db_connection() as conn:
                    analytics_dao = AnalyticsDAO(conn)
                    analytics_dao.insert_user_access_log(user_id, menu_to_log)
        except Exception as e:
            current_app.logger.error(f"메뉴 접근 로그 기록 실패 (엔드포인트: {request.endpoint}): {e}")
        
        return f(*args, **kwargs)
    return decorated_function

@dashboard_bp.route("/")
@dashboard_bp.route("/dashboard")
@login_required
@check_password_change_required
@dashboard_required
@log_menu_access
def dashboard():
    current_app.logger.info(f"--- [LOG] Initial access to root or dashboard route: {request.path}")
    user_permissions = session.get('user', {}).get('permissions', [])
    is_admin = 'mngr_sett' in user_permissions
    return render_template("dashboard.html", now=datetime.utcnow(), is_admin=is_admin)

@dashboard_bp.route('/api/dashboard/summary', methods=['GET'])
@login_required
@check_password_change_required
def get_dashboard_summary():
    """
    대시보드 요약 데이터를 제공하는 API.
    """
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date_str = request.args.get('start_date')
            end_date_str = request.args.get('end_date')
            all_data_str = request.args.get('all_data', 'false')
            all_data = all_data_str.lower() == 'true'

            if not all_data:
                if not start_date_str or not end_date_str:
                    return jsonify({"message": "시작 및 종료 날짜가 필요합니다."}), 400
                try:
                    start_date_obj = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                    end_date_obj = datetime.strptime(end_date_str, '%Y-%m-%d').date()
                    if start_date_obj > end_date_obj:
                        return jsonify({"message": "시작 날짜는 종료 날짜보다 빠를 수 없습니다."}), 400
                    
                    # Add one day to the end date to include all data of the selected day
                    end_date_obj += timedelta(days=1)
                    end_date_str = end_date_obj.strftime('%Y-%m-%d')
                except ValueError:
                    return jsonify({"message": "날짜 형식이 유효하지 않습니다.YYYY-MM-DD 형식을 사용해주세요."}), 400

            summary_data = dashboard_service.get_summary(start_date_str, end_date_str, all_data)
            
            # Convert datetime objects to KST strings before jsonify
            kst = pytz.timezone('Asia/Seoul')
            utc = pytz.utc
            for item in summary_data:
                for key, value in item.items():
                    if isinstance(value, datetime):
                        # Naive datetime을 UTC로 간주하고 KST로 변환
                        if value.tzinfo is None:
                            value = utc.localize(value)
                        item[key] = value.astimezone(kst).strftime('%Y-%m-%d %H:%M:%S')
                    elif value is None:
                        item[key] = ''

            return jsonify(summary_data), 200
    except Exception as e:
        logging.error(f"❌ API: 대시보드 요약 데이터 조회 실패: {e}", exc_info=True)
        return jsonify({"message": "데이터 조회 중 오류가 발생했습니다."}), 500

@dashboard_bp.route('/api/dashboard/day-stats/<string:date_str>', methods=['GET'])
@login_required
@check_password_change_required
def get_day_stats_api(date_str):
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            # This service method might be deprecated or needs refactoring.
            # For now, assuming it might be removed or changed.
            # day_stats = dashboard_service.get_day_stats(date_str)
            # return jsonify(day_stats), 200
            return jsonify([]), 200 # Returning empty list as the service method was removed
    except Exception as e:
        logging.error(f"❌ API: 일별 통계 조회 실패: {e}", exc_info=True)
        return jsonify({"message": "일별 통계 조회 중 오류가 발생했습니다."}), 500

@dashboard_bp.route('/api/dashboard/min-max-dates', methods=['GET'])
@login_required
@check_password_change_required
def get_min_max_dates_api():
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            dates = dashboard_service.get_min_max_dates()
            return jsonify(dates or {"min_date": None, "max_date": None}), 200
    except Exception as e:
        logging.error(f"❌ API: 최소/최대 날짜 조회 실패: {e}", exc_info=True)
        return jsonify({"message": "최소/최대 날짜 조회 중 오류가 발생했습니다."}), 500

@dashboard_bp.route('/api/dashboard/event-log', methods=['GET'])
@login_required
@check_password_change_required
def get_event_log_api():
    """
    이벤트 로그 데이터를 제공하는 API.
    """
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date_str = request.args.get('start_date')
            end_date_str = request.args.get('end_date')
            all_data_str = request.args.get('all_data', 'false')
            all_data = all_data_str.lower() == 'true'

            if not all_data:
                if not start_date_str or not end_date_str:
                    return jsonify({"message": "시작 및 종료 날짜가 필요합니다."}), 400
                try:
                    start_date_obj = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                    end_date_obj = datetime.strptime(end_date_str, '%Y-%m-%d').date()
                    if start_date_obj > end_date_obj:
                        return jsonify({"message": "시작 날짜는 종료 날짜보다 빠를 수 없습니다."}), 400
                except ValueError:
                    return jsonify({"message": "날짜 형식이 유효하지 않습니다.YYYY-MM-DD 형식을 사용해주세요."}), 400

            event_log_data = dashboard_service.get_event_log(start_date_str, end_date_str, all_data)
            
            # Convert datetime objects to KST strings before jsonify
            kst = pytz.timezone('Asia/Seoul')
            utc = pytz.utc
            for item in event_log_data:
                for key, value in item.items():
                    if isinstance(value, datetime):
                        # Naive datetime을 UTC로 간주하고 KST로 변환
                        if value.tzinfo is None:
                            value = utc.localize(value)
                        item[key] = value.astimezone(kst).strftime('%Y-%m-%d %H:%M:%S')
                    elif value is None:
                        item[key] = ''

            return jsonify(event_log_data), 200
    except Exception as e:
        logging.error(f"❌ API: 이벤트 로그 데이터 조회 실패: {e}", exc_info=True)
        return jsonify({"message": "데이터 조회 중 오류가 발생했습니다."}), 500
