# mapper/user_mapper.py
"""
사용자 정보 관련 데이터 변환을 책임지는 매퍼 계층입니다.
"""
import logging
from typing import List, Dict, Any
from msys.database import get_db_connection
from sql.user.user_sql import UserSQL

class UserMapper:
    def __init__(self, db_connection):
        self.conn = db_connection

    def find_by_id(self, user_id: str) -> Dict[str, Any]:
        with self.conn.cursor() as cur:
                cur.execute(UserSQL.find_by_id(), (user_id,))
                columns = [desc[0] for desc in cur.description]
                row = cur.fetchone()
                if not row:
                    return None
                user = dict(zip(columns, row))
                return user

    def find_all(self) -> List[Dict[str, Any]]:
        with self.conn.cursor() as cur:
                cur.execute(UserSQL.find_all())
                columns = [desc[0] for desc in cur.description]
                rows = cur.fetchall()
                users = [dict(zip(columns, row)) for row in rows]
                from msys.column_mapper import convert_to_new_columns
                return convert_to_new_columns('TB_USER', users)

    def delete_by_id(self, user_id: str) -> None:
        with self.conn.cursor() as cur:
            cur.execute(UserSQL.delete_by_id(), (user_id,))

    def save(self, user_id: str, hashed_password: str) -> None:
        with self.conn.cursor() as cur:
            cur.execute(UserSQL.save(), (user_id, hashed_password))

    def update_status(self, user_id: str, status: str) -> None:
        with self.conn.cursor() as cur:
            cur.execute(UserSQL.update_status(), (status, user_id))

    def update_password(self, user_id: str, hashed_password: str) -> None:
        with self.conn.cursor() as cur:
            cur.execute(UserSQL.update_password(), (hashed_password, user_id))

    def find_user_permissions(self, user_id: str) -> List[str]:
        with self.conn.cursor() as cur:
                cur.execute(UserSQL.find_user_permissions(), (user_id,))
                return [row[0] for row in cur.fetchall()]

    def find_all_permissions(self) -> List[Dict[str, Any]]:
        with self.conn.cursor() as cur:
                cur.execute(UserSQL.find_all_permissions())
                columns = [desc[0] for desc in cur.description]
                rows = cur.fetchall()
                permissions = [dict(zip(columns, row)) for row in rows]
                from msys.column_mapper import convert_to_new_columns
                return convert_to_new_columns('TB_USER_AUTH_CTRL', permissions)

    def find_all_menus(self) -> List[Dict[str, Any]]:
        with self.conn.cursor() as cur:
                cur.execute(UserSQL.find_all_menus())
                columns = [desc[0] for desc in cur.description]
                rows = cur.fetchall()
                menus = [dict(zip(columns, row)) for row in rows]
                from msys.column_mapper import convert_to_new_columns
                return convert_to_new_columns('TB_MENU', menus)

    def update_user_permissions(self, user_id: str, menu_ids: List[str]) -> None:
        with self.conn.cursor() as cur:
            # 먼저 해당 사용자의 모든 권한을 삭제합니다.
            cur.execute(UserSQL.delete_user_permissions(), (user_id,))
            
            # menu_ids 리스트에 값이 있는 경우, 새로운 권한을 추가합니다.
            if menu_ids:
                # executemany를 위한 데이터 리스트 생성 (user_id, menu_id) 튜플의 리스트
                permission_data = [(user_id, menu_id) for menu_id in menu_ids]
                # executemany를 사용하여 여러 권한을 한 번에 INSERT
                cur.executemany(UserSQL.insert_user_permission(), permission_data)

    def find_user_menus_sorted(self, user_id: str) -> List[Dict[str, Any]]:
        with self.conn.cursor() as cur:
            cur.execute(UserSQL.find_user_menus_sorted(), (user_id,))
            columns = [desc[0] for desc in cur.description]
            rows = cur.fetchall()
            menus = [dict(zip(columns, row)) for row in rows]
            return menus
