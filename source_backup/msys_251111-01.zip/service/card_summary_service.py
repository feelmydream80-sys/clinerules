# service/card_summary_service.py
from collections import defaultdict
from service.dashboard_service import DashboardService
from datetime import datetime
from zoneinfo import ZoneInfo
from flask import current_app

class CardSummaryService:
    def __init__(self, db_connection):
        self.dashboard_service = DashboardService(db_connection)

    def get_card_summary(self):
        """
        Gets the latest job status for today and formats it for the card summary view.
        """
        # 1. Get today's raw data using the new flag
        job_statuses_today = self.dashboard_service.get_raw_data(use_kst_today=True)
        current_app.logger.debug(f"--- [DEBUG] CardSummaryService: Fetched {len(job_statuses_today)} jobs for today from DB.")

        # 2. Find the latest status for each job
        latest_statuses = {}
        for job in job_statuses_today:
            job_id = job.get('job_id')
            start_dt = job.get('start_dt')

            if not job_id or not isinstance(start_dt, datetime):
                continue

            if job_id not in latest_statuses or start_dt > latest_statuses[job_id]['start_dt']:
                latest_statuses[job_id] = job

        job_statuses = list(latest_statuses.values())
        current_app.logger.debug(f"--- [DEBUG] CardSummaryService: Found {len(job_statuses)} unique latest jobs for today.")
        
        # 4. Build summary data
        summary_data = defaultdict(lambda: {
            "success": {"count": 0, "jobs": []},
            "progress": {"count": 0, "jobs": []},
            "fail": {"count": 0, "jobs": []}
        })

        for job in job_statuses:
            job_id = job['job_id']
            status = job['status']
            
            if job_id and job_id.startswith('CD'):
                group = f"CD{job_id[2]}00" # e.g., CD101 -> CD100
                
                if status == 'success' or status == 'CD901':
                    summary_data[group]['success']['count'] += 1
                    summary_data[group]['success']['jobs'].append(job_id)
                elif status == 'processing' or status == 'CD904':
                    summary_data[group]['progress']['count'] += 1
                    summary_data[group]['progress']['jobs'].append(job_id)
                else: # fail, error, etc.
                    summary_data[group]['fail']['count'] += 1
                    summary_data[group]['fail']['jobs'].append(job_id)

        current_app.logger.debug(f"--- [DEBUG] CardSummaryService: Processed summary data: {dict(summary_data)}")
        return summary_data
