-- sql/mngr_sett/get_schedule_settings.sql
SELECT
    sett_id,
    grp_min_cnt,
    prgs_rt_red_thrsval,
    prgs_rt_org_thrsval,
    use_yn
FROM
    tb_data_clt_schd_sett
ORDER BY
    updr_dt DESC, sett_id DESC
LIMIT 1;