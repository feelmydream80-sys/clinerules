import logging
from mapper.icon_mapper import IconMapper

class IconService:
    def __init__(self, db_connection):
        self.conn = db_connection
        self.icon_mapper = IconMapper(db_connection)

    def get_icon_mappings(self) -> tuple[dict, dict]:
        try:
            all_icons = self.icon_mapper.get_all_icons()
            emoji_to_int = {}
            int_to_emoji = {}
            for icon in all_icons:
                icon_code = icon.get('ICON_CD')
                icon_id = icon.get('ICON_ID')
                if icon_code and icon_id is not None:
                    emoji_to_int[icon_code] = icon_id
                    int_to_emoji[icon_id] = icon_code
            
            logging.debug(f"IconService.get_icon_mappings - Generated EMOJI_TO_INT: {emoji_to_int}")
            logging.debug(f"IconService.get_icon_mappings - Generated INT_TO_EMOJI: {int_to_emoji}")
            return emoji_to_int, int_to_emoji
        except Exception as e:
            logging.error(f"❌ 아이콘 매핑 로드 실패: {e}", exc_info=True)
            raise

    def get_all_icons_data(self) -> list[dict]:
        try:
            return self.icon_mapper.get_all_icons()
        except Exception as e:
            logging.error(f"❌ 아이콘 데이터 로드 실패 (관리 탭): {e}", exc_info=True)
            return []

    def insert_or_update_icon(self, icon_data: dict):
        try:
            if 'ICON_DSP_YN' not in icon_data:
                icon_data['ICON_DSP_YN'] = 'Y' if icon_data.get('ICON_DSP_YN', True) else 'N'
            
            self.icon_mapper.insert_or_update_icon(icon_data)
        except Exception as e:
            logging.error(f"❌ 아이콘 삽입/업데이트 실패 (데이터: {icon_data}): {e}", exc_info=True)
            raise

    def delete_icon(self, icon_id: int):
        try:
            self.icon_mapper.delete_icon(icon_id)
        except Exception as e:
            logging.error(f"❌ 아이콘 삭제 서비스 실패 (ID: {icon_id}): {e}", exc_info=True)
            raise

    def toggle_icon_display(self, icon_id: int, display_yn: str):
        try:
            # Convert boolean to 'Y'/'N' if necessary
            status_str = display_yn if isinstance(display_yn, str) else ('Y' if display_yn else 'N')
            self.icon_mapper.toggle_icon_display(icon_id, status_str)
        except Exception as e:
            logging.error(f"❌ 아이콘 ID {icon_id} 표시 여부 상태 토글 실패: {e}", exc_info=True)
            raise
