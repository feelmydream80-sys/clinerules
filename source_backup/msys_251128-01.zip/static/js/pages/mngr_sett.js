// @DOC_FILE: mngr_sett.js
// @DOC_DESC: 관리자 설정 페이지의 메인 JavaScript 파일. 각 탭의 UI와 이벤트 로직을 관리합니다.

// import { showMessage } from '../modules/common/utils.js'; // toast.js를 직접 사용
import { setDataFlowStatus } from '../modules/common/api/client.js';
import { setupTabs, renderSettingsTable, renderIconTable, populateIconSelects } from '../modules/mngr_sett/ui.js';
import { getAdminSettings, getIcons } from '../modules/mngr_sett/data.js';
import { 
    initializeIconManagementUI, 
    saveBasicSettings,
    saveChartSettings,
    exportSettings, 
    importSettings,
    exportIcons,
    importIcons
} from '../modules/mngr_sett/events.js';

// --- START: Statistics Tab Logic ---

// DOM Elements for Statistics Tab
const statsElements = {
    tab: null,
    dailyViewRadio: null,
    weeklyMonthlyViewRadio: null,
    comparisonViewRadio: null, // Added for comparison view
    yearSelect: null,
    menuSelect: null,
    dateRangeContainer: null,
    startDateInput: null,
    endDateInput: null,
    filterBtn: null,
    excelDownloadBtn: null,
    dailyViewContainer: null,
    weeklyMonthlyViewContainer: null,
    comparisonViewContainer: null, // Added for comparison view
    summaryContainer: null,
    dailyTableBody: null,
    weeklyTable: null,
    comparisonTable: null, // Added for comparison view
    comparisonYearLegend: null, // Added for year legend
    chartCanvas: null,
    chartInstance: null
};

/**
 * Initializes the statistics tab functionality.
 */
async function initStatisticsTab() {
    // 1. Assign DOM elements
    Object.keys(statsElements).forEach(key => {
        const id = {
            tab: 'button[data-tab="statistics"]',
            dailyViewRadio: 'dailyViewRadio',
            weeklyMonthlyViewRadio: 'weeklyMonthlyViewRadio',
            comparisonViewRadio: 'comparisonViewRadio',
            yearSelect: 'statsYearSelect',
            menuSelect: 'statsMenuSelect',
            dateRangeContainer: 'statsDateRangeContainer',
            startDateInput: 'statsStartDate',
            endDateInput: 'statsEndDate',
            filterBtn: 'statsFilterBtn',
            excelDownloadBtn: 'statsExcelDownloadBtn',
            dailyViewContainer: 'dailyViewContainer',
            weeklyMonthlyViewContainer: 'weeklyMonthlyViewContainer',
            comparisonViewContainer: 'comparisonViewContainer',
            summaryContainer: 'statsSummary',
            dailyTableBody: 'menuStatsTableBody',
            weeklyTable: 'weeklyMonthlyStatsTable',
            comparisonTable: 'comparisonStatsTable',
            comparisonYearLegend: 'comparisonYearLegend',
            chartCanvas: 'accessStatsChart'
        }[key];
        const container = document.getElementById('mngr_sett_page');
        if (!container) return;
        statsElements[key] = container.querySelector(`#${id}`) || container.querySelector(id);
    });

    if (!statsElements.tab) return; // Statistics tab not present

    // 2. Add event listeners
    if (statsElements.tab) {
        statsElements.tab.addEventListener('click', () => {
            loadStatisticsConfig();
        });
    }
    if (statsElements.excelDownloadBtn) statsElements.excelDownloadBtn.addEventListener('click', downloadExcel);
    
    const autoLoadStats = () => {
        toggleStatsView();
        loadStatisticsData();
    };

    if (statsElements.dailyViewRadio) statsElements.dailyViewRadio.addEventListener('change', autoLoadStats);
    if (statsElements.weeklyMonthlyViewRadio) statsElements.weeklyMonthlyViewRadio.addEventListener('change', autoLoadStats);
    if (statsElements.comparisonViewRadio) statsElements.comparisonViewRadio.addEventListener('change', autoLoadStats);
    if (statsElements.yearSelect) statsElements.yearSelect.addEventListener('change', loadStatisticsData);
    if (statsElements.menuSelect) statsElements.menuSelect.addEventListener('change', loadStatisticsData);
    if (statsElements.startDateInput) statsElements.startDateInput.addEventListener('change', loadStatisticsData);


    // 3. Set initial UI state
    const today = new Date().toISOString().split('T')[0];
    statsElements.startDateInput.value = today;
    // statsElements.endDateInput.value = today; // endDateInput is removed
    toggleStatsView();
}

/**
 * Fetches configuration data (years, menus) and populates the dropdowns.
 */
async function loadStatisticsConfig() {
    // Prevent re-loading config if already populated
    if (statsElements.yearSelect.options.length > 0) {
        loadStatisticsData(); // If config is loaded, just fetch data
        return;
    }

    try {
        const response = await fetch('/api/statistics/config');
        if (!response.ok) throw new Error('Failed to load statistics config');
        const config = await response.json() || {};

        // API 응답은 정상(200 OK)이지만, 내용이 비어있거나 예상과 다른 형식일 경우를 대비
        if (!config.years || !config.menus) {
            // 빈 데이터로 테이블을 그려서 UI가 깨지는 것을 방지
            renderDailyStats({ menu_access_stats: [], total_access_stats: {} }, []);
            throw new Error('통계 설정 데이터가 비어있거나 형식이 올바르지 않습니다.');
        }

        // Populate year dropdown
        statsElements.yearSelect.innerHTML = '';
        config.years.forEach(year => {
            const option = new Option(`${year}년`, year);
            statsElements.yearSelect.add(option);
        });

        // Populate menu dropdown
        statsElements.menuSelect.innerHTML = '';
        statsElements.menuSelect.add(new Option('전체 메뉴', 'all'));
        config.menus.forEach(menu => {
            const option = new Option(menu.menu_nm, menu.menu_id);
            statsElements.menuSelect.add(option);
        });

        // Render the initial state of the daily stats table with all menus
        renderDailyStats({ menu_access_stats: [], total_access_stats: {} }, config.menus);

        // Load data after populating filters
        loadStatisticsData();

    } catch (error) {
        console.error('Error loading statistics config:', error);
        showToast(error.message, 'error');
        // 오류 발생 시, 빈 데이터로 통계 UI를 초기화하여 깨진 상태로 두지 않도록 함
        renderDailyStats({ menu_access_stats: [], total_access_stats: {} }, []);
    }
}

/**
 * Toggles the view between daily, weekly/monthly, and comparison.
 */
function toggleStatsView() {
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;
    const viewType = container.querySelector('input[name="statsViewType"]:checked')?.value;

    const showIf = (element, condition) => {
        if (element) element.style.display = condition ? (element.tagName === 'DIV' ? 'block' : 'flex') : 'none';
    };

    showIf(statsElements.dailyViewContainer, viewType === 'daily');
    showIf(statsElements.weeklyMonthlyViewContainer, viewType === 'weekly_monthly');
    showIf(statsElements.comparisonViewContainer, viewType === 'comparison');
    
    showIf(statsElements.dateRangeContainer, viewType === 'daily');
    showIf(statsElements.yearSelect, viewType === 'weekly_monthly' || viewType === 'comparison');
    
    if (statsElements.menuSelect) statsElements.menuSelect.style.display = 'none'; // Always hide for now
    if (statsElements.excelDownloadBtn) statsElements.excelDownloadBtn.style.display = 'inline-block'; // Always show
}

/**
 * Fetches and renders the main statistics data based on current filter settings.
 */
async function loadStatisticsData() {
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;
    const viewType = container.querySelector('input[name="statsViewType"]:checked').value;
    const params = new URLSearchParams({ view_type: viewType });

    if (viewType === 'daily') {
        const selectedDate = statsElements.startDateInput.value;
        params.append('start_date', selectedDate);
        params.append('end_date', selectedDate); // Use the same date for start and end
    } else { // weekly_monthly or comparison
        params.append('year', statsElements.yearSelect.value);
        params.append('menu_nm', 'all'); 
    }

    try {
        const response = await fetch(`/api/statistics?${params.toString()}`);
        if (!response.ok) throw new Error('Failed to fetch statistics data');
        const data = await response.json();

        if (viewType === 'daily') {
            const configResponse = await fetch('/api/statistics/config');
            const config = await configResponse.json();
            renderDailyStats(data, config.menus);
        } else if (viewType === 'weekly_monthly') {
            renderWeeklyMonthlyStats(data);
            if (data.yearly_chart_data) {
                renderLineChart(data.yearly_chart_data, data.weekly_stats);
            }
        } else if (viewType === 'comparison') {
            renderComparisonStats(data);
            renderComparisonLineChart(data);
        }
    } catch (error) {
        console.error('Error loading statistics data:', error);
        showToast(error.message, 'error');
    }
}

/**
 * Renders the statistics for the daily view.
 * @param {object} data - The statistics data from the API.
 * @param {array} allMenus - The complete list of menus from the config.
 */
function renderDailyStats(data, allMenus = []) {
    const { menu_access_stats, total_access_stats } = data;

    // Render summary
    statsElements.summaryContainer.innerHTML = `
        <div class="bg-blue-100 p-4 rounded-lg text-center">
            <p class="text-lg font-semibold text-blue-800">총 접속 횟수</p>
            <p class="text-3xl font-bold">${total_access_stats.total_access_count || 0}</p>
        </div>
        <div class="bg-green-100 p-4 rounded-lg text-center">
            <p class="text-lg font-semibold text-green-800">순 방문자 수</p>
            <p class="text-3xl font-bold">${total_access_stats.unique_user_count || 0}</p>
        </div>
    `;

    // Create a map of stats by menu_id for easy lookup
    const statsMap = new Map();
    if (menu_access_stats) {
        menu_access_stats.forEach(stat => statsMap.set(stat.menu_id, stat));
    }

    // Render table
    statsElements.dailyTableBody.innerHTML = '';
    const menusToRender = allMenus.length > 0 ? allMenus : []; // Always use allMenus for the structure
    
    if (menusToRender.length > 0) {
        menusToRender.forEach(menu => {
            const stat = statsMap.get(menu.menu_id) || { total_access_count: 0, unique_user_count: 0 };
            const row = `<tr>
                <td>${menu.menu_nm}</td>
                <td>${stat.total_access_count}</td>
                <td>${stat.unique_user_count}</td>
            </tr>`;
            statsElements.dailyTableBody.innerHTML += row;
        });
        // Render bar chart for daily stats, passing all menu info for correct labels
        renderBarChart(menu_access_stats || [], allMenus);
    } else {
        statsElements.dailyTableBody.innerHTML = '<tr><td colspan="3">표시할 메뉴가 없습니다.</td></tr>';
        if (statsElements.chartInstance) {
            statsElements.chartInstance.destroy();
        }
    }
}

/**
 * Renders the statistics for the weekly/monthly view.
 * @param {object} data - The statistics data from the API.
 */
function renderWeeklyMonthlyStats(data) {
    const { weekly_stats, yearly_total } = data;
    const table = statsElements.weeklyTable;
    if (!table) return;

    // Clear previous content
    table.innerHTML = '';

    // Create header
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    const headers = ['월', '주차', '메뉴', '총 접속 횟수', '메뉴별 순 방문자 수', '사이트 순 방문자 수'];
    headers.forEach(text => {
        const th = document.createElement('th');
        th.textContent = text;
        headerRow.appendChild(th);
    });

    // Create body
    const tbody = table.createTBody();
    if (weekly_stats && weekly_stats.length > 0) {
        const monthlyData = {};
        weekly_stats.forEach(week => {
            if (!monthlyData[week.month]) {
                monthlyData[week.month] = [];
            }
            monthlyData[week.month].push(week);
        });

        Object.keys(monthlyData).sort((a, b) => a - b).forEach(month => {
            const weeksInMonth = monthlyData[month];
            const totalRowsInMonth = weeksInMonth.reduce((sum, week) => sum + week.menus.length, 0);
            
            weeksInMonth.forEach((weekData, weekIndex) => {
                weekData.menus.forEach((menu, menuIndex) => {
                    const row = tbody.insertRow();
                    
                    if (weekIndex === 0 && menuIndex === 0) {
                        const monthCell = row.insertCell();
                        monthCell.textContent = `${month}월`;
                        monthCell.rowSpan = totalRowsInMonth;
                        monthCell.style.verticalAlign = 'middle';
                    }

                    if (menuIndex === 0) {
                        const weekCell = row.insertCell();
                        weekCell.textContent = `${weekData.week}주`;
                        weekCell.rowSpan = weekData.menus.length;
                        weekCell.style.verticalAlign = 'middle';
                    }

                    row.insertCell().textContent = menu.menu_nm;
                    row.insertCell().textContent = (menu.total_access_count || 0).toLocaleString();
                    row.insertCell().textContent = (menu.unique_user_count || 0).toLocaleString();

                    if (menuIndex === 0) {
                        const siteUniqueCell = row.insertCell();
                        siteUniqueCell.textContent = (weekData.site_unique_user_count || 0).toLocaleString();
                        siteUniqueCell.rowSpan = weekData.menus.length;
                        siteUniqueCell.style.verticalAlign = 'middle';
                    }
                });
            });
        });
    } else {
        const row = tbody.insertRow();
        const cell = row.insertCell();
        cell.colSpan = headers.length;
        cell.textContent = '데이터가 없습니다.';
        cell.style.textAlign = 'center';
    }

    // Create footer for yearly total - more robustly
    let tfoot = table.querySelector('tfoot');
    if (!tfoot) {
        tfoot = table.createTFoot();
    }
    tfoot.innerHTML = ''; // Clear any existing footer content

    if (yearly_total) {
        const footerRow = tfoot.insertRow();
        const totalCell = footerRow.insertCell();
        totalCell.colSpan = 3;
        totalCell.textContent = '연간 총계';
        totalCell.style.fontWeight = 'bold';
        totalCell.style.textAlign = 'center';

        footerRow.insertCell().textContent = (yearly_total.total_access_count || 0).toLocaleString();
        footerRow.insertCell().textContent = (yearly_total.total_menu_unique_user_count || 0).toLocaleString();
        footerRow.insertCell().textContent = (yearly_total.total_site_unique_user_count || 0).toLocaleString();
    }
}


function renderBarChart(menuAccessStats, allMenus) {
    if (statsElements.chartInstance) {
        statsElements.chartInstance.destroy();
    }

    // Create a map for quick lookup
    const statsMap = new Map(menuAccessStats.map(item => [item.menu_id, item]));

    // Ensure all menus are represented
    const chartData = allMenus.map(menu => {
        const stats = statsMap.get(menu.menu_id);
        return {
            menu_nm: menu.menu_nm,
            total_access_count: stats ? stats.total_access_count : 0,
            unique_user_count: stats ? stats.unique_user_count : 0
        };
    });

    const labels = chartData.map(d => d.menu_nm);
    const totalAccessData = chartData.map(d => d.total_access_count);
    const uniqueUserData = chartData.map(d => d.unique_user_count);

    statsElements.chartInstance = new Chart(statsElements.chartCanvas.getContext('2d'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '총 접속 횟수',
                    data: totalAccessData,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: '순 방문자 수',
                    data: uniqueUserData,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            scales: { y: { beginAtZero: true } },
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

/**
 * Renders the line chart for weekly totals, showing all weeks of the year.
 * @param {Array<object>} yearlyChartData - The raw weekly statistics data for the entire year.
 * @param {Array<object>} weeklyStatsData - The processed weekly data for the table (used for site unique users).
 */
function renderLineChart(yearlyChartData, weeklyStatsData) {
    if (statsElements.chartInstance) {
        statsElements.chartInstance.destroy();
    }

    const year = statsElements.yearSelect.value;
    if (!year) return;

    // 1. Create a complete list of labels and a zero-filled data structure for the entire year
    const allWeeksData = [];
    const labels = [];
    for (let month = 1; month <= 12; month++) {
        // Assume 5 weeks per month for a consistent chart axis, covering all possible weeks.
        for (let week = 1; week <= 5; week++) {
            const label = `${month}월 ${week}주`;
            labels.push(label);
            allWeeksData.push({
                label: label,
                month: month,
                week: week,
                total_access_count: 0,
                menu_unique_user_count: 0,
                site_unique_user_count: 0
            });
        }
    }

    // 2. Aggregate API data by week
    const apiAggregates = {};
    if (yearlyChartData && yearlyChartData.length > 0) {
        yearlyChartData.forEach(row => {
            const key = `${row.month}-${row.week_of_month}`;
            if (!apiAggregates[key]) {
                apiAggregates[key] = { total_access_count: 0, menu_unique_user_count: 0 };
            }
            apiAggregates[key].total_access_count += Number(row.total_access_count || 0);
            apiAggregates[key].menu_unique_user_count += Number(row.unique_user_count || 0);
        });
    }
    if (weeklyStatsData && weeklyStatsData.length > 0) {
        weeklyStatsData.forEach(weekData => {
            const key = `${weekData.month}-${weekData.week}`;
            if (!apiAggregates[key]) {
                apiAggregates[key] = { total_access_count: 0, menu_unique_user_count: 0 };
            }
            apiAggregates[key].site_unique_user_count = weekData.site_unique_user_count;
        });
    }

    // 3. Map API data to the full year structure
    allWeeksData.forEach(weekData => {
        const key = `${weekData.month}-${weekData.week}`;
        if (apiAggregates[key]) {
            weekData.total_access_count = apiAggregates[key].total_access_count;
            weekData.menu_unique_user_count = apiAggregates[key].menu_unique_user_count;
            weekData.site_unique_user_count = apiAggregates[key].site_unique_user_count || 0;
        }
    });

    const totalAccessData = allWeeksData.map(d => d.total_access_count);
    const menuUniqueUserData = allWeeksData.map(d => d.menu_unique_user_count);
    const siteUniqueUserData = allWeeksData.map(d => d.site_unique_user_count);

    statsElements.chartInstance = new Chart(statsElements.chartCanvas.getContext('2d'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: '총 접속 횟수',
                    data: totalAccessData,
                    borderColor: 'rgba(54, 162, 235, 1)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    fill: true,
                    tension: 0.1
                },
                {
                    label: '사이트 순 방문자 수',
                    data: siteUniqueUserData,
                    borderColor: 'rgba(255, 99, 132, 1)',
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    fill: true,
                    tension: 0.1
                }
            ]
        },
        options: {
            scales: { y: { beginAtZero: true } },
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

/**
 * Handles the Excel file download for the currently active statistics view.
 */
async function downloadExcel() {
    if (typeof XLSX === 'undefined') {
        console.error('XLSX library is not loaded.');
        showToast('엑셀 라이브러리를 로드하는 중입니다. 잠시 후 다시 시도해주세요.', 'warning');
        return;
    }
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;

    const viewType = container.querySelector('input[name="statsViewType"]:checked').value;
    const year = statsElements.yearSelect.value;
    const selectedDate = statsElements.startDateInput.value;

    try {
        let wb = XLSX.utils.book_new();
        let ws, ws_data, fileName;

        const params = new URLSearchParams({ view_type: viewType });
        if (viewType === 'daily') {
            params.append('start_date', selectedDate);
            params.append('end_date', selectedDate);
        } else { // weekly_monthly or comparison
            params.append('year', year);
        }

        const response = await fetch(`/api/statistics?${params.toString()}`);
        if (!response.ok) throw new Error('통계 데이터 다운로드에 실패했습니다.');
        const data = await response.json();

        if (viewType === 'daily') {
            fileName = `일별_접속통계_${selectedDate}.xlsx`;
            ws_data = [['메뉴', '총 접속 횟수', '순 방문자 수']];
            const configResponse = await fetch('/api/statistics/config');
            const config = await configResponse.json();
            const statsMap = new Map(data.menu_access_stats.map(s => [s.menu_id, s]));
            config.menus.forEach(menu => {
                const stat = statsMap.get(menu.menu_id) || { total_access_count: 0, unique_user_count: 0 };
                ws_data.push([menu.menu_nm, stat.total_access_count, stat.unique_user_count]);
            });
            ws = XLSX.utils.aoa_to_sheet(ws_data);
            XLSX.utils.book_append_sheet(wb, ws, "일별 통계");

        } else if (viewType === 'weekly_monthly') {
            fileName = `주별-월별_접속통계_${year}.xlsx`;
            ws_data = [['월', '주차', '메뉴', '총 접속 횟수', '메뉴별 순 방문자 수', '사이트 순 방문자 수']];
            data.weekly_stats.forEach(week => {
                week.menus.forEach((menu, index) => {
                    ws_data.push([
                        index === 0 ? `${week.month}월` : '',
                        index === 0 ? `${week.week}주` : '',
                        menu.menu_nm,
                        menu.total_access_count,
                        menu.unique_user_count,
                        index === 0 ? week.site_unique_user_count : ''
                    ]);
                });
            });
            ws = XLSX.utils.aoa_to_sheet(ws_data);
            XLSX.utils.book_append_sheet(wb, ws, "주별-월별 통계");

        } else if (viewType === 'comparison') {
            fileName = `연도별_비교_통계_${year}.xlsx`;
            ws_data = [['월', '주차', '메뉴', '연도', '총 접속 횟수', '메뉴별 순 방문자 수', '사이트 순 방문자 수']];
            
            const combinedData = {};
            const processData = (stats, year_label) => {
                if (!stats) return;
                stats.forEach(week => {
                    const weekKey = `${week.month}-${week.week}`;
                    if (!combinedData[weekKey]) combinedData[weekKey] = { month: week.month, week: week.week, menus: {} };
                    week.menus.forEach(menu => {
                        const menuKey = menu.menu_nm;
                        if (!combinedData[weekKey].menus[menuKey]) combinedData[weekKey].menus[menuKey] = {};
                        combinedData[weekKey].menus[menuKey][year_label] = {
                            ...menu,
                            site_unique: week.site_unique_user_count
                        };
                    });
                });
            };
            processData(data.this_year_stats, year);
            processData(data.last_year_stats, year - 1);

            const sortedWeeks = Object.values(combinedData).sort((a, b) => a.month - b.month || a.week - b.week);
            sortedWeeks.forEach(week => {
                Object.keys(week.menus).sort().forEach(menuName => {
                    const thisYearMenu = week.menus[menuName][year];
                    const lastYearMenu = week.menus[menuName][year - 1];

                    if (thisYearMenu) {
                        ws_data.push([`${week.month}월`, `${week.week}주`, menuName, year, thisYearMenu.total_access_count, thisYearMenu.unique_user_count, thisYearMenu.site_unique]);
                    }
                    if (lastYearMenu) {
                        ws_data.push([`${week.month}월`, `${week.week}주`, menuName, year - 1, lastYearMenu.total_access_count, lastYearMenu.unique_user_count, lastYearMenu.site_unique]);
                    }
                });
            });
            ws = XLSX.utils.aoa_to_sheet(ws_data);
            XLSX.utils.book_append_sheet(wb, ws, "연도별 비교 통계");
        }

        if (ws) {
            XLSX.writeFile(wb, fileName);
            showToast('Excel 파일 다운로드가 시작되었습니다.', 'success');
        } else {
            showToast('다운로드할 데이터가 없습니다.', 'info');
        }

    } catch (error) {
        console.error('Excel download error:', error);
        showToast(`엑셀 다운로드 오류: ${error.message}`, 'error');
    }
}

/**
 * Renders the statistics table for the comparison view.
 * @param {object} data - The statistics data from the API, containing this_year_stats and last_year_stats.
 */
function renderComparisonStats(data) {
    const { this_year_stats, last_year_stats, yearly_total } = data;
    const table = statsElements.comparisonTable;
    if (!table) return;

    // Set year legend
    const currentYear = statsElements.yearSelect.value;
    if (statsElements.comparisonYearLegend) {
        statsElements.comparisonYearLegend.textContent = `( ${currentYear}년 / ${currentYear - 1}년 )`;
    }

    table.innerHTML = ''; // Clear previous content

    // --- Header ---
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    const headers = ['월', '주차', '메뉴', '총 접속 횟수', '메뉴별 순 방문자 수', '사이트 순 방문자 수'];
    headers.forEach(text => {
        const th = document.createElement('th');
        th.innerHTML = text.replace(/\s/g, '<br>'); // Add line breaks for readability
        headerRow.appendChild(th);
    });

    // --- Body ---
    const tbody = table.createTBody();
    if (!this_year_stats || this_year_stats.length === 0) {
        const row = tbody.insertRow();
        const cell = row.insertCell();
        cell.colSpan = headers.length;
        cell.textContent = '데이터가 없습니다.';
        cell.style.textAlign = 'center';
        return;
    }

    // Helper function to calculate growth and format output
    const getGrowthHtml = (current, previous) => {
        const diff = current - previous;
        const arrow = diff > 0 ? '▲' : (diff < 0 ? '▼' : '');
        const color = diff > 0 ? 'text-red-500' : (diff < 0 ? 'text-blue-500' : 'text-gray-500');

        if (previous === 0) {
            if (current > 0) {
                return `<span class="${color}">${arrow} ${diff.toLocaleString()}</span>`;
            }
            return `<span class="text-gray-500">-</span>`;
        }
        
        const growth = ((current - previous) / previous) * 100;
        
        return `<span class="${color}">${arrow} ${diff.toLocaleString()} (${growth.toFixed(1)}%)</span>`;
    };

    // Combine and group data
    const combinedData = {};
    const processData = (stats, year) => {
        if (!stats) return;
        stats.forEach(week => {
            const weekKey = `${week.month}-${week.week}`;
            if (!combinedData[weekKey]) {
                combinedData[weekKey] = { month: week.month, week: week.week, menus: {}, site_unique: {} };
            }
            combinedData[weekKey].site_unique[year] = week.site_unique_user_count;
            week.menus.forEach(menu => {
                if (!combinedData[weekKey].menus[menu.menu_nm]) {
                    combinedData[weekKey].menus[menu.menu_nm] = {};
                }
                combinedData[weekKey].menus[menu.menu_nm][year] = menu;
            });
        });
    };
    processData(this_year_stats, 'this_year');
    processData(last_year_stats, 'last_year');

    const sortedWeeks = Object.values(combinedData).sort((a, b) => a.month - b.month || a.week - b.week);

    // Render rows
    const monthlyRowSpans = {};
    sortedWeeks.forEach(week => {
        const menuCount = Object.keys(week.menus).length;
        if (!monthlyRowSpans[week.month]) monthlyRowSpans[week.month] = 0;
        monthlyRowSpans[week.month] += menuCount;
    });

    let currentMonth = -1;
    sortedWeeks.forEach(weekData => {
        const menuNames = Object.keys(weekData.menus).sort();
        const numMenus = menuNames.length;

        menuNames.forEach((menuName, menuIndex) => {
            const row = tbody.insertRow();
            const thisYearData = weekData.menus[menuName]['this_year'] || { total_access_count: 0, unique_user_count: 0 };
            const lastYearData = weekData.menus[menuName]['last_year'] || { total_access_count: 0, unique_user_count: 0 };

            // Month cell (with rowspan)
            if (weekData.month !== currentMonth) {
                currentMonth = weekData.month;
                const monthCell = row.insertCell();
                monthCell.textContent = `${currentMonth}월`;
                monthCell.rowSpan = monthlyRowSpans[currentMonth];
                monthCell.style.verticalAlign = 'middle';
            }

            // Week cell (with rowspan)
            if (menuIndex === 0) {
                const weekCell = row.insertCell();
                weekCell.textContent = `${weekData.week}주`;
                weekCell.rowSpan = numMenus;
                weekCell.style.verticalAlign = 'middle';
            }

            // Menu name
            row.insertCell().textContent = menuName;

            // Data cells
            const fields = ['total_access_count', 'unique_user_count'];
            fields.forEach(field => {
                const current = thisYearData[field] || 0;
                const previous = lastYearData[field] || 0;
                const cell = row.insertCell();
                cell.innerHTML = `
                    <div class="flex flex-col items-center">
                        <span>${current.toLocaleString()} / ${previous.toLocaleString()}</span>
                        ${getGrowthHtml(current, previous)}
                    </div>
                `;
            });
            
            // Site unique visitors (with rowspan)
            if (menuIndex === 0) {
                const siteCell = row.insertCell();
                const current = weekData.site_unique['this_year'] || 0;
                const previous = weekData.site_unique['last_year'] || 0;
                siteCell.innerHTML = `
                    <div class="flex flex-col items-center">
                        <span>${current.toLocaleString()} / ${previous.toLocaleString()}</span>
                        ${getGrowthHtml(current, previous)}
                    </div>
                `;
                siteCell.rowSpan = numMenus;
                siteCell.style.verticalAlign = 'middle';
            }
        });
    });

    // --- Footer ---
    const tfoot = table.createTFoot();
    tfoot.innerHTML = ''; // Clear
    if (yearly_total) {
        const thisYear = yearly_total.this_year || {};
        const lastYear = yearly_total.last_year || {};
        const footerRow = tfoot.insertRow();
        footerRow.innerHTML = `<td colspan="3" class="text-center font-bold">연간 총계</td>`;

        const fields = ['total_access_count', 'total_menu_unique_user_count', 'total_site_unique_user_count'];
        fields.forEach(field => {
            const current = thisYear[field] || 0;
            const previous = lastYear[field] || 0;
            const cell = footerRow.insertCell();
            cell.innerHTML = `
                <div class="flex flex-col items-center font-bold">
                    <span>${current.toLocaleString()} / ${previous.toLocaleString()}</span>
                    ${getGrowthHtml(current, previous)}
                </div>
            `;
        });
    }
}

function renderComparisonLineChart(data) {
    if (statsElements.chartInstance) {
        statsElements.chartInstance.destroy();
    }

    const { yearly_chart_data_this_year, yearly_chart_data_last_year } = data;
    const year = statsElements.yearSelect.value;
    if (!year) return;

    const labels = [];
    for (let month = 1; month <= 12; month++) {
        for (let week = 1; week <= 5; week++) {
            labels.push(`${month}월 ${week}주`);
        }
    }

    const processChartData = (chartData) => {
        const weeklyTotals = new Array(labels.length).fill(0);
        if (!chartData) return weeklyTotals;

        chartData.forEach(row => {
            const monthIndex = row.month - 1;
            const weekIndex = row.week_of_month - 1;
            const labelIndex = monthIndex * 5 + weekIndex;
            if (labelIndex >= 0 && labelIndex < weeklyTotals.length) {
                weeklyTotals[labelIndex] += Number(row.total_access_count || 0);
            }
        });
        return weeklyTotals;
    };

    const thisYearData = processChartData(yearly_chart_data_this_year);
    const lastYearData = processChartData(yearly_chart_data_last_year);

    statsElements.chartInstance = new Chart(statsElements.chartCanvas.getContext('2d'), {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: `${year}년 총 접속 횟수`,
                    data: thisYearData,
                    borderColor: 'rgba(54, 162, 235, 1)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    fill: true,
                    tension: 0.1
                },
                {
                    label: `${year - 1}년 총 접속 횟수`,
                    data: lastYearData,
                    borderColor: 'rgba(255, 99, 132, 1)',
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    fill: true,
                    tension: 0.1
                }
            ]
        },
        options: {
            scales: { y: { beginAtZero: true } },
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            }
        }
    });
}

// --- END: Statistics Tab Logic ---


// --- START: Schedule Settings Tab Logic ---

/**
 * Renders the schedule settings form.
 * @param {object} settings - The schedule settings data.
 */
function renderScheduleSettingsForm(settings) {
    const formContainer = document.getElementById('scheduleSettingsForm');
    if (!formContainer) {
        console.error("Element with ID 'scheduleSettingsForm' not found.");
        return;
    }

    const allIcons = window.allIconsData || [];

    const defaultSetting = {
        sett_id: null,
        grp_min_cnt: 3,
        prgs_rt_red_thrsval: 30,
        prgs_rt_org_thrsval: 60,
        succ_rt_red_thrsval: 30,
        succ_rt_org_thrsval: 60,
        use_yn: 'Y',
        grp_brdr_styl: 'solid',
        grp_colr_crtr: 'prgr',
        sucs_icon_id: null, sucs_bg_colr: '#EBF8FF', sucs_txt_colr: '#3182CE',
        fail_icon_id: null, fail_bg_colr: '#FFF5F5', fail_txt_colr: '#C53030',
        prgs_icon_id: null, prgs_bg_colr: '#FFFFF0', prgs_txt_colr: '#D69E2E',
        nodt_icon_id: null, nodt_bg_colr: '#F7FAFC', nodt_txt_colr: '#718096',
        schd_icon_id: null, schd_bg_colr: '#FFFFFF', schd_txt_colr: '#1A202C',
        grp_prgs_icon_id: null,
        grp_sucs_icon_id: null
    };

    let receivedSettings = {};
    if (Array.isArray(settings) && settings.length > 0) {
        receivedSettings = settings[0] || {};
    } else if (settings && typeof settings === 'object' && !Array.isArray(settings)) {
        receivedSettings = settings;
    }

    const setting = { ...defaultSetting, ...receivedSettings };

    const borderStyles = [
        { value: 'none', label: '없음', symbol: '○' },
        { value: 'solid', label: '실선', symbol: '─' },
        { value: 'dashed', label: '대시', symbol: '╍' },
        { value: 'dotted', label: '점선', symbol: '·' },
        { value: 'double', label: '이중선', symbol: '═' }
    ];

     const borderStyleOptions = borderStyles.map(style => `
        <label class="border-style-option">
            <input type="radio" name="grpBrdrStyl" value="${style.value}" ${setting.grp_brdr_styl === style.value ? 'checked' : ''}>
            <div class="border-symbol">${style.symbol}</div>
            <span>${style.label}</span>
        </label>
    `).join('');

    formContainer.innerHTML = `
        <input type="hidden" id="scheduleSettId" value="${setting.sett_id ?? ''}">
        
        <!-- General Settings -->
        <div class="p-6 rounded-lg border border-gray-200 bg-gray-50">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">기본 설정</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="form-group">
                    <label for="grpMinCnt" class="block text-sm font-medium text-gray-700 mb-1">그룹화 최소 개수</label>
                    <input type="number" id="grpMinCnt" value="${setting.grp_min_cnt ?? ''}" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                </div>
                <div class="form-group">
                    <label class="block text-sm font-medium text-gray-700 mb-1">그룹 외곽선 스타일</label>
                    <div class="border-style-selector">${borderStyleOptions}</div>
                </div>
                <div class="form-group flex items-center">
                     <div class="flex items-center h-10">
                        <input type="checkbox" id="scheduleUseYn" ${setting.use_yn === 'Y' ? 'checked' : ''} class="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                        <label for="scheduleUseYn" class="ml-2 block text-sm font-medium text-gray-900">설정 사용 여부</label>
                    </div>
                </div>
                <div class="form-group md:col-span-2">
                   <h4 class="text-md font-semibold text-gray-700 mb-2 border-t pt-4">그룹 색상 임계값 설정</h4>
                    <div class="flex items-center space-x-4">
                        <label class="block text-sm font-medium text-gray-700">색상 기준:</label>
                        <label><input type="radio" name="grpColrCrtr" value="prgr" ${setting.grp_colr_crtr === 'prgr' ? 'checked' : ''}> 진행률</label>
                        <label><input type="radio" name="grpColrCrtr" value="succ" ${setting.grp_colr_crtr === 'succ' ? 'checked' : ''}> 성공률</label>
                    </div>
                </div>
               <div class="form-group">
                   <label for="prgsRtRedThrsval" class="block text-sm font-medium text-gray-700 mb-1">진행률 문제점 임계값 (%)</label>
                   <input type="number" id="prgsRtRedThrsval" value="${setting.prgs_rt_red_thrsval ?? ''}" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
               </div>
               <div class="form-group">
                   <label for="prgsRtOrgThrsval" class="block text-sm font-medium text-gray-700 mb-1">진행률 경고 임계값 (%)</label>
                   <input type="number" id="prgsRtOrgThrsval" value="${setting.prgs_rt_org_thrsval ?? ''}" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
               </div>
               <div class="form-group">
                   <label for="succRtRedThrsval" class="block text-sm font-medium text-gray-700 mb-1">성공률 문제점 임계값 (%)</label>
                   <input type="number" id="succRtRedThrsval" value="${setting.succ_rt_red_thrsval ?? ''}" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
               </div>
               <div class="form-group">
                   <label for="succRtOrgThrsval" class="block text-sm font-medium text-gray-700 mb-1">성공률 경고 임계값 (%)</label>
                   <input type="number" id="succRtOrgThrsval" value="${setting.succ_rt_org_thrsval ?? ''}" class="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
               </div>
                <div class="form-group md:col-span-2">
                   <h4 class="text-md font-semibold text-gray-700 mt-2 border-t pt-4">그룹 아이콘 설정</h4>
                </div>
                ${createStatusSettingRow('grp_prgs', '그룹 진행률', setting.grpPrgsIconId, null, null, allIcons, true)}
                ${createStatusSettingRow('grp_sucs', '그룹 성공률', setting.grpSucsIconId, null, null, allIcons, true)}
            </div>
        </div>

        <!-- Display Settings -->
        <div class="mt-8 p-6 border border-gray-200 rounded-lg bg-white shadow-sm">
            <h3 class="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">상태별 표시 설정</h3>
            <div class="space-y-6">
                ${createStatusSettingRow('sucs', '성공', setting.sucsIconId, setting.sucsBgColr, setting.sucsTxtColr, allIcons)}
                ${createStatusSettingRow('fail', '실패', setting.failIconId, setting.failBgColr, setting.failTxtColr, allIcons)}
                ${createStatusSettingRow('prgs', '수집중', setting.prgsIconId, setting.prgsBgColr, setting.prgsTxtColr, allIcons)}
                ${createStatusSettingRow('nodt', '미수집', setting.nodtIconId, setting.nodtBgColr, setting.nodtTxtColr, allIcons)}
                ${createStatusSettingRow('schd', '예정', setting.schdIconId, setting.schdBgColr, setting.schdTxtColr, allIcons)}
            </div>
            
            <div class="mt-6">
                <h4 class="text-md font-semibold text-gray-700 mb-2">컬러 팔레트</h4>
            </div>
        </div>

    `;
    
    // Append the color palette to the form
    const displaySettingsContainer = formContainer.querySelector('.mt-6');
    if(displaySettingsContainer) {
        displaySettingsContainer.appendChild(createColorPalette());
    }
}


// --- START: Color Palette Logic ---

const pastelColors = [
    '#FFADAD', '#FFD6A5', '#FDFFB6', '#CAFFBF', '#9BF6FF', '#A0C4FF', '#BDB2FF', '#FFC6FF',
    '#FFC8DD', '#FFDDD2', '#FFFFE0', '#D4F0C3', '#B2EBF2', '#B3E5FC', '#C5CAE9', '#E1BEE7'
];

let activeColorInput = null;

function createColorPalette() {
    const palette = document.createElement('div');
    palette.className = 'color-palette';
    pastelColors.forEach(color => {
        const square = document.createElement('div');
        square.className = 'color-square';
        square.style.backgroundColor = color;
        square.dataset.color = color;
        
        square.addEventListener('click', () => {
            if (activeColorInput) {
                activeColorInput.value = color;
                activeColorInput.dispatchEvent(new Event('input'));
            }
        });
        palette.appendChild(square);
    });
    return palette;
}

function setActiveColorInput(inputElement) {
    // Remove highlight from previous active input's container
    if (activeColorInput && activeColorInput.parentElement.parentElement) {
         activeColorInput.parentElement.parentElement.classList.remove('ring-2', 'ring-blue-500', 'rounded-md');
    }
    
    activeColorInput = inputElement;

    // Add highlight to new active input's container
    if (activeColorInput && activeColorInput.parentElement.parentElement) {
        activeColorInput.parentElement.parentElement.classList.add('ring-2', 'ring-blue-500', 'rounded-md');
    }
}

// --- END: Color Palette Logic ---


/**
 * Fetches schedule settings from the server and renders the form.
 */
async function loadScheduleSettings() {
    try {
        const response = await fetch(`/api/mngr_sett/schedule_settings?_=${new Date().getTime()}`);
        if (!response.ok) {
            throw new Error(`스케줄 표시 설정 정보를 가져오는데 실패했습니다. Status: ${response.status}`);
        }
        // 응답이 비어있는 경우를 대비하여 .text()로 먼저 읽음
        const text = await response.text();
        const settings = text ? JSON.parse(text) : [];
        renderScheduleSettingsForm(settings);
        
        // --- Attach Event Listeners after rendering ---
        const formContainer = document.getElementById('scheduleSettingsForm');
        if (formContainer) {
            const colorInputs = formContainer.querySelectorAll('input[type="color"]');
            colorInputs.forEach(input => {
                // Set initial preview color
                const preview = input.previousElementSibling;
                if (preview) {
                    preview.style.backgroundColor = input.value;
                }

                // Update preview on change
                input.addEventListener('input', (e) => {
                    const preview = e.target.previousElementSibling;
                    if (preview) {
                        preview.style.backgroundColor = e.target.value;
                    }
                });
                
                // Set as active for palette selection
                input.addEventListener('click', (e) => {
                    setActiveColorInput(e.target);
                });
                input.addEventListener('focus', (e) => {
                    setActiveColorInput(e.target);
                });
            });
        }
        
    } catch (error) {
        showToast(error.message, 'error');
        renderScheduleSettingsForm([]);
    }
}


/**
 * Collects data from the schedule settings form and saves it to the server.
 */
async function saveScheduleSettings() {
    const settId = document.getElementById('scheduleSettId').value;
    const grpMinCntValue = document.getElementById('grpMinCnt').value;
    const prgsRtRedThrsvalValue = document.getElementById('prgsRtRedThrsval').value;
    const prgsRtOrgThrsvalValue = document.getElementById('prgsRtOrgThrsval').value;
    const succRtRedThrsvalValue = document.getElementById('succRtRedThrsval').value;
    const succRtOrgThrsvalValue = document.getElementById('succRtOrgThrsval').value;

    const grpMinCnt = grpMinCntValue === '' ? null : parseInt(grpMinCntValue);
    const prgsRtRedThrsval = prgsRtRedThrsvalValue === '' ? null : parseInt(prgsRtRedThrsvalValue);
    const prgsRtOrgThrsval = prgsRtOrgThrsvalValue === '' ? null : parseInt(prgsRtOrgThrsvalValue);
    const succRtRedThrsval = succRtRedThrsvalValue === '' ? null : parseInt(succRtRedThrsvalValue);
    const succRtOrgThrsval = succRtOrgThrsvalValue === '' ? null : parseInt(succRtOrgThrsvalValue);
    const useYn = document.getElementById('scheduleUseYn').checked ? 'Y' : 'N';

    if (grpMinCnt === null || prgsRtRedThrsval === null || prgsRtOrgThrsval === null || succRtRedThrsval === null || succRtOrgThrsval === null) {
        showToast('기본 설정의 모든 숫자 필드를 입력해주세요.', 'error');
        return;
    }
    
    if (prgsRtRedThrsval >= prgsRtOrgThrsval) {
        showToast('진행률의 문제점 임계값은 경고 임계값보다 작아야 합니다.', 'error');
        return;
    }
    if (succRtRedThrsval >= succRtOrgThrsval) {
       showToast('성공률의 문제점 임계값은 경고 임계값보다 작아야 합니다.', 'error');
       return;
   }

    const getIconId = (id) => {
        const value = document.getElementById(id).value;
        return value ? parseInt(value) : null;
    };

    const settingsData = {
        sett_id: settId ? parseInt(settId) : null,
        grp_min_cnt: grpMinCnt,
        prgs_rt_red_thrsval: prgsRtRedThrsval,
        prgs_rt_org_thrsval: prgsRtOrgThrsval,
        succ_rt_red_thrsval: succRtRedThrsval,
        succ_rt_org_thrsval: succRtOrgThrsval,
        use_yn: useYn,
        grp_brdr_styl: document.querySelector('input[name="grpBrdrStyl"]:checked') ? document.querySelector('input[name="grpBrdrStyl"]:checked').value : 'solid',
        grp_colr_crtr: document.querySelector('input[name="grpColrCrtr"]:checked') ? document.querySelector('input[name="grpColrCrtr"]:checked').value : 'prgr',
        sucs_icon_id: getIconId('sucs_icon_id'),
        sucs_bg_colr: document.getElementById('sucs_bg_colr').value,
        sucs_txt_colr: document.getElementById('sucs_txt_colr').value,
        fail_icon_id: getIconId('fail_icon_id'),
        fail_bg_colr: document.getElementById('fail_bg_colr').value,
        fail_txt_colr: document.getElementById('fail_txt_colr').value,
        prgs_icon_id: getIconId('prgs_icon_id'),
        prgs_bg_colr: document.getElementById('prgs_bg_colr').value,
        prgs_txt_colr: document.getElementById('prgs_txt_colr').value,
        nodt_icon_id: getIconId('nodt_icon_id'),
        nodt_bg_colr: document.getElementById('nodt_bg_colr').value,
        nodt_txt_colr: document.getElementById('nodt_txt_colr').value,
        schd_icon_id: getIconId('schd_icon_id'),
        schd_bg_colr: document.getElementById('schd_bg_colr').value,
        schd_txt_colr: document.getElementById('schd_txt_colr').value,
        grp_prgs_icon_id: getIconId('grp_prgs_icon_id'),
        grp_sucs_icon_id: getIconId('grp_sucs_icon_id')
    };

    console.log('--- FE: Sending schedule settings data:', settingsData);
    try {
        const response = await fetch('/api/mngr_sett/schedule_settings/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settingsData)
        });
        
        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || '스케줄 표시 설정 저장에 실패했습니다.');
        }
        showToast('스케줄 표시 설정이 성공적으로 저장되었습니다.', 'success');
        
        // Update the hidden sett_id field with the returned new ID after creation
        if (result.sett_id) {
            document.getElementById('scheduleSettId').value = result.sett_id;
        }

    } catch (error) {
        showToast(`저장 실패: ${error.message}`, 'error');
    }
}

// --- END: Schedule Settings Tab Logic ---


/**
 * Creates a reusable HTML string for a status setting row with an icon dropdown.
 * @param {string} prefix - The prefix for element IDs (e.g., 'sucs', 'fail').
 * @param {string} label - The display label for the status.
 * @param {number|null} selectedIconId - The currently selected icon ID.
 * @param {string} bgColorValue - The current value for the background color.
 * @param {string} textColorValue - The current value for the text color.
 * @param {Array<Object>} allIcons - The list of all available icons.
 * @returns {string} - The HTML string for the row.
 */
function createStatusSettingRow(prefix, label, selectedIconId, bgColorValue, textColorValue, allIcons, isIconOnly = false) {
    const iconOptions = allIcons
        .filter(icon => icon.icon_dsp_yn === true)
        .map(icon => `<option value="${icon.icon_id}" ${icon.icon_id === selectedIconId ? 'selected' : ''}>${icon.icon_cd}</option>`)
        .join('');

    if (isIconOnly) {
        return `
            <div class="form-group">
                <label for="${prefix}_icon_id" class="block text-sm font-medium text-gray-700">${label}</label>
                <select id="${prefix}_icon_id" class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <option value="">선택 안 함</option>
                    ${iconOptions}
                </select>
            </div>
        `;
    }

    return `
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 items-center p-3 rounded-md border bg-gray-50">
            <div class="font-medium text-gray-800">${label}</div>
            <div class="form-group">
                <label for="${prefix}_icon_id" class="block text-xs font-medium text-gray-600 mb-1">아이콘</label>
                <select id="${prefix}_icon_id" class="w-full p-2 border border-gray-300 rounded-md shadow-sm">
                    <option value="">선택 안 함</option>
                    ${iconOptions}
                </select>
            </div>
            <div class="form-group">
                <label for="${prefix}_bg_colr" class="block text-xs font-medium text-gray-600 mb-1">배경색</label>
                <div class="color-input-wrapper">
                     <span class="color-preview"></span>
                    <input type="color" id="${prefix}_bg_colr" value="${bgColorValue || '#FFFFFF'}" class="w-full h-10 p-1 border border-gray-300 rounded-md shadow-sm">
                </div>
            </div>
            <div class="form-group">
                <label for="${prefix}_txt_colr" class="block text-xs font-medium text-gray-600 mb-1">글자색</label>
                 <div class="color-input-wrapper">
                    <span class="color-preview"></span>
                    <input type="color" id="${prefix}_txt_colr" value="${textColorValue || '#000000'}" class="w-full h-10 p-1 border border-gray-300 rounded-md shadow-sm">
                </div>
            </div>
        </div>
    `;
}


// --- START: Existing Page Logic ---

async function fetchUsersAndMenus() {
    try {
        const response = await fetch(`/api/mngr_sett/users?_=${new Date().getTime()}`);
        if (!response.ok) throw new Error('사용자 정보를 가져오는데 실패했습니다.');
        return await response.json();
    } catch (error) {
        console.error(error);
        showToast(error.message, 'error');
        return { users: [], menus: [] };
    }
}

function renderUserManagementTable(users, menus) {
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;
    const tableBody = container.querySelector('#userTableBody');
    if (!tableBody) return;

    // 'admin' 권한을 'mngr_sett'으로 변경하고, 메뉴 목록에 포함시켜 일관성 있게 처리
    const allMenus = menus.map(m => m.menu_id === 'admin' ? { ...m, menu_id: 'mngr_sett', menu_nm: '관리자 설정' } : m);
    
    // 메뉴를 menu_ord 기준으로 정렬
    allMenus.sort((a, b) => a.menu_ord - b.menu_ord);

    // 헤더 생성
    let menuHeaderHtml = allMenus.map(menu => `<th>${menu.menu_nm}</th>`).join('');
    const headerRow = `<tr><th>사용자 ID</th><th>작업</th><th>상태</th><th>가입일</th>${menuHeaderHtml}</tr>`;
    tableBody.parentElement.querySelector('thead').innerHTML = headerRow;

    // 테이블 바디 생성
    tableBody.innerHTML = '';
    users.forEach(user => {
        const row = document.createElement('tr');
        const createdAt = user.acc_cre_dt ? new Date(user.acc_cre_dt).toLocaleDateString('ko-KR') : 'N/A';

        // 권한 체크박스 HTML 생성
        let permissionsHtml = allMenus.map(menu => {
            const isChecked = user.permissions.includes(menu.menu_id) ? 'checked' : '';
            return `<td><input type="checkbox" class="permission-checkbox" data-user-id="${user.user_id}" data-menu-id="${menu.menu_id}" ${isChecked}></td>`;
        }).join('');

        // 작업 버튼 HTML 생성
        let actionHtml = '';
        if (user.acc_sts === 'PENDING' || user.acc_sts === 'PENDING_RESET') {
            actionHtml = `<button class="approve-btn bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded text-xs" data-user-id="${user.user_id}">승인</button> <button class="reject-btn bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded text-xs" data-user-id="${user.user_id}">거절</button>`;
        } else {
            // 개별 저장 버튼 제거
            actionHtml = `<button class="reset-password-btn bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-1 px-2 rounded text-xs" data-user-id="${user.user_id}">비밀번호 초기화</button> <button class="delete-user-btn bg-gray-500 hover:bg-gray-700 text-white font-bold py-1 px-2 rounded text-xs" data-user-id="${user.user_id}">삭제</button>`;
        }

        row.innerHTML = `<td>${user.user_id}</td><td>${actionHtml}</td><td>${user.acc_sts}</td><td>${createdAt}</td>${permissionsHtml}`;
        tableBody.appendChild(row);
    });

    addEventListenersToButtons();
}

function addEventListenersToButtons() {
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;
    container.querySelectorAll('.approve-btn').forEach(b => b.addEventListener('click', e => approveUser(e.target.dataset.userId)));
    container.querySelectorAll('.reject-btn').forEach(b => b.addEventListener('click', e => { if (confirm(`'${e.target.dataset.userId}' 사용자의 가입 신청을 거절하시겠습니까?`)) rejectUser(e.target.dataset.userId); }));
    // container.querySelectorAll('.save-permissions-btn').forEach(b => b.addEventListener('click', e => saveUserPermissions(e.target.dataset.userId))); // 개별 저장 버튼 리스너 제거
    container.querySelectorAll('.reset-password-btn').forEach(b => b.addEventListener('click', e => { if (confirm(`'${e.target.dataset.userId}' 사용자의 비밀번호를 ID와 동일하게 초기화하시겠습니까?`)) resetPassword(e.target.dataset.userId); }));
    container.querySelectorAll('.delete-user-btn').forEach(b => b.addEventListener('click', e => { if (confirm(`'${e.target.dataset.userId}' 사용자를 정말로 삭제하시겠습니까?`)) deleteUser(e.target.dataset.userId); }));
}

async function approveUser(userId) {
    try {
        const response = await fetch('/api/mngr_sett/users/approve', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: userId }) });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        showToast(result.message, 'success');
        refreshUserManagementTable();
    } catch (error) { showToast(`승인 실패: ${error.message}`, 'error'); }
}

async function rejectUser(userId) {
    try {
        const response = await fetch('/api/mngr_sett/users/reject', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: userId }) });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        showToast(result.message, 'success');
        refreshUserManagementTable();
    } catch (error) { showToast(`거절 실패: ${error.message}`, 'error'); }
}

async function deleteUser(userId) {
    try {
        const response = await fetch('/api/mngr_sett/users/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: userId }) });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        showToast(result.message, 'success');
        refreshUserManagementTable();
    } catch (error) { showToast(`삭제 실패: ${error.message}`, 'error'); }
}

async function resetPassword(userId) {
    try {
        const response = await fetch('/api/mngr_sett/users/reset-password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: userId }) });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        showToast(result.message, 'success');
        refreshUserManagementTable();
    } catch (error) { showToast(`비밀번호 초기화 실패: ${error.message}`, 'error'); }
}

async function saveUserPermissions(userId) {
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;
    const permissionCheckboxes = container.querySelectorAll(`.permission-checkbox[data-user-id="${userId}"]`);
    let selectedMenuIds = Array.from(permissionCheckboxes).filter(cb => cb.checked).map(cb => cb.dataset.menuId);
    
    try {
        const response = await fetch('/api/mngr_sett/users/permissions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: userId, menu_ids: selectedMenuIds }) });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        showToast(result.message, 'success');
        refreshUserManagementTable();
    } catch (error) { showToast(`권한 저장 실패: ${error.message}`, 'error'); }
}

async function saveAllUserPermissions() {
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;
    const userRows = container.querySelectorAll('#userTableBody tr');
    const permissionsData = [];

    userRows.forEach(row => {
        const userId = row.querySelector('.permission-checkbox')?.dataset.userId;
        if (userId) {
            const permissionCheckboxes = row.querySelectorAll(`.permission-checkbox[data-user-id="${userId}"]`);
            const selectedMenuIds = Array.from(permissionCheckboxes)
                .filter(cb => cb.checked)
                .map(cb => cb.dataset.menuId);
            permissionsData.push({ user_id: userId, menu_ids: selectedMenuIds });
        }
    });

    if (permissionsData.length === 0) {
        showToast('저장할 데이터가 없습니다.', 'info');
        return;
    }

    try {
        const response = await fetch('/api/mngr_sett/users/permissions/bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ permissions: permissionsData })
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message);
        showToast(result.message, 'success');
        refreshUserManagementTable();
    } catch (error) {
        showToast(`전체 권한 저장 실패: ${error.message}`, 'error');
    }
}

function addNewSettingRow() {
    const container = document.getElementById('mngr_sett_page');
    if (!container) return;
    const settingsTableBody = container.querySelector('#settingsTableBody');
    const chartSettingsTableBody = container.querySelector('#chartSettingsTableBody');
    const newCd = prompt("새로 추가할 Job ID를 입력하세요:");
    if (!newCd) { showToast('Job ID가 입력되지 않았습니다.', 'warning'); return; }
    if (container.querySelector(`#settingsTableBody tr[data-cd="${newCd}"]`)) { showToast('이미 존재하는 Job ID입니다.', 'error'); return; }
    const newRow = settingsTableBody.insertRow();
    newRow.dataset.cd = newCd;
    newRow.innerHTML = `<td class="job-id-cell">${newCd}</td><td><input type="text" value="${newCd}" data-field="cd_nm" placeholder="Job 이름"></td><td><input type="text" value="" data-field="cd_desc" placeholder="Job 설명"></td><td><input type="text" value="" data-field="item5" placeholder="비고"></td><td><input type="number" value="0" data-field="cnn_failr_thrs_val"></td><td><select data-field="cnn_failr_icon_id" class="icon-select"><option value="">선택 안 함</option></select></td><td><input type="color" value="#FF0000" data-field="cnn_failr_wrd_colr"></td><td><input type="number" value="0" data-field="cnn_warn_thrs_val"></td><td><select data-field="cnn_warn_icon_id" class="icon-select"><option value="">선택 안 함</option></select></td><td><input type="color" value="#FFA500" data-field="cnn_warn_wrd_colr"></td><td><select data-field="cnn_sucs_icon_id" class="icon-select"><option value="">선택 안 함</option></select></td><td><input type="color" value="#008000" data-field="cnn_sucs_wrd_colr"></td><td><input type="number" step="0.01" value="0" data-field="dly_sucs_rt_thrs_val"></td><td><input type="number" step="0.01" value="0" data-field="dd7_sucs_rt_thrs_val"></td><td><input type="number" step="0.01" value="0" data-field="mthl_sucs_rt_thrs_val"></td><td><input type="number" step="0.01" value="0" data-field="mc6_sucs_rt_thrs_val"></td><td><input type="number" step="0.01" value="0" data-field="yy1_sucs_rt_thrs_val"></td><td><select data-field="sucs_rt_sucs_icon_id" class="icon-select"><option value="">선택 안 함</option></select></td><td><input type="color" value="#008000" data-field="sucs_rt_sucs_wrd_colr"></td><td><select data-field="sucs_rt_warn_icon_id" class="icon-select"><option value="">선택 안 함</option></select></td><td><input type="color" value="#FFA500" data-field="sucs_rt_warn_wrd_colr"></td><td><input type="checkbox" checked data-field="chrt_dsp_yn"></td>`;
    const newChartRow = chartSettingsTableBody.insertRow();
    newChartRow.dataset.cd = newCd;
    newChartRow.innerHTML = `<td class="job-id-cell">${newCd}</td><td><input type="text" value="${newCd}" data-field="cd_nm" readonly disabled></td><td><input type="color" value="#007bff" data-field="chrt_colr"></td><td><input type="color" value="#9be9a8" data-field="grass_chrt_min_colr"></td><td><input type="color" value="#216e39" data-field="grass_chrt_max_colr"></td>`;
    populateIconSelects(window.allIconsData || []);
}

async function refreshUserManagementTable() {
    const { users, menus } = await fetchUsersAndMenus();
    renderUserManagementTable(users, menus);
}

async function loadPageData() {
    const container = document.getElementById('mngr_sett_page');
    if (!container) {
        console.error("[mngr_sett.js] CRITICAL: Page container #mngr_sett_page not found. Aborting initialization.");
        return;
    }
    const loadingOverlay = container.querySelector('#adminLoadingOverlay');
    if (loadingOverlay) loadingOverlay.classList.remove('hidden');

    try {
        const [adminSettings, icons, userData] = await Promise.all([
            getAdminSettings(),
            getIcons(),
            fetchUsersAndMenus()
        ]);

        renderSettingsTable(adminSettings, icons);
        renderIconTable(icons);
        populateIconSelects(icons);
        window.allIconsData = icons;
        renderUserManagementTable(userData.users, userData.menus);

        showToast('관리자 설정 페이지 로드 완료.', 'success');
    } catch (error) {
        console.error("[mngr_sett.js] CRITICAL: Page initialization failed:", error);
        showToast('페이지 초기화 중 오류 발생: ' + error.message, 'error');
    } finally {
        if (loadingOverlay) loadingOverlay.classList.add('hidden');
    }
}

export async function init() {
    const container = document.getElementById('mngr_sett_page');
    if (!container) {
        console.error("[mngr_sett.js] CRITICAL: Page container #mngr_sett_page not found. Aborting initialization.");
        return;
    }

    setupTabs();
    initializeIconManagementUI();

    const addRowBtn = container.querySelector('#addRowBtn');
    if (addRowBtn) addRowBtn.addEventListener('click', addNewSettingRow);
    
    const saveAllPermissionsBtn = container.querySelector('#saveAllPermissionsBtn');
    if (saveAllPermissionsBtn) saveAllPermissionsBtn.addEventListener('click', saveAllUserPermissions);

    const userManagementTab = container.querySelector('button[data-tab="userManagement"]');
    if (userManagementTab) {
        userManagementTab.addEventListener('click', refreshUserManagementTable);
    }

    const settingsTab = container.querySelector('button[data-tab="settings"]');
    if (settingsTab) {
        settingsTab.addEventListener('click', loadPageData);
    }

    initStatisticsTab();

    const scheduleSettingsTab = container.querySelector('button[data-tab="scheduleSettings"]');
    if (scheduleSettingsTab) {
        scheduleSettingsTab.addEventListener('click', loadScheduleSettings);
    }

    const saveScheduleBtn = container.querySelector('#saveScheduleSettingsBtn');
    if (saveScheduleBtn) {
        saveScheduleBtn.addEventListener('click', saveScheduleSettings);
    }

    // 초기에 첫 번째 탭(설정)을 활성화하고 데이터를 로드합니다.
    const firstTab = container.querySelector('.tab-button');
    if (firstTab) {
        firstTab.click();
    }
    loadPageData();
}

window.saveBasicSettings = saveBasicSettings;
window.saveChartSettings = saveChartSettings;
window.exportSettings = exportSettings;
window.importSettings = importSettings;
window.exportIcons = exportIcons;
window.importIcons = importIcons;
window.refreshUserManagementTable = refreshUserManagementTable;

// --- END: Existing Page Logic ---
