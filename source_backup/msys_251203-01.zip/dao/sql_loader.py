import os
from functools import lru_cache

@lru_cache(maxsize=None)
def load_sql(file_path: str) -> str:
    """
    SQL 파일을 읽어와서 쿼리 문자열을 반환합니다.
    결과는 캐시되어 반복적인 파일 I/O를 방지합니다.
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # 'dao' 디렉토리에서 상위 디렉토리로 이동한 후 'sql' 디렉토리로 경로 설정
    sql_file_path = os.path.join(base_dir, '..', 'sql', file_path)
    
    try:
        with open(sql_file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        raise FileNotFoundError(f"SQL file not found at: {sql_file_path}")
    except Exception as e:
        raise e
