// static/js/modules/common/api/client.js
import { showMessage } from '../utils.js';

let globalDataFlowStatus = {};

export function setDataFlowStatus(statusObject) {
    globalDataFlowStatus = statusObject;
}

export function updateApiStatus(apiName, field, value) {
    if (!globalDataFlowStatus) {
        console.warn(`[API Module] globalDataFlowStatus has not been initialized. (API: ${apiName}, Field: ${field})`);
        return;
    }
    if (!globalDataFlowStatus[apiName]) {
        globalDataFlowStatus[apiName] = {
            apiCallAttempted: false,
            apiCallSuccess: false,
            apiResponseCount: 0,
            dataProcessedCount: 0,
            chartRendered: false,
            error: null
        };
    }
    globalDataFlowStatus[apiName][field] = value;
    if (field === "error" && value !== null) {
        globalDataFlowStatus.overallStatus = "error";
    }
}

// A wrapper for fetch can be added here later if needed.
