# routes/card_summary_routes.py
from flask import Blueprint, render_template, jsonify
from service.card_summary_service import CardSummaryService
from msys.database import get_db_connection
from flask_login import login_required

card_summary_bp = Blueprint('card_summary', __name__)

@card_summary_bp.route('/card_summary')
@login_required
def card_summary_page():
    """
    Renders the card summary page.
    """
    return render_template('card_summary.html')

@card_summary_bp.route('/api/card_summary')
@login_required
def get_card_summary_data():
    """
    Provides card summary data as JSON.
    """
    db_connection = get_db_connection()
    service = CardSummaryService(db_connection)
    summary_data = service.get_card_summary()
    return jsonify(summary_data)
