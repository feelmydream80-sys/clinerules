from flask import Blueprint, render_template, current_app, request, jsonify
from .auth_routes import login_required, check_password_change_required, collection_schedule_required
from routes.dashboard_routes import log_menu_access
from service.dashboard_service import DashboardService
from mapper.mst_mapper import MstMapper
from msys.database import get_db_connection
from datetime import datetime, timedelta
import croniter
import pytz

collection_schedule_bp = Blueprint('collection_schedule', __name__)

@collection_schedule_bp.route("/collection_schedule")
@login_required
@check_password_change_required
@collection_schedule_required
@log_menu_access
def collection_schedule():
    """데이터 수집 일정 페이지를 렌더링합니다."""
    return render_template("collection_schedule.html")

def get_schedule_and_history(start_date, end_date):
    """
    주어진 기간 동안의 데이터 수집 스케줄과 실제 이력을 조합하여 반환합니다.
    미래 시간대의 스케줄은 '예정'으로 표시합니다.
    """
    with get_db_connection() as conn:
        dashboard_service = DashboardService(conn)
        mst_mapper = MstMapper(conn)

        kst = pytz.timezone('Asia/Seoul')
        now_kst = datetime.now(kst)

        all_mst_data = mst_mapper.get_all_mst_for_schedule()
        jobs = {mst['cd']: mst.get('item6') for mst in all_mst_data if mst.get('item6')}

        scheduled_tasks = []
        current_date = start_date
        while current_date <= end_date:
            for cd, cron_str in jobs.items():
                try:
                    base_time = datetime(current_date.year, current_date.month, current_date.day)
                    cron = croniter.croniter(cron_str, base_time)
                    schedule_time = cron.get_next(datetime)
                    while schedule_time.date() == current_date:
                        schedule_time_aware = kst.localize(schedule_time)
                        status = "미수집"
                        if schedule_time_aware > now_kst:
                            status = "예정"

                        scheduled_tasks.append({
                            "date": current_date.strftime('%Y-%m-%d'),
                            "job_id": cd,
                            "schedule_time": schedule_time.strftime('%H:%M:%S'),
                            "status": status,
                        })
                        schedule_time = cron.get_next(datetime)
                except Exception as e:
                    current_app.logger.error(f"Error parsing cron string '{cron_str}' for job '{cd}': {e}")
            current_date += timedelta(days=1)

        history_data = dashboard_service.get_collection_history_for_schedule(start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d'))
        
        # 각 (날짜, job_id) 조합에 대한 모든 상태를 수집
        history_statuses = {}
        for item in history_data:
            date_str = str(item['collection_date'])
            job_id = item['job_id']
            status_code = item['status']
            key = (date_str, job_id)

            if key not in history_statuses:
                history_statuses[key] = []
            history_statuses[key].append(status_code)

        # 우선순위에 따라 최종 상태를 결정
        history_map = {}
        for key, statuses in history_statuses.items():
            if 'CD903' in statuses:
                history_map[key] = '실패'
            elif 'CD902' in statuses:
                history_map[key] = '수집중'
            elif 'CD901' in statuses:
                history_map[key] = '성공'
            else:
                history_map[key] = '미수집' # 기본값

        for task in scheduled_tasks:
            if task['status'] == '예정':
                continue
            key = (task['date'], task['job_id'])
            task['status'] = history_map.get(key, '미수집')

    return scheduled_tasks

@collection_schedule_bp.route("/api/collection_schedule")
@login_required
def api_collection_schedule():
    """데이터 수집 일정 데이터를 API로 제공합니다."""
    view_type = request.args.get('view', 'weekly') # 'weekly' or 'monthly'
    
    today = datetime.now(pytz.timezone('Asia/Seoul')).date()
    
    if view_type == 'monthly':
        start_date = today.replace(day=1)
        # 다음 달의 첫 날에서 하루를 빼서 이번 달의 마지막 날을 구함
        next_month = (start_date.replace(day=28) + timedelta(days=4)).replace(day=1)
        end_date = next_month - timedelta(days=1)
    else: # weekly
        start_date = today - timedelta(days=today.weekday())
        end_date = start_date + timedelta(days=6)
        
    try:
        report_data = get_schedule_and_history(start_date, end_date)
        return jsonify(report_data)
    except Exception as e:
        current_app.logger.error(f"Failed to get data report: {e}", exc_info=True)
        return jsonify({"error": "데이터를 조회하는 중 오류가 발생했습니다."}), 500
