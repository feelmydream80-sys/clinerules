import logging
from dao.con_hist_dao import ConHistDAO

class CardSummaryService:
    def __init__(self, conn):
        self.conn = conn
        self.logger = logging.getLogger(__name__)

    def get_daily_job_status(self):
        """
        오늘 날짜의 모든 작업 상태를 가져와 그룹별로 정리하여 반환합니다.
        """
        try:
            con_hist_dao = ConHistDAO(self.conn)
            # DAO에 오늘 날짜의 데이터를 가져오는 함수를 호출
            daily_data = con_hist_dao.find_status_by_today()
            
            # 데이터를 job_id의 hundred-prefix 기준으로 그룹화
            grouped_data = self._group_data_by_job_prefix(daily_data)
            
            return grouped_data
        except Exception as e:
            self.logger.error(f"Failed to get daily job status: {e}", exc_info=True)
            return {}

    def _group_data_by_job_prefix(self, data):
        """
        데이터 리스트를 job_id의 앞자리(hundred-prefix)를 기준으로 그룹화합니다.
        """
        grouped = {}
        for item in data:
            job_id = item.get('job_id', '')
            if len(job_id) > 2:
                prefix = job_id[:-2] # 예: "JOB01" -> "JOB"
                if prefix not in grouped:
                    grouped[prefix] = []
                grouped[prefix].append(item)
        
        # 각 그룹 내에서 job_id로 정렬
        for prefix in grouped:
            grouped[prefix].sort(key=lambda x: x.get('job_id', ''))
            
        return grouped
