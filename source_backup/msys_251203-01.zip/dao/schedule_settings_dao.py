# dao/schedule_settings_dao.py
import logging
from typing import Dict, Optional

class ScheduleSettingsDAO:
    def __init__(self, db_connection):
        self.conn = db_connection
        self.logger = logging.getLogger(self.__class__.__name__)

    def _execute_query(self, query: str, params: tuple = (), fetch_one: bool = False):
        with self.conn.cursor() as cursor:
            cursor.execute(query, params)
            if fetch_one:
                row = cursor.fetchone()
                if row:
                    columns = [desc[0] for desc in cursor.description]
                    return dict(zip(columns, row))
                return None
            
            rows = cursor.fetchall()
            if not rows:
                return []
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in rows]

    def get_schedule_settings(self) -> Optional[Dict]:
        """
        Fetches the latest schedule display settings from the database.
        The SQL now joins with the icon table to get the icon codes directly.
        """
        try:
            with open('sql/mngr_sett/get_schedule_settings.sql', 'r', encoding='utf-8') as f:
                query = f.read()
            
            settings = self._execute_query(query, fetch_one=True)
            return settings
        except Exception as e:
            self.logger.error(f"DAO: Failed to get schedule settings: {e}", exc_info=True)
            raise

    def update_schedule_settings(self, settings_data: Dict):
        """
        Updates an existing schedule settings record.
        """
        try:
            with open('sql/mngr_sett/update_schedule_settings.sql', 'r', encoding='utf-8') as f:
                query = f.read()
            
            # Ensure all keys are present, providing defaults if necessary
            params = {
                'grp_min_cnt': settings_data.get('grp_min_cnt'),
                'prgs_rt_red_thrsval': settings_data.get('prgs_rt_red_thrsval'),
                'prgs_rt_org_thrsval': settings_data.get('prgs_rt_org_thrsval'),
                'succ_rt_red_thrsval': settings_data.get('succ_rt_red_thrsval'),
                'succ_rt_org_thrsval': settings_data.get('succ_rt_org_thrsval'),
                'use_yn': settings_data.get('use_yn'),
                'grp_brdr_styl': settings_data.get('grp_brdr_styl'),
                'grp_colr_crtr': settings_data.get('grp_colr_crtr'),
                'sucs_icon_id': settings_data.get('sucs_icon_id'),
                'sucs_bg_colr': settings_data.get('sucs_bg_colr'),
                'sucs_txt_colr': settings_data.get('sucs_txt_colr'),
                'fail_icon_id': settings_data.get('fail_icon_id'),
                'fail_bg_colr': settings_data.get('fail_bg_colr'),
                'fail_txt_colr': settings_data.get('fail_txt_colr'),
                'prgs_icon_id': settings_data.get('prgs_icon_id'),
                'prgs_bg_colr': settings_data.get('prgs_bg_colr'),
                'prgs_txt_colr': settings_data.get('prgs_txt_colr'),
                'nodt_icon_id': settings_data.get('nodt_icon_id'),
                'nodt_bg_colr': settings_data.get('nodt_bg_colr'),
                'nodt_txt_colr': settings_data.get('nodt_txt_colr'),
                'schd_icon_id': settings_data.get('schd_icon_id'),
                'schd_bg_colr': settings_data.get('schd_bg_colr'),
                'schd_txt_colr': settings_data.get('schd_txt_colr'),
                'updr_id': settings_data.get('updr_id'),
                'grp_prgs_icon_id': settings_data.get('grp_prgs_icon_id'),
                'grp_sucs_icon_id': settings_data.get('grp_sucs_icon_id'),
                'sett_id': settings_data.get('sett_id')
            }
            
            with self.conn.cursor() as cursor:
                cursor.execute(query, params)

        except Exception as e:
            self.logger.error(f"DAO: Failed to update schedule settings for sett_id {settings_data.get('sett_id')}: {e}", exc_info=True)
            raise

    def create_schedule_settings(self, settings_data: Dict) -> int:
        """
        Creates a new schedule settings record and returns the new sett_id.
        """
        try:
            with open('sql/mngr_sett/create_schedule_settings.sql', 'r', encoding='utf-8') as f:
                query = f.read()

            params = {
                'grp_min_cnt': settings_data.get('grp_min_cnt'),
                'prgs_rt_red_thrsval': settings_data.get('prgs_rt_red_thrsval'),
                'prgs_rt_org_thrsval': settings_data.get('prgs_rt_org_thrsval'),
                'succ_rt_red_thrsval': settings_data.get('succ_rt_red_thrsval'),
                'succ_rt_org_thrsval': settings_data.get('succ_rt_org_thrsval'),
                'use_yn': settings_data.get('use_yn'),
                'grp_brdr_styl': settings_data.get('grp_brdr_styl'),
                'grp_colr_crtr': settings_data.get('grp_colr_crtr'),
                'sucs_icon_id': settings_data.get('sucs_icon_id'),
                'sucs_bg_colr': settings_data.get('sucs_bg_colr'),
                'sucs_txt_colr': settings_data.get('sucs_txt_colr'),
                'fail_icon_id': settings_data.get('fail_icon_id'),
                'fail_bg_colr': settings_data.get('fail_bg_colr'),
                'fail_txt_colr': settings_data.get('fail_txt_colr'),
                'prgs_icon_id': settings_data.get('prgs_icon_id'),
                'prgs_bg_colr': settings_data.get('prgs_bg_colr'),
                'prgs_txt_colr': settings_data.get('prgs_txt_colr'),
                'nodt_icon_id': settings_data.get('nodt_icon_id'),
                'nodt_bg_colr': settings_data.get('nodt_bg_colr'),
                'nodt_txt_colr': settings_data.get('nodt_txt_colr'),
                'schd_icon_id': settings_data.get('schd_icon_id'),
                'schd_bg_colr': settings_data.get('schd_bg_colr'),
                'schd_txt_colr': settings_data.get('schd_txt_colr'),
                'regr_id': settings_data.get('regr_id'),
                'updr_id': settings_data.get('updr_id'),
                'grp_prgs_icon_id': settings_data.get('grp_prgs_icon_id'),
                'grp_sucs_icon_id': settings_data.get('grp_sucs_icon_id')
            }

            with self.conn.cursor() as cursor:
                cursor.execute(query, params)
                new_id = cursor.lastrowid
            
            return new_id
        except Exception as e:
            self.logger.error(f"DAO: Failed to create schedule settings: {e}", exc_info=True)
            raise