-- 'admin' 사용자에게 'admin' 메뉴 접근 권한을 부여합니다.
-- 이 권한이 있어야 is_admin 플래그가 True로 설정됩니다.
INSERT INTO tb_user_auth_ctrl (user_id, menu_id)
SELECT 'admin', 'admin'
WHERE NOT EXISTS (
    SELECT 1
    FROM tb_user_auth_ctrl
    WHERE user_id = 'admin' AND menu_id = 'admin'
);
