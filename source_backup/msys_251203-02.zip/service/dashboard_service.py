# service/dashboard_service.py
"""
Dashboard and Analytics Business Logic
Handles fetching and processing data for the dashboard and analytics pages.
"""
import logging
from typing import Optional, List, Dict
from mapper.dashboard_mapper import DashboardMapper
from mapper.user_mapper import UserMapper
from msys.database import get_db_connection
# Service Dependencies (Settings)
from mapper.mngr_sett_mapper import MngrSettMapper
from service.mngr_sett_service import DEFAULT_ADMIN_SETTINGS
from service.icon_service import IconService


class DashboardService:
    """
    Provides methods to retrieve data for the dashboard and analytics charts.
    """

    def __init__(self, db_connection):
        self.conn = db_connection
        self.dashboard_mapper = DashboardMapper(db_connection)
        self.user_mapper = UserMapper(db_connection)
        self.mngr_sett_mapper = MngrSettMapper(db_connection)

    def get_summary(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False, user: Optional[Dict] = None) -> List[Dict]:
        user_id_log = user.get('user_id') if user else 'None'
        logging.info(f"DashboardService.get_summary called for user: {user_id_log}")

        # 1. Fetch all manager settings and create a lookup map
        try:
            # 1. Fetch raw settings and icon data
            all_settings_raw = self.mngr_sett_mapper.get_all_settings()
            
            icon_service = IconService(self.conn)
            all_icons = icon_service.get_all_icons_data()
            icon_code_map = {icon['icon_id']: icon['icon_cd'] for icon in all_icons}

            # 2. Add icon codes to each setting object
            all_settings_with_codes = []
            for setting_raw in all_settings_raw:
                combined_setting = setting_raw.copy()
                icon_fields = [
                    'cnn_failr_icon_id', 'cnn_warn_icon_id', 'cnn_sucs_icon_id',
                    'sucs_rt_sucs_icon_id', 'sucs_rt_warn_icon_id'
                ]
                for field in icon_fields:
                    icon_id = combined_setting.get(field)
                    combined_setting[f'{field}_code'] = icon_code_map.get(icon_id)
                all_settings_with_codes.append(combined_setting)

            # 3. Create the final settings map
            settings_map = {setting['cd']: setting for setting in all_settings_with_codes}
            logging.info(f"Successfully fetched and mapped {len(settings_map)} manager settings with icon codes.")
        except Exception as e:
            logging.error(f"Failed to fetch manager settings in DashboardService: {e}", exc_info=True)
            settings_map = {}

        # 2. Check data access permissions
        if not user:
            logging.info("User object not provided, skipping permission checks for internal call.")
            allowed_job_ids = None
        else:
            is_admin = 'mngr_sett' in user.get('permissions', [])
            user_id = user.get('user_id', 'Unknown')
            logging.info(f"Checking data permissions for user: {user_id}, is_admin: {is_admin}")
            
            allowed_job_ids = None
            if not is_admin:
                if user_id:
                    allowed_job_ids = self.user_mapper.find_data_permissions_by_user_id(user_id)
                    logging.info(f"Non-admin user. Applying data permissions. Allowed jobs: {allowed_job_ids}")
                
                if not allowed_job_ids:
                    logging.warning(f"User {user_id} has no data permissions. Returning empty summary.")
                    return []
            else:
                logging.info(f"Admin user {user_id}. No data permission filtering applied.")

        # 3. Fetch summary data
        summary_data = self.dashboard_mapper.get_summary(start_date, end_date, all_data, allowed_job_ids)
        # --- [LOG] 원천 데이터 수량 기록 ---
        source_total_count = len(summary_data)
        source_cd101_count = sum(1 for item in summary_data if item.get('job_id') == 'CD101')
        source_cd102_count = sum(1 for item in summary_data if item.get('job_id') == 'CD102')
        logging.info(f"--- [DATA LOG] Dashboard - Source Data Count: Total={source_total_count}, CD101={source_cd101_count}, CD102={source_cd102_count}")


        # 4. Combine summary data with settings
        processed_summary_data = []
        for item in summary_data:
            job_id = item.get('job_id')
            job_settings = settings_map.get(job_id, DEFAULT_ADMIN_SETTINGS)

            # Apply 'Dashboard Display Y/N' setting
            if job_settings.get('CHRT_DSP_YN', 'Y').upper() == 'N':
                logging.info(f"Skipping job '{job_id}' from dashboard summary as per CHRT_DSP_YN setting.")
                continue
            
            item['settings'] = job_settings
            processed_summary_data.append(item)

        # --- [LOG] 최종 데이터 수량 기록 ---
        final_total_count = len(processed_summary_data)
        final_cd101_count = sum(1 for item in processed_summary_data if item.get('job_id') == 'CD101')
        final_cd102_count = sum(1 for item in processed_summary_data if item.get('job_id') == 'CD102')
        logging.info(f"--- [DATA LOG] Dashboard - Final Data Count: Total={final_total_count}, CD101={final_cd101_count}, CD102={final_cd102_count}")
            
        return processed_summary_data

    def get_min_max_dates(self) -> Optional[Dict]:
        return self.dashboard_mapper.get_min_max_dates()

    def get_analytics_success_rate_trend(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        trend_data = self.dashboard_mapper.get_analytics_success_rate_trend(start_date, end_date, allowed_job_ids)
        return trend_data

    def get_trouble_by_code(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        trouble_data = self.dashboard_mapper.get_analytics_trouble_by_code(start_date, end_date, allowed_job_ids)
        return trouble_data

    def get_raw_data(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None, all_data: bool = False, use_kst_today: bool = False, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        raw_data = self.dashboard_mapper.get_raw_data(start_date, end_date, allowed_job_ids, all_data, use_kst_today)
        return raw_data

    def get_event_log(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False, user: Optional[Dict] = None) -> List[Dict]:
        logging.info(f"--- [DEBUG] get_event_log called. User: {user}")
        
        event_log_data = self.dashboard_mapper.get_event_log(start_date, end_date, all_data)
        
        is_admin = user and 'mngr_sett' in user.get('permissions', [])
        logging.info(f"--- [DEBUG] Is admin? {is_admin}")

        # if user is admin, return all logs.
        if not user or is_admin:
            logging.info(f"--- [DEBUG] Returning all {len(event_log_data)} event logs for admin or no user.")
            return event_log_data
        
        # if user is not admin, filter system logs.
        user_id = user.get('user_id', 'Unknown')
        logging.info(f"--- [DEBUG] Filtering logs for non-admin user '{user_id}'. Total logs before filter: {len(event_log_data)}")

        filtered_logs = []
        for log in event_log_data:
            # job_id가 None일 경우를 대비해 기본값을 빈 문자열로 설정
            job_id_str = str(log.get('job_id') or '').lower()
            status_str = str(log.get('status') or '')

            # 필터링 조건: job_id에 'system'이 포함되거나, status가 인증 관련인 경우
            is_system_by_id = 'system' in job_id_str
            is_system_by_status = status_str.startswith('AUTH_') or status_str == 'LOGIN_SUCCESS'

            if is_system_by_id or is_system_by_status:
                logging.info(f"--- [DEBUG] Filtering out log for user '{user_id}': job_id='{log.get('job_id')}', status='{status_str}'")
                continue  # 이 로그는 건너뜀
            
            filtered_logs.append(log)

        logging.info(f"--- [DEBUG] Total logs for user '{user_id}' after filter: {len(filtered_logs)}")
        return filtered_logs

    def get_distinct_job_ids(self, user: Optional[Dict] = None) -> List[str]:
        allowed_job_ids = self._get_allowed_job_ids(user)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        job_ids = self.dashboard_mapper.get_distinct_job_ids(job_ids=allowed_job_ids)
        return job_ids

    def save_event(self, con_id: Optional[str], job_id: Optional[str], status: str, rqs_info: str):
        self.dashboard_mapper.save_event(con_id, job_id, status, rqs_info)

    def get_daily_job_counts(self, job_id: Optional[str], start_date: Optional[str], end_date: Optional[str], all_data: bool, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = None
        if user:
            is_admin = 'mngr_sett' in user.get('permissions', [])
            user_id = user.get('user_id', 'Unknown')
            logging.info(f"Checking data permissions for user: {user_id}, is_admin: {is_admin} in get_daily_job_counts")
            if not is_admin:
                allowed_job_ids = user.get('data_permissions', [])
                logging.info(f"Non-admin user in get_daily_job_counts. Applying data permissions. Allowed jobs: {allowed_job_ids}")
                if not allowed_job_ids:
                    logging.warning(f"User {user_id} has no data permissions. Returning empty daily job counts.")
                    return []
            else:
                logging.info(f"Admin user {user_id} in get_daily_job_counts. No data permission filtering applied.")
        
        data = self.dashboard_mapper.get_daily_job_counts(job_id, start_date, end_date, all_data, job_ids=allowed_job_ids)
        return data

    def get_distinct_error_codes(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False, user: Optional[Dict] = None) -> List[str]:
        allowed_job_ids = self._get_allowed_job_ids(user)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        error_codes = self.dashboard_mapper.get_distinct_error_codes(start_date, end_date, all_data, job_ids=allowed_job_ids)
        return error_codes

    def get_collection_history_for_schedule(self, start_date: str, end_date: str, job_ids: Optional[List[str]] = None, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        return self.dashboard_mapper.get_collection_history_for_schedule(start_date, end_date, allowed_job_ids)
        
    def _get_allowed_job_ids(self, user: Optional[Dict], requested_job_ids: Optional[List[str]] = None) -> Optional[List[str]]:
        if not user or 'mngr_sett' in user.get('permissions', []):
            return requested_job_ids

        user_permissions = set(user.get('data_permissions', []))
        if not user_permissions:
            return []

        if requested_job_ids:
            allowed = list(user_permissions.intersection(set(requested_job_ids)))
            logging.info(f"User requested {requested_job_ids}, allowed: {allowed}")
            return allowed
        
        return list(user_permissions)
