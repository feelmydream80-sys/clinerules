# dao/schedule_settings_dao.py
"""
DAO for handling schedule settings data (tb_data_clt_schd_sett) in the database.
"""
import logging
from typing import Dict, Optional
import psycopg2
from psycopg2.extras import RealDictCursor
from dao.sql_loader import load_sql

class ScheduleSettingsDAO:
    """
    Data Access Object for schedule settings.
    Handles all database operations for the tb_data_clt_schd_sett table.
    """
    def __init__(self, db_connection):
        self.conn = db_connection
        self.logger = logging.getLogger(self.__class__.__name__)

    def get_schedule_settings(self) -> Optional[Dict]:
        """
        Retrieves the schedule settings from the database.
        Since there is only one row of settings, it fetches the first one.
        """
        query = """
            SELECT
                sett_id,
                grp_min_cnt,
                prgs_rt_red_thrsval,
                prgs_rt_org_thrsval,
                use_yn
            FROM
                tb_data_clt_schd_sett
            ORDER BY
                updr_dt DESC, sett_id DESC
            LIMIT 1
        """
        try:
            with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(query)
                result = cur.fetchone()
                self.logger.info(f"✅✅✅ DAO: DB에서 조회된 원본 데이터: {result}")
                if result:
                    self.logger.info(f"✅ DAO: Successfully fetched schedule settings.")
                    return dict(result)
                else:
                    self.logger.warning("🤔 DAO: No schedule settings found in tb_data_clt_schd_sett.")
                    return None
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error fetching schedule settings: {e}", exc_info=True)
            raise
        except Exception as e:
            self.logger.error(f"❌ DAO: An unexpected error occurred while fetching schedule settings: {e}", exc_info=True)
            raise

    def create_schedule_settings(self, settings_data: Dict) -> int:
        """
        Creates a new schedule settings record in the database.
        Returns the ID of the newly created record.
        """
        query = load_sql('mngr_sett/create_schedule_settings.sql')
        try:
            with self.conn.cursor() as cur:
                params = {
                    'grp_min_cnt': settings_data.get('grp_min_cnt'),
                    'prgs_rt_red_thrsval': settings_data.get('prgs_rt_red_thrsval'),
                    'prgs_rt_org_thrsval': settings_data.get('prgs_rt_org_thrsval'),
                    'use_yn': settings_data.get('use_yn', 'Y'),
                    'regr_id': settings_data.get('regr_id', 'system'),
                    'updr_id': settings_data.get('updr_id', 'system')
                }
                cur.execute(query, params)
                new_id = cur.fetchone()[0]
                self.logger.info(f"✅ DAO: Successfully created new schedule settings with ID {new_id}.")
                return new_id
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error creating schedule settings: {e}", exc_info=True)
            raise

    def update_schedule_settings(self, settings_data: Dict):
        """
        Updates the schedule settings in the database.
        """
        query = load_sql('mngr_sett/update_schedule_settings.sql')
        try:
            with self.conn.cursor() as cur:
                params = {
                    'sett_id': settings_data.get('sett_id'),
                    'grp_min_cnt': settings_data.get('grp_min_cnt'),
                    'prgs_rt_red_thrsval': settings_data.get('prgs_rt_red_thrsval'),
                    'prgs_rt_org_thrsval': settings_data.get('prgs_rt_org_thrsval'),
                    'use_yn': settings_data.get('use_yn', 'Y'),
                    'updr_id': settings_data.get('updr_id', 'system')
                }
                cur.execute(query, params)
                # 업데이트된 행이 있는지 확인
                if cur.rowcount == 0:
                    self.logger.warning(f"🤔 DAO: Update failed. No rows found for sett_id {settings_data.get('sett_id')}")
                    raise ValueError(f"ID가 {settings_data.get('sett_id')}인 설정을 찾을 수 없어 업데이트에 실패했습니다.")
                self.logger.info(f"✅ DAO: Successfully updated schedule settings for ID {params['sett_id']}.")
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error updating schedule settings for ID {settings_data.get('sett_id')}: {e}", exc_info=True)
            raise