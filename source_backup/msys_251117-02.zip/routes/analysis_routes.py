from flask import Blueprint, request, jsonify, render_template, session, current_app
import logging
from datetime import datetime
from functools import wraps
import pytz

from msys.database import get_db_connection
from dao.analytics_dao import AnalyticsDAO
from service.dashboard_service import DashboardService
from service.mst_service import ConMstService
from service.analysis_service import AnalysisService
from .auth_routes import login_required, check_password_change_required

analysis_bp = Blueprint('analysis', __name__)

def log_menu_access(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            user_id = session.get('user', {}).get('user_id')
            if user_id:
                menu_name = request.endpoint
                
                with get_db_connection() as conn:
                    analytics_dao = AnalyticsDAO(conn)
                    analytics_dao.insert_user_access_log(user_id, menu_name)
        except Exception as e:
            current_app.logger.error(f"Failed to log menu access for endpoint {request.endpoint}: {e}")
        
        return f(*args, **kwargs)
    return decorated_function

@analysis_bp.route("/chart-analysis")
@login_required
@check_password_change_required
@log_menu_access
def chart_analysis():
    logging.info("Serving chart_analysis.html")
    return render_template("chart_analysis.html")

@analysis_bp.route("/data-analysis")
@login_required
@check_password_change_required
@log_menu_access
def data_analysis():
    logging.info("Serving data_analysis.html")
    return render_template("data_analysis.html")

@analysis_bp.route('/api/analytics/success_rate_trend', methods=['GET'])
@login_required
@check_password_change_required
def get_analytics_success_rate_trend_api():
    """
    [분석 차트용] 기간별 Job ID별 수집 성공률 추이 데이터를 제공하는 API.
    """
    logging.info("▶ API: /api/analytics/success_rate_trend 요청 수신")
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date_str = request.args.get('start_date')
            end_date_str = request.args.get('end_date')
            job_ids = request.args.getlist('job_ids')

            if not start_date_str or not end_date_str:
                return jsonify({"message": "시작 및 종료 날짜가 필요합니다."}), 400
            try:
                start_date_obj = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date_obj = datetime.strptime(end_date_str, '%Y-%m-%d').date()
                if start_date_obj > end_date_obj:
                    return jsonify({"message": "시작 날짜는 종료 날짜보다 빠를 수 없습니다."}), 400
            except ValueError:
                return jsonify({"message": "날짜 형식이 유효하지 않습니다.YYYY-MM-DD 형식을 사용해주세요."}), 400

            trend_data = dashboard_service.get_analytics_success_rate_trend(start_date_str, end_date_str, job_ids)
            return jsonify(trend_data), 200
    except Exception as e:
        logging.error(f"❌ API: 분석 성공률 추이 데이터 조회 실패: {e}", exc_info=True)
        return jsonify({"message": "분석 성공률 추이 데이터 조회 중 오류가 발생했습니다."}), 500

@analysis_bp.route('/api/analytics/trouble_by_code', methods=['GET'])
@login_required
@check_password_change_required
def get_analytics_trouble_by_code_api():
    """
    [분석 차트용] 장애 코드별 비율 데이터를 제공하는 API.
    """
    logging.info("▶ API: /api/analytics/trouble_by_code 요청 수신")
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date_str = request.args.get('start_date')
            end_date_str = request.args.get('end_date')
            job_ids = request.args.getlist('job_ids')

            if not start_date_str or not end_date_str:
                return jsonify({"message": "시작 및 종료 날짜가 필요합니다."}), 400
            try:
                start_date_obj = datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date_obj = datetime.strptime(end_date_str, '%Y-%m-%d').date()
                if start_date_obj > end_date_obj:
                    return jsonify({"message": "시작 날짜는 종료 날짜보다 빠를 수 없습니다."}), 400
            except ValueError:
                return jsonify({"message": "날짜 형식이 유효하지 않습니다.YYYY-MM-DD 형식을 사용해주세요."}), 400

            trouble_data = dashboard_service.get_trouble_by_code(start_date_str, end_date_str, job_ids)
            return jsonify(trouble_data), 200
    except Exception as e:
        logging.error(f"❌ API: 분석 장애 데이터 조회 중 오류 발생: {e}", exc_info=True)
        return jsonify({"message": "분석 장애 데이터 조회 중 오류이 발생했습니다."}), 500

@analysis_bp.route('/api/analysis/summary', methods=['GET'])
@login_required
@check_password_change_required
def api_analysis_summary():
    """
    [공통화] 대시보드와 데이터 구조/필터링 방식이 완전히 동일하므로,
    중복 방지를 위해 대시보드 summary API를 그대로 재사용함.
    """
    # Re-implementing the logic from get_dashboard_summary to avoid direct call
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date_str = request.args.get('start_date')
            end_date_str = request.args.get('end_date')
            all_data_str = request.args.get('all_data', 'false')
            all_data = all_data_str.lower() == 'true'

            if not all_data:
                if not start_date_str or not end_date_str:
                    return jsonify({"message": "시작 및 종료 날짜가 필요합니다."}), 400
            
            summary_data = dashboard_service.get_summary(start_date_str, end_date_str, all_data)
            
            # Convert datetime objects to KST strings before jsonify
            kst = pytz.timezone('Asia/Seoul')
            utc = pytz.utc
            for item in summary_data:
                for key, value in item.items():
                    if isinstance(value, datetime):
                        if value.tzinfo is None:
                            value = utc.localize(value)
                        item[key] = value.astimezone(kst).strftime('%Y-%m-%d %H:%M:%S')
                    elif value is None:
                        item[key] = ''
            
            return jsonify(summary_data), 200
    except Exception as e:
        logging.error(f"❌ API: 분석 요약 데이터 조회 실패: {e}", exc_info=True)
        return jsonify({"message": "데이터 조회 중 오류가 발생했습니다."}), 500

@analysis_bp.route('/api/analysis/trend', methods=['GET'])
@login_required
@check_password_change_required
def api_analysis_trend():
    """
    데이터분석 추이/경향 데이터를 제공하는 API.
    """
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date = request.args.get('start_date')
            end_date = request.args.get('end_date')
            job_ids_str = request.args.get('job_ids')
            job_ids = job_ids_str.split(',') if job_ids_str else None
            data = dashboard_service.get_analytics_success_rate_trend(start_date, end_date, job_ids)
            
            # Convert datetime objects to KST strings before jsonify
            kst = pytz.timezone('Asia/Seoul')
            utc = pytz.utc
            for item in data:
                for key, value in item.items():
                    if isinstance(value, datetime):
                        if value.tzinfo is None:
                            value = utc.localize(value)
                        item[key] = value.astimezone(kst).strftime('%Y-%m-%d %H:%M:%S')
                    elif value is None:
                        item[key] = ''

            return jsonify(data), 200
    except Exception as e:
        return jsonify({'message': f'추이 데이터 조회 실패: {e}'}), 500

@analysis_bp.route('/api/analysis/raw_data', methods=['GET'])
@login_required
@check_password_change_required
def api_analysis_raw_data():
    """
    데이터분석 원천데이터(상세 로그) API.
    """
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date = request.args.get('start_date')
            end_date = request.args.get('end_date')
            job_ids_str = request.args.get('job_ids')
            job_ids = job_ids_str.split(',') if job_ids_str else None
            rows = dashboard_service.get_raw_data(start_date, end_date, job_ids, all_data=False)
            
            # Convert datetime objects to KST strings before jsonify
            kst = pytz.timezone('Asia/Seoul')
            utc = pytz.utc
            for item in rows:
                for key, value in item.items():
                    if isinstance(value, datetime):
                        if value.tzinfo is None:
                            value = utc.localize(value)
                        item[key] = value.astimezone(kst).strftime('%Y-%m-%d %H:%M:%S')
                    elif value is None:
                        item[key] = ''

            return jsonify(rows), 200
    except Exception as e:
        return jsonify({'message': f'원천데이터 조회 실패: {e}'}), 500

@analysis_bp.route('/api/analysis/job_ids', methods=['GET'])
@login_required
@check_password_change_required
def api_analysis_job_ids():
    """
    tb_con_hist에 실제로 존재하는 job_id만 중복 없이 반환하는 API.
    """
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            job_ids = dashboard_service.get_distinct_job_ids()
            result = [{"job_id": job_id} for job_id in job_ids if job_id]
            return jsonify(result), 200
    except Exception as e:
        return jsonify({'message': f'Job ID 목록 조회 실패: {e}'}), 500

@analysis_bp.route('/api/analysis/error_codes', methods=['GET'])
def api_analysis_error_codes():
    """
    tb_con_hist에서 실제 존재하는 장애코드(status) 목록을 반환하는 API.
    """
    try:
        with get_db_connection() as conn:
            dashboard_service = DashboardService(conn)
            start_date = request.args.get('start_date')
            end_date = request.args.get('end_date')
            all_data_str = request.args.get('all_data', 'false')
            all_data = all_data_str.lower() == 'true'
            
            # dashboard_service를 통해 데이터 조회
            error_codes = dashboard_service.get_distinct_error_codes(start_date, end_date, all_data)
            
            status_names = {
                'CD901': '정상(성공)',
                'CD902': '실패',
                'CD903': '미수집',
                'CD904': '계측중'
            }
            
            result = [{"code": code, "name": status_names.get(code, code)} for code in error_codes]
            return jsonify(result), 200
    except Exception as e:
        logging.error(f"❌ API: 장애코드 목록 조회 실패: {e}", exc_info=True)
        return jsonify({'message': f'장애코드 목록 조회 실패: {e}'}), 500

@analysis_bp.route('/api/analysis/error_code_map', methods=['GET'])
@login_required
@check_password_change_required
def api_analysis_error_code_map():
    """
    tb_con_mst에서 cd_cl='CD900'인 장애코드와 item1(영문명) 매핑만 반환
    """
    try:
        with get_db_connection() as conn:
            mst_service = ConMstService(conn)
            rows = mst_service.get_error_code_map()
            code_map = {row['cd']: row['item1'] for row in rows}
            return jsonify(code_map), 200
    except Exception as e:
        return jsonify({'message': f'장애코드 매핑 조회 실패: {e}'}), 500

@analysis_bp.route('/api/analysis/dynamic-chart', methods=['GET'])
@login_required
@check_password_change_required
def get_dynamic_chart_data():
    """
    사용자 정의 파라미터를 기반으로 동적 차트 데이터를 제공하는 API.
    ---
    parameters:
      - name: x_axis
        in: query
        type: string
        required: true
        description: '차트의 X축으로 사용할 차원 (예: date, job_id, status)'
        enum: ['date', 'job_id', 'status']
      - name: y_axis
        in: query
        type: string
        required: true
        description: '차트의 Y축으로 사용할 측정 항목 (예: success_count, fail_count, total_count, success_rate)'
        enum: ['success_count', 'fail_count', 'no_data_count', 'total_count', 'success_rate']
      - name: group_by
        in: query
        type: string
        required: false
        description: '데이터를 그룹화할 추가 차원 (예: job_id, status)'
        enum: ['job_id', 'status']
      - name: start_date
        in: query
        type: string
        required: true
        description: '조회 시작 날짜 (YYYY-MM-DD)'
      - name: end_date
        in: query
        type: string
        required: true
        description: '조회 종료 날짜 (YYYY-MM-DD)'
      - name: job_ids
        in: query
        type: array
        items:
          type: string
        required: false
        description: '필터링할 Job ID 목록'
    responses:
      200:
        description: '동적 차트 데이터 조회 성공'
        schema:
          type: array
          items:
            type: object
      400:
        description: '필수 파라미터 누락 또는 유효하지 않은 파라미터'
      500:
        description: '서버 내부 오류'
    """
    logging.info("▶ API: /api/analysis/dynamic-chart 요청 수신")
    try:
        with get_db_connection() as conn:
            analysis_service = AnalysisService(conn)
            params = {
                'x_axis': request.args.get('x_axis'),
                'y_axis': request.args.get('y_axis'),
                'group_by': request.args.get('group_by'),
                'start_date': request.args.get('start_date'),
                'end_date': request.args.get('end_date'),
                'job_ids': request.args.getlist('job_ids')
            }
            
            # 필수 파라미터 검증
            if not all([params['x_axis'], params['y_axis'], params['start_date'], params['end_date']]):
                return jsonify({"message": "x_axis, y_axis, start_date, end_date는 필수 파라미터입니다."}), 400

            chart_data = analysis_service.get_dynamic_chart_data(params)
            return jsonify(chart_data), 200
    except ValueError as ve:
        logging.error(f"❌ API: 유효하지 않은 파라미터: {ve}", exc_info=True)
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        logging.error(f"❌ API: 동적 차트 데이터 조회 실패: {e}", exc_info=True)
        return jsonify({"message": "동적 차트 데이터 조회 중 오류가 발생했습니다."}), 500
