# routes/__init__.py

def init_app(app):
    from . import auth_routes
    from . import data_spec_routes
    from . import jandi_routes
    from . import mngr_sett_routes
    from . import analysis_routes
    from . import api_routes
    from . import dashboard_routes
    from . import mapping_routes
    from . import admin_routes
    from . import card_summary_routes

    app.register_blueprint(auth_routes.auth_bp)
    app.register_blueprint(data_spec_routes.bp)
    app.register_blueprint(jandi_routes.bp)
    app.register_blueprint(mngr_sett_routes.mngr_sett_bp)
    app.register_blueprint(mngr_sett_routes.api_mngr_sett_bp)
    app.register_blueprint(analysis_routes.analysis_bp)
    app.register_blueprint(api_routes.api_bp)
    app.register_blueprint(dashboard_routes.dashboard_bp)
    app.register_blueprint(mapping_routes.mapping_bp)
    app.register_blueprint(admin_routes.admin_bp)
    app.register_blueprint(card_summary_routes.card_summary_bp)
