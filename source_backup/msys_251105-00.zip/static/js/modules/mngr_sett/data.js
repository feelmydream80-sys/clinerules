import { showMessage } from '../common/utils.js';
import { fetchAllMngrSett, fetchAllIcons } from '../common/api/mngr_sett.js';

// @DOC: 이 파일은 서버로부터 관리자 설정 관련 데이터를 가져오고 관리하는 역할을 합니다.
// 데이터 캐싱을 통해 중복 API 호출을 방지하고 애플리케이션의 성능을 향상시킵니다.

/**
 * @description 모든 아이콘 데이터를 저장하는 전역 변수 배열입니다.
 * @type {Array<Object>}
 * @example
 * // allIcons 배열의 데이터 구조 예시:
 * // [
 * //   { ICON_ID: 1, ICON_CD: 'fas fa-star', ICON_NM: '별', ICON_EXPL: '중요 항목', ICON_DSP_YN: true },
 * //   { ICON_ID: 2, ICON_CD: 'fas fa-heart', ICON_NM: '하트', ICON_EXPL: '선호 항목', ICON_DSP_YN: true }
 * // ]
 */
export let allIcons = [];

/**
 * @description 모든 관리자 설정 데이터를 저장하는 전역 변수 배열입니다.
 * @type {Array<Object>}
 * @example
 * // allAdminSettings 배열의 데이터 구조 예시:
 * // [
 * //   { CD: 'JOB001', cd_nm: '일일 배치', CNN_FAILR_THRS_VAL: 10, CNN_FAILR_ICON_ID: 1, ... },
 * //   { CD: 'JOB002', cd_nm: '주간 리포트', CNN_FAILR_THRS_VAL: 5, CNN_FAILR_ICON_ID: 2, ... }
 * // ]
 */
export let allMngrSett = [];

/**
 * @DOC: 서버에서 모든 관리자 설정 데이터를 비동기적으로 가져와 `allAdminSettings` 변수에 캐싱합니다.
 * 이 데이터는 각 Job ID에 대한 상세 설정 값을 포함합니다.
 * @returns {Promise<Array<Object>>} 성공 시 관리자 설정 데이터 배열을, 실패 시 에러를 반환합니다.
 */
export async function loadAllMngrSett() {
    console.log("Loading all manager settings...");
    try {
        allMngrSett = await fetchAllMngrSett();
        console.log("Manager settings loaded 개수:", allMngrSett.length);
        if (allMngrSett.length > 0) {
            console.log("Manager settings 첫 번째 데이터:", allMngrSett[0]);
        }
        return allMngrSett;
    } catch (error) {
        console.error("Failed to load manager settings:", error);
        showMessage('관리자 설정 로드 실패: ' + error.message, 'error');
        throw error;
    }
}

/**
 * @DOC: 서버에서 모든 아이콘 데이터를 비동기적으로 가져와 `allIcons` 변수에 캐싱합니다.
 * 이 데이터는 아이콘 선택 드롭다운 및 아이콘 관리 테이블에 사용됩니다.
 * @returns {Promise<Array<Object>>} 성공 시 아이콘 데이터 배열을, 실패 시 에러를 반환합니다.
 */
export async function loadAllIcons() {
    console.log("Loading all icons...");
    try {
        allIcons = await fetchAllIcons();
        console.log("Icons loaded (allIcons array content):", allIcons);
        return allIcons;
    } catch (error) {
        console.error("Failed to load icons:", error);
        showMessage('아이콘 목록 로드 실패: ' + error.message, 'error');
        throw error;
    }
}
