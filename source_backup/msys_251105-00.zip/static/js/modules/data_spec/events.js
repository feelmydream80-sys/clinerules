// static/js/modules/data_spec/events.js

/**
 * @module events
 * @description 데이터 명세 페이지의 이벤트 처리 및 메인 로직을 담당합니다.
 * 
 * @example
 * import { initializePage } from './events.js';
 * 
 * document.addEventListener('DOMContentLoaded', initializePage);
 */

import * as api from './api.js';
import * as ui from './ui.js';
import { initUrlMapper } from './urlMapper.js';
import { initCollapsibleFeatures } from '../ui_components/collapsible.js';
import { initPagination } from '../ui_components/pagination.js';

/**
 * @description 명세 목록을 비동기적으로 로드하고 UI를 갱신합니다.
 */
async function loadSpecs() {
    try {
        const specs = await api.getSpecs();
        initPagination({
            fullData: specs,
            pageSize: 10,
            renderTableCallback: (pageData) => ui.renderSpecList(pageData, handleViewSpec),
            paginationId: 'specPagination',
            pageSizeId: 'specPageSize',
            searchId: 'specSearch',
        });
    } catch (error) {
        console.error('Error loading specs:', error);
        alert('명세서 목록을 불러오는 데 실패했습니다.');
    }
}

/**
 * @description '새로 만들기' 버튼 클릭 이벤트 핸들러
 */
function handleAddNew() {
    ui.resetForm();
    ui.elements.modalTitle.textContent = '새 명세서 등록 (수동)';
    ui.openModal();
}

/**
 * @description 명세 목록에서 특정 항목 클릭 이벤트 핸들러
 * @param {string} id - 조회할 명세 ID
 */
async function handleViewSpec(id) {
    try {
        const spec = await api.getSpecById(id);
        ui.populateForm(spec);
        ui.openModal();
    } catch (error) {
        console.error(`Error fetching spec ${id}:`, error);
        alert('상세 정보를 불러오는 데 실패했습니다.');
    }
}

/**
 * @description URL 스크래핑 버튼 클릭 이벤트 핸들러
 */
async function handleScrape() {
    const url = ui.elements.scrapeUrlInput.value.trim();
    if (!url) {
        alert('URL을 입력해주세요.');
        return;
    }

    ui.elements.scrapeBtn.disabled = true;
    ui.elements.scrapeStatus.textContent = '가져오는 중...';
    ui.elements.scrapeStatus.className = 'text-gray-500 text-sm';

    try {
        const data = await api.scrapeSpec(url);
        ui.populateForm({}, [], data);
        ui.openModal();
        ui.elements.scrapeStatus.textContent = '가져오기 성공! 팝업에서 내용을 확인하고 저장하세요.';
        ui.elements.scrapeStatus.className = 'text-green-500 text-sm';
    } catch (error) {
        console.error('Scraping error:', error);
        ui.elements.scrapeStatus.textContent = `가져오기 실패: ${error.message}`;
        ui.elements.scrapeStatus.className = 'text-red-500 text-sm';
    } finally {
        ui.elements.scrapeBtn.disabled = false;
    }
}

/**
 * @description 명세 저장 로직
 * @param {string|null} password - 저장 시 사용할 비밀번호
 */
async function handleSave() {
    const getParamsFromTable = (container, paramType) => {
        return Array.from(container.querySelectorAll('tbody tr')).map(row => {
            const cells = row.querySelectorAll('td');
            return cells.length >= 4 ? {
                param_type: paramType,
                name_ko: cells[0].textContent,
                name_en: cells[1].textContent,
                is_required: cells[2].textContent === 'Y',
                description: cells[3].textContent
            } : null;
        }).filter(p => p);
    };

    const specData = {
        data_name: ui.elements.dataNameInput.value,
        provider: ui.elements.providerInput.value,
        api_url: ui.elements.apiUrlInput.value,
        reference_doc_url: ui.elements.refDocUrlInput.value,
        keywords: ui.elements.keywordsInput.value,
        description: ui.elements.descriptionInput.value,
        password: ui.elements.passwordInput.value,
    };

    const requestParams = getParamsFromTable(ui.elements.requestParamsContainer, 'request');
    const responseParams = getParamsFromTable(ui.elements.responseParamsContainer, 'response');

    const payload = { spec: specData, params: [...requestParams, ...responseParams] };

    if (!specData.data_name) {
        ui.elements.saveStatus.textContent = '데이터 명칭은 필수입니다.';
        ui.elements.saveStatus.className = 'text-red-500 text-sm';
        return;
    }
    
    const id = ui.elements.specIdInput.value;
    if (!id && (!specData.password || specData.password.length < 4)) {
        ui.elements.saveStatus.textContent = '새 명세서에는 4자리 이상의 비밀번호가 필수입니다.';
        ui.elements.saveStatus.className = 'text-red-500 text-sm';
        return;
    }

    ui.elements.saveStatus.textContent = '저장 중...';
    ui.elements.saveStatus.className = 'text-gray-500 text-sm';

    try {
        const result = await api.saveSpec(ui.elements.specIdInput.value, payload);
        if (!ui.elements.specIdInput.value && result.spec_id) {
            ui.elements.specIdInput.value = result.spec_id;
            ui.elements.deleteBtn.classList.remove('hidden');
            ui.elements.modalTitle.textContent = '명세 상세 정보';
        }
        ui.elements.saveStatus.textContent = '저장됨';
        ui.elements.saveStatus.className = 'text-green-500 text-sm';
        loadSpecs();
        ui.closeModal();
    } catch (error) {
        console.error('Save error:', error);
        ui.elements.saveStatus.textContent = `저장 실패: ${error.message}`;
        ui.elements.saveStatus.className = 'text-red-500 text-sm';
    }
}

async function handleSaveWithCheck() {
    const name = ui.elements.dataNameInput.value.trim();
    const id = ui.elements.specIdInput.value;
    const nameErrorMsg = document.getElementById('data-name-error');

    if (!name) {
        nameErrorMsg.textContent = '데이터 명칭은 필수 항목입니다.';
        nameErrorMsg.classList.remove('hidden');
        return;
    }

    try {
        const response = await api.checkName(name, id);
        if (response.exists) {
            nameErrorMsg.textContent = '이미 사용중인 데이터 명칭입니다.';
            nameErrorMsg.classList.remove('hidden');
            return;
        }
        nameErrorMsg.classList.add('hidden');
        await handleSave();
    } catch (error) {
        console.error('Error checking name or saving:', error);
        nameErrorMsg.textContent = '이름 확인 또는 저장 중 오류가 발생했습니다.';
        nameErrorMsg.classList.remove('hidden');
    }
}

/**
 * @description 삭제 버튼 클릭 이벤트 핸들러
 */
async function handleDelete() {
    const id = ui.elements.specIdInput.value;
    if (!id) return;

    const password = ui.elements.passwordInput.value;

    // 상세 모달에 비밀번호가 입력된 경우, 해당 비밀번호로 즉시 삭제 시도
    if (password) {
        try {
            ui.elements.deleteBtn.disabled = true;
            await api.deleteSpec(id, password);
            // alert('성공적으로 삭제되었습니다.'); // 팝업 제거
            ui.closeModal();
            loadSpecs();
        } catch (error) {
            // 비밀번호가 틀렸을 경우, 확인 모달을 띄움
            alert(`삭제 실패: ${error.message}. 비밀번호를 다시 확인해주세요.`);
            ui.openDeletePasswordModal();
            ui.elements.passwordConfirmInput.value = '';
            ui.elements.passwordErrorMsg.classList.add('hidden');
            setTimeout(() => ui.elements.passwordConfirmInput.focus(), 50);
        } finally {
            ui.elements.deleteBtn.disabled = false;
        }
    } else if (ui.hasPassword()) {
        // DB에 비밀번호는 있지만, 입력 필드가 비어있는 경우
        ui.openDeletePasswordModal();
        ui.elements.passwordConfirmInput.value = '';
        ui.elements.passwordErrorMsg.classList.add('hidden');
        setTimeout(() => ui.elements.passwordConfirmInput.focus(), 50);
    } else {
        // 비밀번호가 없는 명세서의 경우
        if (!confirm(`정말로 ID ${id} 명세서를 삭제하시겠습니까? (비밀번호 없음)`)) return;
        
        try {
            ui.elements.deleteBtn.disabled = true;
            await api.deleteSpec(id, null); 
            // alert('성공적으로 삭제되었습니다.'); // 팝업 제거
            ui.closeModal();
            loadSpecs();
        } catch (error) {
            console.error('Delete error:', error);
            alert(`삭제에 실패했습니다: ${error.message}`);
        } finally {
            ui.elements.deleteBtn.disabled = false;
        }
    }
}

/**
 * @description 삭제 비밀번호 확인 후 삭제 실행
 */
async function handleConfirmDelete() {
    const id = ui.elements.specIdInput.value;
    const password = ui.elements.passwordConfirmInput.value;

    if (!password) {
        ui.elements.passwordErrorMsg.textContent = '비밀번호를 입력해주세요.';
        ui.elements.passwordErrorMsg.classList.remove('hidden');
        return;
    }

    ui.elements.confirmDeleteBtn.disabled = true;
    ui.elements.passwordErrorMsg.classList.add('hidden');

    try {
        await api.deleteSpec(id, password);
        // alert('성공적으로 삭제되었습니다.'); // 팝업 제거
        ui.closeDeletePasswordModal();
        ui.closeModal();
        loadSpecs();
    } catch (error) {
        console.error('Delete error:', error);
        ui.elements.passwordErrorMsg.textContent = `삭제 실패: ${error.message}`;
        ui.elements.passwordErrorMsg.classList.remove('hidden');
    } finally {
        ui.elements.confirmDeleteBtn.disabled = false;
    }
}

/**
 * @description 페이지의 모든 이벤트 리스너를 초기화합니다.
 */
function initializeEventListeners() {
    ui.elements.addNewBtn.addEventListener('click', handleAddNew);
    ui.elements.closeModalBtn.addEventListener('click', ui.closeModal);
    ui.elements.closeModalXBtn.addEventListener('click', ui.closeModal);
    ui.elements.saveBtn.addEventListener('click', handleSaveWithCheck);
    ui.elements.deleteBtn.addEventListener('click', handleDelete);
    ui.elements.scrapeBtn.addEventListener('click', handleScrape);

    ui.elements.pasteContentInput.addEventListener('input', () => {
        const maxLength = ui.elements.pasteContentInput.maxLength;
        const currentLength = ui.elements.pasteContentInput.value.length;
        ui.elements.charCounter.textContent = `${currentLength} / ${maxLength}`;
    });


    // Delete password confirm modal events
    ui.elements.cancelDeleteBtn.addEventListener('click', ui.closeDeletePasswordModal);
    ui.elements.confirmDeleteBtn.addEventListener('click', handleConfirmDelete);
    ui.elements.passwordConfirmInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') handleConfirmDelete();
    });
}

/**
 * @description 데이터 명세 페이지를 초기화합니다.
 */
export function initializePage() {
    ui.initializeDOMElements();
    initializeEventListeners();
    loadSpecs();
    
    // 카드 접기/펴기 기능 초기화
    initCollapsibleFeatures();

    initUrlMapper((mappedData) => {
        console.log('Received mapped data:', mappedData);
        ui.populateForm(mappedData.spec, mappedData.params);
        ui.openModal();
    });
}
