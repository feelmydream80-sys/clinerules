import logging
from flask import g, session
from mapper.user_mapper import UserMapper
from service.dashboard_service import DashboardService
from msys.database import get_db_connection
from service.password_service import PasswordService
from msys.column_mapper import reload_mappings

class UserService:
    def __init__(self, db_connection):
        self.conn = db_connection
        self.user_mapper = UserMapper(db_connection)
        self.dashboard_service = DashboardService(db_connection)

    def get_all_users_with_permissions(self):
        """모든 사용자 목록과 각 사용자의 권한 정보를 반환합니다."""
        try:
            reload_mappings()
            users = self.user_mapper.find_all()
            logging.info(f"DEBUG [Service]: Received users from Mapper: {users}")
            menus = self.user_mapper.find_all_menus()
            
            # 메뉴 목록을 menu_order 기준으로 정렬합니다. menu_order 없는 경우 마지막에 위치시킵니다.
            menus = sorted(menus, key=lambda x: x.get('menu_order') if x.get('menu_order') is not None else float('inf'))

            logging.info(f"DEBUG [Service]: Received menus from Mapper: {menus}")
            all_permissions = self.user_mapper.find_all_permissions()
            logging.info(f"DEBUG [Service]: Received permissions from Mapper: {all_permissions}")

            permissions_map = {}
            for p in all_permissions:
                user_id = p['user_id']
                if user_id not in permissions_map:
                    permissions_map[user_id] = []
                permissions_map[user_id].append(p['menu_id'])

            for user in users:
                user_permissions = permissions_map.get(user['user_id'], [])
                user['permissions'] = user_permissions
                user['is_admin'] = 'admin' in user_permissions
            
            final_data = {"users": users, "menus": menus}
            logging.info(f"DEBUG [Service]: Final data to be returned: {final_data}")
            return final_data
        except Exception as e:
            logging.error(f"❌ Service: 사용자 목록 조회 실패: {e}", exc_info=True)
            raise

    def approve_user(self, user_id):
        """사용자를 승인하고 비밀번호를 ID와 동일하게 초기화합니다."""
        try:
            # 1. 상태를 'APPROVED'로 변경
            self.user_mapper.update_status(user_id, 'APPROVED')
            # 2. 비밀번호를 user_id로 해싱하여 업데이트
            hashed_password = PasswordService.hash_password(user_id)
            self.user_mapper.update_password(user_id, hashed_password)
            
            self._log_user_event(user_id, 'AUTH_APPROVE', f"User '{user_id}' approved by admin")
            
            logging.info(f"✅ Service: 사용자 '{user_id}'가 승인되고 비밀번호가 초기화되었습니다.")
        except Exception as e:
            logging.error(f"❌ Service: 사용자 승인 실패: {e}", exc_info=True)
            raise

    def reject_user(self, user_id):
        """사용자 가입 신청을 거절하고 데이터베이스에서 삭제합니다."""
        try:
            self.user_mapper.delete_by_id(user_id)
            self._log_user_event(user_id, 'AUTH_REJECT', f"User '{user_id}' rejected by admin")
            logging.info(f"✅ Service: 사용자 '{user_id}'의 가입 신청이 거절되어 삭제되었습니다.")
        except Exception as e:
            logging.error(f"❌ Service: 사용자 거절 실패: {e}", exc_info=True)
            raise

    def delete_user(self, user_id):
        """관리자가 승인된 사용자를 삭제합니다."""
        try:
            self.user_mapper.delete_by_id(user_id)
            self._log_user_event(user_id, 'AUTH_DELETE', f"User '{user_id}' deleted by admin")
            logging.info(f"✅ Service: 사용자 '{user_id}'가 삭제되었습니다.")
        except Exception as e:
            logging.error(f"❌ Service: 사용자 삭제 실패: {e}", exc_info=True)
            raise

    def reset_password(self, user_id):
        """사용자 비밀번호를 ID와 동일하게 초기화합니다."""
        try:
            hashed_password = PasswordService.hash_password(user_id)
            self.user_mapper.update_password(user_id, hashed_password)
            self._log_user_event(user_id, 'AUTH_RESET_PW', f"Password for user '{user_id}' reset by admin")
            logging.info(f"✅ Service: 사용자 '{user_id}'의 비밀번호가 초기화되었습니다.")
        except Exception as e:
            logging.error(f"❌ Service: 비밀번호 초기화 실패: {e}", exc_info=True)
            raise

    def update_permissions(self, user_id, menu_ids):
        """사용자의 메뉴 접근 권한을 업데이트합니다."""
        try:
            self.user_mapper.update_user_permissions(user_id, menu_ids)
            
            # 이벤트 로그 기록
            log_message = f"Permissions for user '{user_id}' updated by admin. New permissions: {menu_ids}"
            self._log_user_event(user_id, 'AUTH_UPDATE_PERM', log_message)
            
            logging.info(f"✅ Service: 사용자 '{user_id}'의 권한이 업데이트되었습니다.")
        except Exception as e:
            # 데이터베이스 오류 메시지를 확인하여 원인을 더 구체적으로 파악합니다.
            error_msg = str(e).lower()
            # 외래 키 제약 조건 위반을 나타내는 일반적인 문자열을 확인합니다.
            if 'foreign key constraint' in error_msg or 'violates foreign key' in error_msg or 'foreign key violation' in error_msg:
                logging.error(f"❌ Service: 사용자 권한 업데이트 실패 (잘못된 menu_id): {e}", exc_info=True)
                # 클라이언트에게 원인을 명확히 알려주기 위해 ValueError를 발생시킵니다.
                raise ValueError("존재하지 않는 메뉴 ID가 포함되어 있어 권한을 업데이트할 수 없습니다.")
            
            logging.error(f"❌ Service: 사용자 권한 업데이트 실패: {e}", exc_info=True)
            # 그 외 다른 예외는 그대로 다시 발생시킵니다.
            raise

    def _log_user_event(self, user_id, status, message):
        """사용자 관련 이벤트를 로그에 기록합니다."""
        try:
            # g.user 대신 session에서 직접 사용자 정보를 가져옵니다.
            admin_user_id = session.get('user', {}).get('user_id', 'UNKNOWN_ADMIN')
            rqs_info = f"{message} by '{admin_user_id}'"
            self.dashboard_service.save_event(con_id=None, job_id=user_id, status=status, rqs_info=rqs_info)
            logging.info(f"Event '{status}' saved for user: {user_id}")
        except Exception as log_e:
            logging.error(f"Failed to save event log for user {user_id}: {log_e}", exc_info=True)
            # 로깅 실패가 전체 트랜잭션을 롤백시키지 않도록 수정합니다.
            # raise 대신 경고 로그만 남깁니다.
            logging.warning(f"Could not log event for user {user_id} due to: {log_e}")
