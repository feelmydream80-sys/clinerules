// static/js/modules/dashboardTable.js
/*
 * 주요 역할: 대시보드 메인 테이블의 렌더링을 담당합니다.
 * 복잡한 UI 로직과 상태 계산을 처리합니다.
 */

import { parseCronExpression, formatNumberWithCommas, formatNumberToKorean } from '../common/utils.js';

// @AI_NOTE: 상태 레벨 상수 정의 (가독성 향상)
const STATUS_CHECK_NEEDED = 0; // 확인필요
const STATUS_NO_DATA = 1;      // 미수집
const STATUS_NORMAL = 2;       // 정상
const STATUS_WARNING = 4;      // 경고
const STATUS_FAILURE = 5;      // 장애

/**
 * @AI_NOTE: 기간별 성공률 셀을 렌더링하는 헬퍼 함수
 * @param {object} item - 해당 Job의 데이터 아이템
 * @param {string} periodPrefix - 기간 접두사 ('day', 'week', 'month', 'half', 'year')
 * @param {number} threshold - 성공률 경고 임계값
 * @param {object} icons - 아이콘 코드 맵
 * @param {object} colors - 색상 클래스 맵
 * @returns {string} - 렌더링될 HTML 문자열
 */
function createPeriodRateDisplay(
    item,
    periodPrefix,
    threshold,
    icons,
    colors
) {
    const successCount = item[`${periodPrefix}_success`] || 0;
    const failCount = item[`${periodPrefix}_fail_count`] || 0;
    const noDataCount = item[`${periodPrefix}_no_data_count`] || 0;
    const ingCount = item[`${periodPrefix}_ing_count`] || 0;
    const miscCount = item[`${periodPrefix}_misc_count`] || 0; // 기타(misc) 카운트 추가

    // CD904(계측중)는 분모에서 제외
    const calculatedPeriodTotal = successCount + failCount + noDataCount;
    const displayRate = (calculatedPeriodTotal > 0) ? ((successCount / calculatedPeriodTotal) * 100).toFixed(2) : '0.00';
    
    let periodStatusLevel = STATUS_NORMAL;
    if (calculatedPeriodTotal === 0) {
        periodStatusLevel = STATUS_NO_DATA;
    } else if (parseFloat(displayRate) === 0.00) {
        periodStatusLevel = STATUS_FAILURE;
    } else if (parseFloat(displayRate) < parseFloat(threshold)) {
        periodStatusLevel = STATUS_WARNING;
    }

    let periodStatusIcon = icons.checkNeeded;
    let periodStatusColorClass = colors.checkNeeded;

    switch (periodStatusLevel) {
        case STATUS_NO_DATA: periodStatusIcon = icons.noData; periodStatusColorClass = colors.noData; break;
        case STATUS_NORMAL: periodStatusIcon = icons.srSuccess; periodStatusColorClass = colors.srSuccess; break;
        case STATUS_WARNING: periodStatusIcon = icons.srWarning; periodStatusColorClass = colors.srWarning; break;
        case STATUS_FAILURE: periodStatusIcon = icons.srWarning; periodStatusColorClass = colors.srWarning; break; // 0%일 경우 경고 아이콘 재사용
    }

    return `
        <div class="flex flex-col items-end">
            <div class="flex items-center justify-end gap-1">
                <span class="${periodStatusColorClass}">${periodStatusIcon}</span>
                <span class="font-semibold" style="color: ${periodStatusColorClass};">${displayRate}%</span>
            </div>
            <div class="text-xs text-gray-500 mt-1">
                (${formatNumberWithCommas(successCount)}, ${formatNumberWithCommas(ingCount)}, ${formatNumberWithCommas(failCount)}/${formatNumberWithCommas(noDataCount)}/${formatNumberWithCommas(miscCount)})
            </div>
        </div>
    `;
}


/**
 * @AI_NOTE: 대시보드 요약 데이터를 테이블로 렌더링합니다.
 * @param {Array<Object>} summaryData - 렌더링할 데이터 배열 (페이징 처리된)
 * @param {Object} allJobSettings - 모든 Job의 관리자 설정
 * @param {Object} iconMap - 아이콘 ID와 이모지 코드 매핑
 */
export function renderDashboardSummaryTable(summaryData, allJobSettings, iconMap) {
    const tableBody = document.getElementById('dashboardTableBody');
    if (!tableBody) {
        console.error("Error: dashboardTableBody element not found.");
        return;
    }
    tableBody.innerHTML = '';

    if (!summaryData || summaryData.length === 0) {
        // 데이터가 없을 경우의 메시지는 pagination 모듈에서 처리하므로 여기서는 비워두기만 함
        return;
    }

    summaryData.forEach(item => {
        const row = document.createElement('tr');
        row.className = 'border-b border-gray-200 hover:bg-gray-50';

        const jobSetting = allJobSettings[item.job_id] || {};

        // 아이콘 코드와 색상 클래스를 미리 객체로 정리
        const icons = {
            success: iconMap[jobSetting?.sr_success_icon] || '🟢',
            cfWarning: iconMap[jobSetting?.cf_warning_icon] || '🟠',
            cfFail: iconMap[jobSetting?.cf_fail_icon] || '🔴',
            srSuccess: iconMap[jobSetting?.sr_success_icon] || '🟢',
            srWarning: iconMap[jobSetting?.sr_warning_icon] || '🟠',
            noData: '⚪',
            checkNeeded: '⚫',
        };
        const colors = {
            success: jobSetting?.sr_success_wd_color || 'text-green-600',
            warning: jobSetting?.cf_warning_wd_color || 'text-yellow-600',
            fail: jobSetting?.cf_fail_wd_color || 'text-red-600',
            srSuccess: jobSetting?.sr_success_wd_color || 'text-green-600',
            srWarning: jobSetting?.sr_warning_wd_color || 'text-yellow-600',
            noData: 'text-gray-500',
            checkNeeded: 'text-gray-500',
        };

        const currentTotalCount = (item.overall_success_count || 0) + (item.overall_fail_count || 0) + (item.overall_no_data_count || 0) + (item.overall_cd904_count || 0) + (item.overall_ing_count || 0);
        const currentFailStreak = item.fail_streak || 0;
        const overallNoDataCount = item.overall_no_data_count || 0;

        const cf_warning_cnt = parseFloat(jobSetting?.cf_warning_cnt);
        const final_cf_warning_cnt = isNaN(cf_warning_cnt) ? 1 : cf_warning_cnt;
        const cf_fail_cnt = parseFloat(jobSetting?.cf_fail_cnt);
        const final_cf_fail_cnt = isNaN(cf_fail_cnt) ? 3 : cf_fail_cnt;

        // Job의 전체 상태 결정 로직
        let overallJobStatusLevel = STATUS_NORMAL;
        if (currentTotalCount === 0 && overallNoDataCount > 0) {
            overallJobStatusLevel = STATUS_NO_DATA;
        } else if (currentFailStreak === 0) {
            overallJobStatusLevel = STATUS_NORMAL;
        } else {
            if (currentFailStreak >= final_cf_fail_cnt) {
                overallJobStatusLevel = STATUS_FAILURE;
            } else if (currentFailStreak >= final_cf_warning_cnt) {
                overallJobStatusLevel = STATUS_WARNING;
            }
        }

        let jobIcon = icons.checkNeeded;
        let jobColorClass = colors.checkNeeded;
        switch (overallJobStatusLevel) {
            case STATUS_NO_DATA: jobIcon = icons.noData; jobColorClass = colors.noData; break;
            case STATUS_NORMAL: jobIcon = icons.success; jobColorClass = colors.success; break;
            case STATUS_WARNING: jobIcon = icons.cfWarning; jobColorClass = colors.warning; break;
            case STATUS_FAILURE: jobIcon = icons.cfFail; jobColorClass = colors.fail; break;
        }

        const jobIdContent = window.isAdmin
            ? `<a href="http://CIB200L2:18080/dags/${item.job_id}/grid" target="_blank" class="font-semibold hover:underline" style="color: ${jobColorClass};">${item.job_id}</a>`
            : `<span class="font-semibold" style="color: ${jobColorClass};">${item.job_id}</span>`;

        const jobIdDisplay = `
            <div class="flex flex-col items-start">
                <div class="flex items-center justify-start gap-1">
                    <span class="${jobColorClass}">${jobIcon}</span>
                    ${jobIdContent}
                </div>
                <div class="text-xs text-gray-500 mt-1">
                    (${currentFailStreak}회 실패)
                </div>
            </div>
        `;

        // 기간별 성공률 임계값
        const thresholds = {
            day: parseFloat(item.sr_day_th || jobSetting?.sr_day_th) || 80,
            week: parseFloat(item.sr_week_th || jobSetting?.sr_week_th) || 80,
            month: parseFloat(item.sr_month_th || jobSetting?.sr_month_th) || 80,
            half: parseFloat(item.sr_half_th || jobSetting?.sr_half_th) || 80,
            year: parseFloat(item.sr_year_th || jobSetting?.sr_year_th) || 80,
        };

        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 align-top">${jobIdDisplay}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 align-top">${item.cd_nm || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 align-top">
                <div>${item.frequency || 'N/A'}</div>
                <div class="text-xs text-gray-500 mt-1">${parseCronExpression(item.frequency)}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right align-top">${formatNumberToKorean(currentTotalCount)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right align-top">
                ${createPeriodRateDisplay(item, 'day', thresholds.day, icons, colors)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right align-top">
                ${createPeriodRateDisplay(item, 'week', thresholds.week, icons, colors)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right align-top">
                ${createPeriodRateDisplay(item, 'month', thresholds.month, icons, colors)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right align-top">
                ${createPeriodRateDisplay(item, 'half', thresholds.half, icons, colors)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 text-right align-top">
                ${createPeriodRateDisplay(item, 'year', thresholds.year, icons, colors)}
            </td>
        `;
        tableBody.appendChild(row);
    });
}
