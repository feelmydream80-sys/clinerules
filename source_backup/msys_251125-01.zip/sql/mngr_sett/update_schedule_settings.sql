-- sql/mngr_sett/update_schedule_settings.sql
UPDATE
    tb_data_clt_schd_sett
SET
    grp_min_cnt = %(grp_min_cnt)s,
    prgs_rt_red_thrsval = %(prgs_rt_red_thrsval)s,
    prgs_rt_org_thrsval = %(prgs_rt_org_thrsval)s,
    use_yn = %(use_yn)s,
    updr_id = %(updr_id)s,
    updr_dt = CURRENT_TIMESTAMP
WHERE
    sett_id = %(sett_id)s;