export function init() {
    const weeklyBtn = document.getElementById('weekly-btn');
    const monthlyBtn = document.getElementById('monthly-btn');
    const calendarGrid = document.getElementById('calendar-grid');
    const summaryStats = document.getElementById('summary-stats');
    const heatmapTitle = document.getElementById('heatmap-title');
    const descriptionBox = document.getElementById('heatmap-description');

    let currentView = 'weekly'; // 'weekly' or 'monthly'

    const renderHeatmap = async () => {
        try {
            // 설정과 히트맵 데이터를 병렬로 가져옵니다.
            const [heatmapRes, settingsRes] = await Promise.all([
                fetch(`/api/analytics/collection_heatmap?period=${currentView}`),
                fetch(`/api/mngr_sett/schedule_settings?_=${new Date().getTime()}`)
            ]);

            if (!heatmapRes.ok) {
                throw new Error(`히트맵 데이터 로딩 실패: ${heatmapRes.status}`);
            }
            const heatmapData = await heatmapRes.json();
            
            // 설정을 처리하고, 실패해도 기본값으로 동작하도록 합니다.
            let settings = { use_yn: 'N' };
            if (settingsRes.ok) {
                const rawSettings = await settingsRes.json();
                 if (Array.isArray(rawSettings) && rawSettings.length > 0) {
                    settings = rawSettings[0];
                } else if (rawSettings && typeof rawSettings === 'object' && !Array.isArray(rawSettings)) {
                    settings = rawSettings;
                }
            } else {
                console.warn('수집 스케줄 설정을 불러오지 못했습니다. 기본값으로 표시됩니다.');
            }
            
            console.log('Loaded schedule settings on heatmap page:', settings);

            // 설정 사용 여부(use_yn)에 따라 설명 박스를 숨깁니다.
            if (descriptionBox && settings.use_yn === 'Y') {
                descriptionBox.style.display = 'none';
            }
            
            updateSummary(heatmapData.summary);
            updateCalendar(heatmapData.heatmap);
            updateTitle();

        } catch (error) {
            console.error("히트맵 데이터를 불러오는 중 오류 발생:", error);
            calendarGrid.innerHTML = `<p class="text-red-500">${error.message}</p>`;
        }
    };

    const updateTitle = () => {
        heatmapTitle.textContent = `${currentView === 'weekly' ? '주간' : '월간'} 수집 현황 히트맵`;
    };

    const updateSummary = (summary) => {
        summaryStats.innerHTML = `
            <div>전체 예정: <span class="count">${summary.total}</span></div>
            <div>성공: <span class="count" style="color: #166534;">${summary.success}</span></div>
            <div>실패: <span class="count" style="color: #991b1b;">${summary.fail}</span></div>
            <div>미수집: <span class="count" style="color: #9a3412;">${summary.nodata}</span></div>
        `;
    };

    const updateCalendar = (heatmapData) => {
        calendarGrid.innerHTML = ''; // Clear previous content
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        heatmapData.forEach(dayData => {
            const dayDate = new Date(dayData.date);
            dayDate.setHours(0, 0, 0, 0);

            const isToday = dayDate.getTime() === today.getTime();
            const dayColumn = document.createElement('div');
            dayColumn.className = `day-column ${isToday ? 'today' : ''}`;

            const dayHeader = document.createElement('div');
            dayHeader.className = 'day-header';
            dayHeader.textContent = `${dayData.date_str} (${dayData.day_of_week})`;
            
            const jobsContainer = document.createElement('div');
            jobsContainer.className = 'jobs-container';

            dayData.jobs.forEach(job => {
                const jobPill = document.createElement('div');
                jobPill.className = `job-pill status-${job.status.toLowerCase()}`;
                
                let icon = '';
                switch(job.status) {
                    case 'SUCCESS': icon = '✅'; break;
                    case 'FAIL': icon = '❌'; break;
                    case 'INPROGRESS': icon = '🔵'; break;
                    case 'NODATA': icon = '⚠️'; break;
                }
                jobPill.textContent = `${icon} ${job.job_id}`;
                jobsContainer.appendChild(jobPill);
            });

            dayColumn.appendChild(dayHeader);
            dayColumn.appendChild(jobsContainer);
            calendarGrid.appendChild(dayColumn);
        });
    };

    weeklyBtn.addEventListener('click', () => {
        if (currentView !== 'weekly') {
            currentView = 'weekly';
            weeklyBtn.classList.add('active');
            monthlyBtn.classList.remove('active');
            renderHeatmap();
        }
    });

    monthlyBtn.addEventListener('click', () => {
        if (currentView !== 'monthly') {
            currentView = 'monthly';
            monthlyBtn.classList.add('active');
            weeklyBtn.classList.remove('active');
            renderHeatmap();
        }
    });

    // Initial render
    renderHeatmap();
}
