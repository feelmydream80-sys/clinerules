# 기술 부채 로그

## 1. 이벤트 로그 미출력 현상

### 원인

Flask 애플리케이션을 Gunicorn과 같은 프로덕션 WSGI 서버를 통해 실행할 때, `print()` 함수를 사용한 로그는 표준 출력(stdout)으로 직접 전달되지 않을 수 있습니다. 특히, 데몬화(daemonized)된 프로세스에서는 출력이 버려지거나 다른 곳으로 리디렉션될 수 있습니다. 이로 인해 `print()`를 사용하여 남긴 디버그 메시지가 터미널에 표시되지 않는 문제가 반복적으로 발생했습니다.

### 해결 방법

Flask의 내장 로거인 `current_app.logger`를 사용하는 것으로 표준화합니다. 이는 Flask 애플리케이션의 로깅 설정을 따르므로, 개발 환경(로컬 실행)과 프로덕션 환경(Gunicorn 등) 모두에서 일관되게 로그를 출력할 수 있습니다.

- **`print()` 대신 `current_app.logger.debug()`, `current_app.logger.info()` 등을 사용합니다.**
- 디버그 레벨의 로그를 확인하기 위해서는 Flask 앱의 로그 레벨을 `DEBUG`로 설정해야 합니다. (`app.logger.setLevel(logging.DEBUG)`)

---
