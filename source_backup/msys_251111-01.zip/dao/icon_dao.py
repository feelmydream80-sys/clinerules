# dao/icon_dao.py
"""
DAO for handling icon data in the database.
"""
import logging
from typing import List, Dict, Optional
import psycopg2
from psycopg2.extras import RealDictCursor
from dao.sql_loader import load_sql

class IconDAO:
    """
    Data Access Object for icons.
    Handles all database operations for the TB_ICON table.
    """
    def __init__(self, db_connection):
        self.conn = db_connection
        self.logger = logging.getLogger(self.__class__.__name__)

    def get_all_icons(self) -> List[Dict]:
        """
        Retrieves all icons from the database.
        """
        query = load_sql('icon/get_all_icons.sql')
        try:
            with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(query)
                results = cur.fetchall()
                return [dict(row) for row in results]
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error fetching all icons: {e}", exc_info=True)
            raise

    def insert_icon(self, icon_data: Dict):
        """
        Inserts a new icon into the database.
        """
        query = load_sql('icon/insert_icon.sql')
        values = (
            icon_data.get('ICON_CD'),
            icon_data.get('ICON_NM'),
            icon_data.get('ICON_EXPL'),
            icon_data.get('ICON_DSP_YN', 'Y') # Default to 'Y' if not provided
        )
        try:
            with self.conn.cursor() as cur:
                cur.execute(query, values)
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error inserting icon {icon_data.get('ICON_CD')}: {e}", exc_info=True)
            raise

    def update_icon(self, icon_data: Dict):
        """
        Updates an existing icon in the database.
        """
        query = load_sql('icon/update_icon.sql')
        values = (
            icon_data.get('ICON_CD'),
            icon_data.get('ICON_NM'),
            icon_data.get('ICON_EXPL'),
            icon_data.get('ICON_DSP_YN'),
            icon_data.get('ICON_ID')
        )
        try:
            with self.conn.cursor() as cur:
                cur.execute(query, values)
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error updating icon ID {icon_data.get('ICON_ID')}: {e}", exc_info=True)
            raise

    def delete_icon(self, icon_id: int):
        """
        Deletes an icon from the database by its ID.
        """
        query = load_sql('icon/delete_icon.sql')
        try:
            with self.conn.cursor() as cur:
                cur.execute(query, (icon_id,))
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error deleting icon ID {icon_id}: {e}", exc_info=True)
            raise

    def update_icon_display_status(self, icon_id: int, display_yn: str):
        """
        Updates the display status of an icon.
        """
        query = load_sql('icon/update_icon_display_status.sql')
        try:
            with self.conn.cursor() as cur:
                cur.execute(query, (display_yn, icon_id))
        except psycopg2.Error as e:
            self.logger.error(f"❌ DAO: Error updating display status for icon ID {icon_id}: {e}", exc_info=True)
            raise
