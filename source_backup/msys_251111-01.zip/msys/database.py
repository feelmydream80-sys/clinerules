import psycopg2
from psycopg2.extras import RealDictCursor
import os
from my_setting.db_config import DB_CONFIG
import logging
from flask import g

def get_db_connection():
    """
    요청 컨텍스트(g)를 사용하여 데이터베이스 연결을 관리합니다.
    g에 연결이 없으면 새로 생성하고, 있으면 기존 연결을 반환합니다.
    """
    if 'db_conn' not in g:
        try:
            db_config_with_encoding = DB_CONFIG.copy()
            db_config_with_encoding['client_encoding'] = 'UTF8'
            g.db_conn = psycopg2.connect(**db_config_with_encoding)
        except Exception as e:
            logging.error(f"❌ DB 연결 실패: {e}", exc_info=True)
            raise
    return g.db_conn

def close_db_connection(e=None):
    """
    요청이 종료될 때 데이터베이스 연결을 닫습니다.
    """
    db_conn = g.pop('db_conn', None)
    if db_conn is not None:
        db_conn.close()
        logging.info("DB 연결이 성공적으로 닫혔습니다.")

def get_db_cursor(conn):
    """
    주어진 DB 연결(conn)에 대해 RealDictCursor를 사용하여 딕셔너리 형태의 결과를 반환하는 커서를 생성합니다.
    """
    return conn.cursor(cursor_factory=RealDictCursor)
