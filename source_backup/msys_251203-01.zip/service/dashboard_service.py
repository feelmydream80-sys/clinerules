# service/dashboard_service.py
"""
Dashboard and Analytics Business Logic
Handles fetching and processing data for the dashboard and analytics pages.
"""
import logging
from typing import Optional, List, Dict
from mapper.dashboard_mapper import DashboardMapper
from mapper.user_mapper import UserMapper
from msys.database import get_db_connection

class DashboardService:
    """
    Provides methods to retrieve data for the dashboard and analytics charts.
    """

    def __init__(self, db_connection):
        self.conn = db_connection
        self.dashboard_mapper = DashboardMapper(db_connection)
        self.user_mapper = UserMapper(db_connection)

    def get_summary(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False, user: Optional[Dict] = None) -> List[Dict]:
        user_id_log = user.get('user_id') if user else 'None'
        logging.info(f"DashboardService.get_summary called for user: {user_id_log}")
        # 데이터 접근 권한 확인
        # user 객체가 없을 경우 (시스템 내부 호출 등) 권한 검사를 건너뛰고 모든 데이터를 조회합니다.
        if not user:
            logging.info("User object not provided, skipping permission checks for internal call.")
            allowed_job_ids = None
        else:
            is_admin = 'mngr_sett' in user.get('permissions', [])
            user_id = user.get('user_id', 'Unknown')
            logging.info(f"Checking data permissions for user: {user_id}, is_admin: {is_admin}")
            
            allowed_job_ids = None
            if not is_admin:
                if user_id:
                    allowed_job_ids = self.user_mapper.find_data_permissions_by_user_id(user_id)
                    logging.info(f"Non-admin user. Applying data permissions. Allowed jobs: {allowed_job_ids}")
                
                # 권한이 없는 비-관리자 사용자는 빈 목록을 반환합니다.
                if not allowed_job_ids:
                    logging.warning(f"User {user_id} has no data permissions. Returning empty summary.")
                    return []
            else:
                logging.info(f"Admin user {user_id}. No data permission filtering applied.")

        summary_data = self.dashboard_mapper.get_summary(start_date, end_date, all_data, allowed_job_ids)
        return summary_data

    def get_min_max_dates(self) -> Optional[Dict]:
        return self.dashboard_mapper.get_min_max_dates()

    def get_analytics_success_rate_trend(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        trend_data = self.dashboard_mapper.get_analytics_success_rate_trend(start_date, end_date, allowed_job_ids)
        return trend_data

    def get_trouble_by_code(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        trouble_data = self.dashboard_mapper.get_analytics_trouble_by_code(start_date, end_date, allowed_job_ids)
        return trouble_data

    def get_raw_data(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None, all_data: bool = False, use_kst_today: bool = False, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        raw_data = self.dashboard_mapper.get_raw_data(start_date, end_date, allowed_job_ids, all_data, use_kst_today)
        return raw_data

    def get_event_log(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False) -> List[Dict]:
        event_log_data = self.dashboard_mapper.get_event_log(start_date, end_date, all_data)
        return event_log_data

    def get_distinct_job_ids(self, user: Optional[Dict] = None) -> List[str]:
        allowed_job_ids = self._get_allowed_job_ids(user)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        job_ids = self.dashboard_mapper.get_distinct_job_ids(job_ids=allowed_job_ids)
        return job_ids

    def save_event(self, con_id: Optional[str], job_id: Optional[str], status: str, rqs_info: str):
        self.dashboard_mapper.save_event(con_id, job_id, status, rqs_info)

    def get_daily_job_counts(self, job_id: Optional[str], start_date: Optional[str], end_date: Optional[str], all_data: bool, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = None
        if user:
            is_admin = 'mngr_sett' in user.get('permissions', [])
            user_id = user.get('user_id', 'Unknown')
            logging.info(f"Checking data permissions for user: {user_id}, is_admin: {is_admin} in get_daily_job_counts")
            if not is_admin:
                allowed_job_ids = user.get('data_permissions', [])
                logging.info(f"Non-admin user in get_daily_job_counts. Applying data permissions. Allowed jobs: {allowed_job_ids}")
                if not allowed_job_ids:
                    logging.warning(f"User {user_id} has no data permissions. Returning empty daily job counts.")
                    return []
            else:
                logging.info(f"Admin user {user_id} in get_daily_job_counts. No data permission filtering applied.")
        
        data = self.dashboard_mapper.get_daily_job_counts(job_id, start_date, end_date, all_data, job_ids=allowed_job_ids)
        return data

    def get_distinct_error_codes(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False, user: Optional[Dict] = None) -> List[str]:
        allowed_job_ids = self._get_allowed_job_ids(user)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        error_codes = self.dashboard_mapper.get_distinct_error_codes(start_date, end_date, all_data, job_ids=allowed_job_ids)
        return error_codes

    def get_collection_history_for_schedule(self, start_date: str, end_date: str, job_ids: Optional[List[str]] = None, user: Optional[Dict] = None) -> List[Dict]:
        allowed_job_ids = self._get_allowed_job_ids(user, job_ids)
        if allowed_job_ids is not None and not allowed_job_ids:
            return []
        return self.dashboard_mapper.get_collection_history_for_schedule(start_date, end_date, allowed_job_ids)
        
    def _get_allowed_job_ids(self, user: Optional[Dict], requested_job_ids: Optional[List[str]] = None) -> Optional[List[str]]:
        if not user or 'mngr_sett' in user.get('permissions', []):
            return requested_job_ids

        user_permissions = set(user.get('data_permissions', []))
        if not user_permissions:
            return []

        if requested_job_ids:
            allowed = list(user_permissions.intersection(set(requested_job_ids)))
            logging.info(f"User requested {requested_job_ids}, allowed: {allowed}")
            return allowed
        
        return list(user_permissions)
