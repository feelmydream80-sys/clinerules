from dao.icon_dao import IconDAO

class IconMapper:
    
    def __init__(self, db_connection):
        self.icon_dao = IconDAO(db_connection)

    def get_all_icons(self):
        return self.icon_dao.get_all_icons()

    def insert_or_update_icon(self, icon_data):
        # This method seems to be a business logic, might be better in service layer
        # For now, assuming it decides whether to insert or update
        if 'ICON_ID' in icon_data and icon_data['ICON_ID']:
            return self.icon_dao.update_icon(icon_data)
        else:
            return self.icon_dao.insert_icon(icon_data)

    def delete_icon(self, icon_id):
        return self.icon_dao.delete_icon(icon_id)

    def toggle_icon_display(self, icon_id, display_yn):
        return self.icon_dao.update_icon_display_status(icon_id, display_yn)
