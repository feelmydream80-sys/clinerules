document.addEventListener('DOMContentLoaded', function () {
    const weeklyBtn = document.getElementById('weekly-btn');
    const monthlyBtn = document.getElementById('monthly-btn');
    const calendarGrid = document.getElementById('calendar-grid');
    const cardTitle = document.querySelector('.card-title');

    let currentView = 'weekly'; // 'weekly' or 'monthly'

    async function fetchData(view) {
        try {
            const response = await fetch(`/api/analytics/collection_schedule?view=${view}`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            return data;
        } catch (error) {
            console.error("Error fetching collection schedule data:", error);
            // Return a default structure in case of error
            return { summary: { total: 0, success: 0, fail: 0, scheduled: 0 }, jobs: [] };
        }
    }

    function renderCalendar(data, view) {
        calendarGrid.innerHTML = '';

        const safeData = data || {};
        const summary = safeData.summary || { total: 0, success: 0, fail: 0, scheduled: 0 };
        const jobs = safeData.jobs || [];

        updateSummary(summary);

        const today = new Date();
        let startDate;
        let days;

        if (view === 'weekly') {
            days = 7;
            startDate = new Date(today);
            startDate.setDate(today.getDate() - today.getDay()); // Start from Sunday
        } else { // monthly
            days = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
            startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        }
        
        for (let i = 0; i < days; i++) {
            const dayCol = document.createElement('div');
            dayCol.className = 'day-column';

            const date = new Date(startDate);
            date.setDate(startDate.getDate() + i);
            
            if (date.toDateString() === today.toDateString()) {
                dayCol.classList.add('today');
            }

            const dayHeader = document.createElement('div');
            dayHeader.className = 'day-header';
            dayHeader.textContent = `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')} (${getKoreanDay(date)})`;
            
            const jobsContainer = document.createElement('div');
            jobsContainer.className = 'jobs-container';

            const jobsForDay = jobs.filter(job => {
                // Normalize dates to prevent timezone issues
                const jobDate = new Date(job.date + 'T00:00:00');
                return jobDate.toDateString() === date.toDateString();
            });

            jobsForDay.forEach(job => {
                const jobPill = document.createElement('div');
                jobPill.className = `job-pill status-${job.status}`;
                jobPill.textContent = getStatusIcon(job.status) + ` ${job.job_id}`;
                jobsContainer.appendChild(jobPill);
            });

            dayCol.appendChild(dayHeader);
            dayCol.appendChild(jobsContainer);
            calendarGrid.appendChild(dayCol);
        }
    }

    function updateSummary(summary) {
        document.getElementById('total-jobs').textContent = summary.total || 0;
        document.getElementById('success-jobs').textContent = summary.success || 0;
        document.getElementById('fail-jobs').textContent = summary.fail || 0;
        document.getElementById('nodata-jobs').textContent = summary.scheduled || 0;
    }

    function getKoreanDay(date) {
        const days = ['일', '월', '화', '수', '목', '금', '토'];
        return days[date.getDay()];
    }

    function getStatusIcon(status) {
        switch (status) {
            case 'CD901': return '✅'; // success
            case 'CD902': return '❌'; // fail
            case 'CD903': return '⚠️'; // nodata
            case 'scheduled': return '🔵'; // scheduled
            default: return '❔';
        }
    }

    async function updateView(view) {
        currentView = view;
        if (view === 'weekly') {
            weeklyBtn.classList.add('active');
            monthlyBtn.classList.remove('active');
            cardTitle.textContent = '주간 데이터 수집 일정표';
        } else {
            monthlyBtn.classList.add('active');
            weeklyBtn.classList.remove('active');
            cardTitle.textContent = '월간 데이터 수집 일정표';
        }
        const data = await fetchData(view);
        renderCalendar(data, view);
    }

    weeklyBtn.addEventListener('click', () => updateView('weekly'));
    monthlyBtn.addEventListener('click', () => updateView('monthly'));

    // Initial load
    updateView('weekly');
});
