INSERT INTO tb_data_clt_schd_sett (
    grp_min_cnt,
    prgs_rt_red_thrsval,
    prgs_rt_org_thrsval,
    use_yn,
    regr_id,
    updr_id
) VALUES (
    %(grp_min_cnt)s,
    %(prgs_rt_red_thrsval)s,
    %(prgs_rt_org_thrsval)s,
    %(use_yn)s,
    %(regr_id)s,
    %(updr_id)s
) RETURNING sett_id;