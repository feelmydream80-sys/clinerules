import logging
from typing import Optional
from mapper.mst_mapper import MstMapper

class ConMstService:
    def __init__(self, db_connection):
        self.conn = db_connection
        self.mst_mapper = MstMapper(db_connection)

    def fetch_mst_list(self):
        return self.mst_mapper.get_all_mst()

    def get_cd_nm_item2(self, cd: str) -> tuple[Optional[str], Optional[str]]:
        """
        tb_con_mst에서 cd_nm과 item2를 조회하여 반환합니다.
        """
        try:
            data = self.mst_mapper.get_mst_data_by_cd(cd)
            if data:
                return data.get('cd_nm'), data.get('item2')
            return None, None
        except Exception as e:
            logging.error(f"❌ ConMstService: cd_nm, item2 조회 실패 (cd: {cd}): {e}", exc_info=True)
            return None, None

    def get_job_mst_info(self, job_ids):
        """
        job_id 리스트에 해당하는 마스터 상세정보를 dict로 반환
        {job_id: {cd_nm, cd_desc, item1, ...}}
        """
        return self.mst_mapper.get_job_mst_info(job_ids)

    def get_paged_jobs(self, start, length, search_value, start_date=None, end_date=None, all_data=True):
        return self.mst_mapper.get_paged_jobs(start, length, search_value, start_date, end_date, all_data)
            
    def get_error_code_map(self):
        return self.mst_mapper.get_error_code_map()
