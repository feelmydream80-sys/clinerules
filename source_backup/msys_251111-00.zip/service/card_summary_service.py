# service/card_summary_service.py
from collections import defaultdict
from mapper.card_summary_mapper import CardSummaryMapper

class CardSummaryService:
    def __init__(self, db_connection):
        self.card_summary_mapper = CardSummaryMapper(db_connection)

    def get_card_summary(self):
        """
        Gets the latest job status for today and formats it for the card summary view.
        """
        job_statuses = self.card_summary_mapper.get_latest_job_status_today()
        
        summary_data = defaultdict(lambda: {
            "success": {"count": 0, "jobs": []},
            "progress": {"count": 0, "jobs": []},
            "fail": {"count": 0, "jobs": []}
        })

        for job in job_statuses:
            job_id = job['job_id']
            status = job['status']
            
            if job_id.startswith('CD'):
                group = f"CD{job_id[2]}00" # e.g., CD101 -> CD100
                
                if status == 'success':
                    summary_data[group]['success']['count'] += 1
                    summary_data[group]['success']['jobs'].append(job_id)
                elif status == 'processing':
                    summary_data[group]['progress']['count'] += 1
                    summary_data[group]['progress']['jobs'].append(job_id)
                else: # fail, error, etc.
                    summary_data[group]['fail']['count'] += 1
                    summary_data[group]['fail']['jobs'].append(job_id)

        return summary_data
