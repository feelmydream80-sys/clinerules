/**
 * @module api
 * @description 서버 API 호출을 담당하는 모듈
 */

/**
 * tb_con_hist 테이블에 존재하는 모든 Job ID 목록을 가져옵니다.
 * @returns {Promise<Array<Object>>} Job ID 목록 Promise 객체
 * 
 * @example
 * // 사용 예시
 * import { fetchJobIds } from './api.js';
 * 
 * async function initialize() {
 *   const jobIds = await fetchJobIds();
 *   jobIds; // [{job_id: 'JOB001'}, {job_id: 'JOB002'}]
 * }
 */
export async function fetchJobIds() {
    const response = await fetch('/api/analysis/job_ids');
    if (!response.ok) {
        console.error('Failed to fetch job IDs');
        return [];
    }
    return await response.json();
}

/**
 * 모든 상세 데이터를 가져옵니다.
 * @returns {Promise<Array<Object>>} 상세 데이터 목록 Promise 객체
 * 
 * @example
 * // 사용 예시
 * import { fetchAllData } from './api.js';
 * 
 * async function initialize() {
 *   const allData = await fetchAllData();
 *   allData; // [{...}, {...}]
 * }
 */
export async function fetchAllData(startDate, endDate) {
    const params = new URLSearchParams();
    if (startDate) params.append('start_date', startDate);
    if (endDate) params.append('end_date', endDate);

    const url = `/api/raw_data?${params.toString()}`;
    const response = await fetch(url);
    
    if (!response.ok) {
        console.error('Failed to fetch raw data');
        return [];
    }
    return await response.json();
}

/**
 * 에러 코드와 한글명 매핑 정보를 가져옵니다.
 * @returns {Promise<Object>} 에러 코드 맵 Promise 객체
 * 
 * @example
 * // 사용 예시
 * import { fetchErrorCodeMap } from './api.js';
 * 
 * async function initialize() {
 *   const errorCodeMap = await fetchErrorCodeMap();
 *   errorCodeMap; // { 'CD901': '성공', 'CD902': '실패' }
 * }
 */
export async function fetchErrorCodeMap() {
    const response = await fetch('/api/analysis/error_code_map');
    if (!response.ok) {
        console.error('Failed to fetch error code map');
        return {};
    }
    return await response.json();
}

/**
 * tb_con_hist 테이블의 min, max 날짜를 가져옵니다.
 * @returns {Promise<Object>} min, max 날짜를 포함하는 Promise 객체
 */
export async function fetchMinMaxDates() {
    const response = await fetch('/api/min-max-dates');
    if (!response.ok) {
        console.error('Failed to fetch min/max dates');
        return { min_date: null, max_date: null };
    }
    return await response.json();
}
