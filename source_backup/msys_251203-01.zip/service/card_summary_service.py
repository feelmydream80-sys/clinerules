# service/card_summary_service.py
from collections import defaultdict
from service.dashboard_service import DashboardService
from datetime import datetime
import pytz
from flask import current_app

class CardSummaryService:
    def __init__(self, db_connection):
        self.dashboard_service = DashboardService(db_connection)

    def get_card_summary(self, user):
        """
        Gets the latest job status for today and formats it for the card summary view.
        """
        # 1. Get today's raw data using the new flag
        job_statuses_today = self.dashboard_service.get_raw_data(user=user, use_kst_today=True)

        job_statuses = job_statuses_today
        
        # 4. Build summary data
        summary_data = defaultdict(lambda: {
            "success": {"count": 0, "jobs": []},
            "progress": {"count": 0, "jobs": []},
            "fail": {"count": 0, "jobs": []}
        })

        kst = pytz.timezone('Asia/Seoul')
        utc = pytz.utc

        for job in job_statuses:
            job_id = job['job_id']
            status = job['status']
            start_dt = job.get('start_dt')
            
            if job_id and job_id.startswith('CD'):
                group = f"CD{job_id[2]}00" # e.g., CD101 -> CD100
                
                # Format job string with KST hour
                formatted_job = job_id
                if isinstance(start_dt, datetime):
                    # Robustly handle both naive and aware datetimes
                    if start_dt.tzinfo is None:
                        # If naive, assume UTC and make it aware
                        start_dt_aware = utc.localize(start_dt)
                    else:
                        # If already aware, use it as is
                        start_dt_aware = start_dt
                    
                    kst_time = start_dt_aware.astimezone(kst)
                    formatted_job = f"{job_id}({kst_time.hour}시)"

                if status == 'success' or status == 'CD901':
                    summary_data[group]['success']['count'] += 1
                    summary_data[group]['success']['jobs'].append(formatted_job)
                elif status == 'processing' or status == 'CD904':
                    summary_data[group]['progress']['count'] += 1
                    summary_data[group]['progress']['jobs'].append(formatted_job)
                else: # fail, error, etc.
                    summary_data[group]['fail']['count'] += 1
                    summary_data[group]['fail']['jobs'].append(formatted_job)

        return summary_data
