# service/dashboard_service.py
"""
Dashboard and Analytics Business Logic
Handles fetching and processing data for the dashboard and analytics pages.
"""
import logging
from typing import Optional, List, Dict
from mapper.dashboard_mapper import DashboardMapper
from msys.database import get_db_connection

class DashboardService:
    """
    Provides methods to retrieve data for the dashboard and analytics charts.
    """

    def __init__(self, db_connection):
        self.conn = db_connection
        self.dashboard_mapper = DashboardMapper(db_connection)

    def get_summary(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False) -> List[Dict]:
        summary_data = self.dashboard_mapper.get_summary(start_date, end_date, all_data)
        return summary_data

    def get_min_max_dates(self) -> Optional[Dict]:
        return self.dashboard_mapper.get_min_max_dates()

    def get_analytics_success_rate_trend(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None) -> List[Dict]:
        trend_data = self.dashboard_mapper.get_analytics_success_rate_trend(start_date, end_date, job_ids)
        return trend_data

    def get_trouble_by_code(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None) -> List[Dict]:
        trouble_data = self.dashboard_mapper.get_analytics_trouble_by_code(start_date, end_date, job_ids)
        return trouble_data

    def get_raw_data(self, start_date: Optional[str] = None, end_date: Optional[str] = None, job_ids: Optional[List[str]] = None, all_data: bool = False, use_kst_today: bool = False) -> List[Dict]:
        raw_data = self.dashboard_mapper.get_raw_data(start_date, end_date, job_ids, all_data, use_kst_today)
        return raw_data

    def get_event_log(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False) -> List[Dict]:
        event_log_data = self.dashboard_mapper.get_event_log(start_date, end_date, all_data)
        return event_log_data

    def get_distinct_job_ids(self) -> List[str]:
        job_ids = self.dashboard_mapper.get_distinct_job_ids()
        return job_ids

    def save_event(self, con_id: Optional[str], job_id: Optional[str], status: str, rqs_info: str):
        self.dashboard_mapper.save_event(con_id, job_id, status, rqs_info)

    def get_daily_job_counts(self, job_id: Optional[str], start_date: Optional[str], end_date: Optional[str], all_data: bool) -> List[Dict]:
        data = self.dashboard_mapper.get_daily_job_counts(job_id, start_date, end_date, all_data)
        return data

    def get_distinct_error_codes(self, start_date: Optional[str] = None, end_date: Optional[str] = None, all_data: bool = False) -> List[str]:
        error_codes = self.dashboard_mapper.get_distinct_error_codes(start_date, end_date, all_data)
        return error_codes

    def get_collection_history_for_schedule(self, start_date: str, end_date: str) -> List[Dict]:
        return self.dashboard_mapper.get_collection_history_for_schedule(start_date, end_date)
