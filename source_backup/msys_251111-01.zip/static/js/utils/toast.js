/**
 * Displays a toast message at the top of the screen.
 * @param {string} message - The message to display.
 * @param {string} type - The type of toast ('info', 'success', 'error').
 * @param {number} duration - The duration in milliseconds for the toast to be visible.
 */
export function showToast(message, type = 'info', duration = 3000) {
    // Create the toast element
    const toast = document.createElement('div');
    toast.className = `fixed top-5 right-5 p-4 rounded-md shadow-lg text-white font-bold z-50 transition-transform transform translate-x-full`;
    
    // Set background color based on type
    const colors = {
        info: 'bg-blue-500',
        success: 'bg-green-500',
        error: 'bg-red-500'
    };
    toast.classList.add(colors[type] || colors.info);
    toast.textContent = message;

    // Append to body
    document.body.appendChild(toast);

    // Animate in
    setTimeout(() => {
        toast.classList.remove('translate-x-full');
        toast.classList.add('translate-x-0');
    }, 100);

    // Animate out and remove after duration
    setTimeout(() => {
        toast.classList.remove('translate-x-0');
        toast.classList.add('translate-x-full');
        toast.addEventListener('transitionend', () => {
            toast.remove();
        });
    }, duration);
}
